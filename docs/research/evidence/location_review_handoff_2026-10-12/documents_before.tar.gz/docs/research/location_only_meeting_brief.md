# Location-only inference: meeting brief

12 October 2026. Scope: known-scale Student, Logistic and Laplace location models.

**Decision:** use explicit selected-statistic methods. Keep raw weighted Monte
Carlo as the reference. The KDE helper is repaired. New Logistic and Laplace
kernels pass focused correctness checks. Student endpoint checks are cheaper.
These changes do not establish adequate RATTLE tail mixing or a fastest method.

This note uses short sentences and defined terms, in the spirit of ASD-STE100.
It is not a claim of formal standard compliance. The work follows the agreed
correctness-first scope. No tuning campaign or repository reorganization was run.

## 1. The target we must preserve

We observe a released statistic \(t=T(X)\). We infer the model location \(\mu\).
For Student data, \(T\) selects the global likelihood maximum. It selects the
smaller location only when global maxima tie exactly. Logistic has one maximum.
For Laplace, this work selects the middle observation for odd sample sizes.
For even sizes, it selects the midpoint of the two middle observations.

Score zero alone does not define the desired conditional distribution. Write

\[
C(x)=\sum_i\psi(x_i-t),\qquad
J(x)=\sum_i\psi'(x_i-t),\qquad G(x)=\sum_i\psi'(x_i-t)^2.
\]

On regular selected-maximum states, implicit differentiation gives
\(\nabla T=\nabla C/J\). Coarea therefore gives the surface density

\[
\rho_T(x\mid\mu)\propto
\mathbf1\{T(x)=t\}\,F_\mu(x)\,J(x)/\sqrt{G(x)}.
\]

The score-conditioned density lacks the selection indicator and \(J\). A unique
score root does not remove this curvature factor. These statements concern
regular regions. They do not certify singular roots or exact tie boundaries.
The [target audit](selected_mle_target_audit.md) gives the full measure derivation.

Translation equivariance gives a separate reference construction. Draw independent
standardized data \(E\sim f_0^n\). Set \(\mu=t-T(E)\) and \(X=E+\mu\mathbf1\).
Weight each draw by \(\pi_0(t-T(E))\). Integrating the release constraint over
\(\mu\) has derivative one. Thus this representation needs no extra curvature
factor. Raw weighting, prior rejection and independence MH use this same identity.

## 2. What changed in the code

| Family | Selected latent Gibbs | Hamiltonian method | Endpoint validation |
|---|---|---|---|
| Student | Existing compiled reversible block; transparent pair baseline retained | Existing pure RATTLE with corrected endpoint MH | Guarded root certificate, then hardened selector if needed |
| Logistic | New compiled reversible score block with curvature MH | New pure RATTLE with score guiding force and curvature MH | Unique-root bracket |
| Laplace | New ordered median/midpoint conditionals, followed by random labels | New reflective facet HMC, followed by random labels | Direct median/midpoint check |

Find the imports and entrypoints in
[`SELECTED_LOCATION_METHODS`](../../models/model_registry.py). The old score
samplers and Laplace comparators keep their original behavior. Affine, independence
MH, the hardened selector and location-scale code are unchanged.

Selected Student parameter updates now use the full machine uniform range.
The previous positive lower cutoff could forbid very small MH probabilities.
The block proposal normalizer now uses a sum of positive error functions. This
avoids subtracting almost equal Gaussian CDF values in narrow intervals. It does
not floor the proposal mass. Unresolved arithmetic raises an explicit error.

**Gibbs correction.** Hold \(\mu\) fixed inside a block. Each random-scan pair
kernel is reversible for the score target. Its fixed-length power is also
reversible. One outer MH step therefore uses \(W(x')/W(x)\), with
\(W=\mathbf1\{T=t\}J\). Student retains both finite inverse branches and their
inverse-Jacobian weights. Branch refresh belongs inside the reversible proposal.
It must not be applied after rejecting the corrected block.

For Logistic, use \(z=\tanh((x-t)/2)\), \(x=t+2\operatorname{atanh}z\), and
\(J=\frac12\sum_i\operatorname{sech}^2((x_i-t)/2)\). Its inverse is unique.
The new kernel uses the exact inverse Jacobian and the truncated-proposal Hastings
ratio. The ordinary parameter MH update uses the full likelihood and prior.

**RATTLE correction.** Both smooth families use identity mass and tangent Gaussian
momenta. Their guiding Hamiltonian is
\(H_s=-\log F_\mu+\frac12\log G+\frac12p^Tp\).
The endpoint log acceptance is \(-\Delta H_s+\log J'-\log J\), on selected
support. The full position-and-momentum reverse check remains mandatory.
A regular guiding trajectory may pass through invalid selected states. The
endpoint check defines support. No latent Gibbs move was added to RATTLE.

**Laplace requires different geometry.** Smooth score RATTLE does not apply to
its order statistic. In sorted coordinates, the median constraint is linear on
each ordering region. Its coarea factor is constant. For even \(n=2h\), write the
middle pair as \(t-d,t+d\). Given the outer observations,

\[
p(d\mid x_{\rm outer},\mu,t)\propto
\exp[-2\max(d,|\mu-t|)/b],\qquad 0<d<U,
\]

where \(U=\min(t-x_{h-1},x_{h+2}-t)\), using one-based ranks; \(U=\infty\) for
\(n=2\). The code draws the uniform and exponential pieces directly. It then
draws the outer observations from the correct truncated Laplace laws. Odd-n
Gibbs fixes the middle observation and draws both sides. These are conditional
updates; integrating out the outer observations would require additional factors.

Reflective HMC uses projected force kicks and specular drift at ordering walls.
The wall normal is projected into the median tangent space. These maps preserve
canonical volume and reverse under momentum reversal in exact arithmetic, away
from ambiguous corner collisions. Final MH uses the full potential and kinetic
energy. A uniform permutation restores exchangeable observation labels for both
Laplace methods. Fixed label assignments are not the full selected-data target.

## 3. Cheaper checks and numerical limits

Student block and RATTLE runners now default to `mle_check='auto'`. The original
path remains available through `mle_check='selector'`. The legacy n=3 option
still works when supplied alone. Conflicting options raise an error.

The existing n=3 theorem identifies the unique selected root in
\(\operatorname{median}(x)\pm\sqrt{k}\). Acceptance requires a certified root
bracket around the release. A small score residual alone is insufficient.
The [n=3 report](student_n3_fast_path_validation.md) records the outward arithmetic
assumptions and adversarial checks. This certificate is now shared with RATTLE.

A new sufficient test works for any n at unit scale. If
\((\max x-\min x)^2<k\), all score roots lie in the data range. Within that
range, every score derivative with respect to location is negative. Thus the
root is unique and global. Outward arithmetic must also prove opposite score
signs inside the requested release tolerance. Inconclusive checks use the full
selector. This narrow condition cannot replace selection for dispersed n=5 data.

In the smoke study, n=3 block and RATTLE made only one full-selector call per
chain, for initialization. The general small-diameter test certified only one
n=10 endpoint. It provides no demonstrated broad n=10 speed improvement.

Logistic uses monotonicity and a release bracket, with long-double score signs
and selective high precision. This is a checked numerical enclosure, not a
formally verified interval implementation of transcendental functions. Laplace
checks its order statistic directly. All methods have explicit failure paths.
Representability, nearly singular geometry and finite projection tolerances
remain limits. Student and Logistic updates studied here use unit known scale;
Laplace accepts positive known scale \(b\).

The first Laplace smoke stopped at iteration 8: collision roundoff produced a
tiny negative ordering gap. The fix represents contact on the wall and median
plane only within a bounded rounding error. Larger errors and simultaneous
collisions still raise. Reverse checks remain active. The failed partial chain
is retained. A regression reproduces its start and seed.

## 4. KDE helper repair

[`gaussian_kde_gaussian_prior_moments`](../../kde_ref/moments.py) had two defects.
It took quantiles of mixture component means, omitting component spread. It also
lost the log-weight offset when computing the normalizer.

The helper now solves the full Gaussian-mixture CDF and uses log-sum-exp weights.
It returns a log normalizer when the ordinary value underflows. Independent
quadrature checks cover centered, shifted and narrow kernels. In the recorded
two-point example, the repaired 95% interval is approximately ([-2.46185,2.46185])
and the normalizer is 0.155146.

This repair does not validate unchecked caches, bandwidth labels or every
finite-grid integration path. KDE remains a density approximation. Use raw
weighted summaries, bank hashes and importance ESS for reference claims.

## 5. Tests and bounded numerical evidence

**395 tests passed** in 198.31 seconds. The final output is recorded in
[`pytest_final.log`](evidence/location_only_correctness_2026-10-12/pytest_final.log).
Focused checks cover mixture quadrature, branch/proposal balance, curvature,
root brackets, force differences, canonical phase volume, reverse paths,
constraints, failures, fixed seeds, chain independence and label permutations.
Auto and selector-only Student runs retain identical tested trajectories.

The [smoke configuration](evidence/location_only_correctness_2026-10-12/smoke_attempt2/config.json)
fixes two dispersed starts, 512 iterations and 128 discarded iterations. Student
uses existing hashed banks and carries forward their uncertainty. Logistic and
Laplace use fresh 4096-row banks, independent root/order-statistic calculations
and 64 particle bootstrap replicates. Shifted-bank importance ESS is only
about 455–565 for the new families. These are small correctness references.

All 40 final chains complete without numerical failures. Twelve retained Student
endpoints pass the rational oracle, with maximum release error \(1.78\times10^{-15}\).
The following entries show **reference / Gibbs / Hamiltonian** estimates.
Centered cases use \(t=0,\pi=N(0,2^2)\). Shifted cases use
\(t=1.25,\pi=N(-0.75,0.6^2)\). Student has \(k=2\).

| Case | Posterior mean | P(maximum absolute residual > 6) |
|---|---|---|
| Student n=3, centered | −0.003 / −0.020 / 0.060 | .0669 / .0443 / .0885 |
| Student n=10, centered | −0.001 / −0.069 / −0.014 | .2344 / .2695 / .1797 |
| Student n=10, shifted | .493 / .515 / .480 | .2692 / .2552 / .2370 |
| Logistic n=3, centered | −0.017 / −0.061 / .101 | .0075 / .0078 / .0000 |
| Logistic n=10, centered | −0.007 / .018 / −0.073 | .0395 / .0534 / .0573 |
| Logistic n=10, shifted | .290 / .376 / .335 | .0381 / .0234 / .0195 |
| Laplace n=3, centered | −0.002 / −0.227 / −0.038 | .0050 / .0078 / .0013 |
| Laplace n=4, centered | .015 / .036 / .204 | .0079 / .0091 / .0000 |
| Laplace n=3, shifted | −0.079 / −0.097 / −0.104 | .0060 / .0091 / .0000 |
| Laplace n=4, shifted | .075 / .108 / .082 | .0081 / .0078 / .0000 |

![Small-run reference comparisons](evidence/location_only_correctness_2026-10-12/smoke_attempt2/smoke_comparison.png)

Do not read zero observed events as zero uncertainty. No convergence screens
were declared passed. Student RATTLE centered n=10 has latent-maximum R-hat 1.31
and bulk ESS about 5.3. Logistic centered n=3 Gibbs has parameter R-hat 1.14.
The short chains are insufficient for precise comparisons. Full SDs, quantiles,
chain differences, tail residence, ESS and acceptance counters are saved in
[comparisons.json](evidence/location_only_correctness_2026-10-12/smoke_attempt2/comparisons.json).

Historical block Gibbs had strong tested latent mixing. Its n=3 certificate gave
1.58–2.05× speedups in the earlier matched study. Those results are carried
forward, not newly measured for revised code. Historical selected RATTLE failed
both n=10 latent-mixing screens. That finding remains unresolved. Smoke timings
include compilation in some paths and must not be used to rank methods.

## 6. Can Basu's theorem help?

Basu gives independence between an ancillary statistic and a boundedly complete
sufficient statistic. Translation equivariance makes \(A=X-T(X)\mathbf1\)
ancillary. It does not establish the required sufficiency of \(T\). See
[Boos and Hughes-Oliver (1998)](https://homepages.math.uic.edu/~rgmartin/Teaching/Stat411/Refs/BoosOliver1998.pdf).

Exact likelihood comparisons disprove sufficiency here. For Student k=1, compare
data \((-1,0,1)\) and \((-2,0,2)\). Both have selected MLE zero. Their denominator
product ratio is \(4/25\) at location zero and \(1/4\) at location one. For Logistic,
compare \((-\log2,0,\log2)\) and \((-\log4,0,\log4)\). Their likelihood ratio is
\(625/324\) at zero and \(729/400\) at \(\log2\). For Laplace, the absolute-deviation
sum difference for the first two datasets changes from −2 at zero to −1 at 1.5.
These continuous differences persist locally on the regular statistic fibers.
Thus equal released estimators do not give parameter-free likelihood ratios.

Moreover, \((T,A)\) reconstructs \(X\). If ancillary \(A\) were independent of \(T\)
for every location, the conditional data law given \(T\) would be parameter-free.
That would make \(T\) sufficient, contradicting these examples. Basu therefore
cannot remove our correction or prior weights. Random labels are independent of
order statistics by IID exchangeability; their restoration needs no Basu argument.

Gaussian data provide the positive control. With known variance, the sample mean
is complete and sufficient. The centered residual is ancillary and independent
of the mean. A focused test checks the covariance identity and the analytic
Gaussian posterior against quadrature.

## 7. Reproduce and decide

Use Python 3.13.5 and the existing environment. On this host, the supplementary
oracle dependencies reside in `/tmp/student-mle-oracle-deps-20261003`.

```bash
export PYTHONPATH=/tmp/student-mle-oracle-deps-20261003
export NUMBA_CACHE_DIR=/tmp/student-location-correctness-numba
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 .venv/bin/python -m pytest tests -q -p no:cacheprovider
.venv/bin/python scripts/validate_location_only_correctness.py --output tmp/location-smoke-new
```

The driver refuses an existing output directory. It saves configuration, seeds,
source hashes, raw data and failures. Original evidence and source snapshots are
preserved. Historical source verification remains strict: archived bytes do not
certify current numerical equivalence. See the
[preservation record](evidence/location_only_correctness_2026-10-12/preservation.json).

**Next decision:** approve one bounded mixing and efficiency comparison for the
new Logistic and Laplace methods. Keep Student block Gibbs and direct simulation
as fixed controls. Treat pure RATTLE tail transport as an open problem. Do not
describe these kernels as universally perfect, certified or fastest.
