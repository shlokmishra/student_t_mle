"""Known-scale location inference."""
