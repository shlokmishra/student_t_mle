"""Logistic score-conditioned comparators."""
