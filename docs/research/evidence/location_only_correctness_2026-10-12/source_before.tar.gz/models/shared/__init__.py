"""Shared numerical utilities."""
