"""Run long Student-t Gibbs/RATTLE chains and make readable trace figures.

Example:
    python scripts/plot_student_chain_traces.py \
        --n-values 10,50,200 --iterations 20000 --burn-in 5000 \
        --out /tmp/student_chain_traces
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-cache")

import jax.random as random
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from models import loc_student, loc_student_rattle


QUANTILES = np.array([0.05, 0.25, 0.50, 0.75, 0.95])
METHOD_COLORS = {"gibbs": "#1769aa", "rattle": "#c62828"}


def _ints(text: str) -> list[int]:
    return [int(part) for part in text.split(",") if part.strip()]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=float, default=2.0)
    parser.add_argument("--n-values", type=_ints, default=[10, 50, 200])
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--mu-star", type=float, default=0.0)
    parser.add_argument("--iterations", type=int, default=20_000)
    parser.add_argument("--burn-in", type=int, default=5_000)
    parser.add_argument("--plot-thin", type=int, default=5)
    parser.add_argument("--proposal-std-mu", type=float, default=0.3)
    parser.add_argument("--proposal-std-z", type=float, default=0.02)
    parser.add_argument("--prior-mean", type=float, default=0.0)
    parser.add_argument("--prior-std", type=float, default=10.0)
    parser.add_argument("--rattle-step-size", type=float, default=0.05)
    parser.add_argument("--rattle-num-steps", type=int, default=2)
    parser.add_argument("--rattle-proj-tol", type=float, default=1e-10)
    parser.add_argument("--rattle-proj-max-iters", type=int, default=25)
    parser.add_argument("--rattle-reverse-position-tol", type=float, default=5e-3)
    parser.add_argument(
        "--rattle-settings-json",
        type=Path,
        default=None,
        help="Optional size-specific RATTLE settings preset, as used by run_cost_audit.py.",
    )
    parser.add_argument("--out", type=Path, required=True)
    return parser.parse_args()


def _ess(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    n = values.size
    if n < 3:
        return float(n)
    centered = values - values.mean()
    variance = float(np.dot(centered, centered) / n)
    if variance <= 0.0 or not np.isfinite(variance):
        return float(n)
    autocorr_sum = 0.0
    for lag in range(1, n):
        rho = float(np.dot(centered[:-lag], centered[lag:]) / n / variance)
        if rho <= 0.0:
            break
        autocorr_sum += rho
    return float(max(n / (1.0 + 2.0 * autocorr_sum), 1.0))


def _acf1(values: np.ndarray) -> float:
    values = np.asarray(values, dtype=float)
    if values.size < 3:
        return float("nan")
    centered = values - values.mean()
    denom = float(np.dot(centered, centered))
    if denom <= 0.0:
        return float("nan")
    return float(np.dot(centered[:-1], centered[1:]) / denom)


def _constraint_residuals(xs: np.ndarray, mu_star: float, k: float) -> np.ndarray:
    y = np.asarray(xs, dtype=float) - float(mu_star)
    return np.sum(y / (float(k) + y * y), axis=1)


def _params(args: argparse.Namespace, n: int) -> dict:
    params = {
        "n": int(n),
        "k": float(args.k),
        "num_iterations_T": int(args.iterations),
        "proposal_std_mu": float(args.proposal_std_mu),
        "proposal_std_z": float(args.proposal_std_z),
        "prior_mean": float(args.prior_mean),
        "prior_std": float(args.prior_std),
        "initialization": "central",
        "initialization_seed": int(args.seed),
        "store_x_chain": True,
        "rattle_step_size": float(args.rattle_step_size),
        "rattle_num_steps": int(args.rattle_num_steps),
        "rattle_proj_tol": float(args.rattle_proj_tol),
        "rattle_proj_max_iters": int(args.rattle_proj_max_iters),
        "rattle_reverse_position_tol": float(args.rattle_reverse_position_tol),
        "rattle_projection_mode": "paper_fixed_direction",
        "rattle_include_gram_correction": True,
        "reverse_check": True,
    }
    selected = args.rattle_settings.get(f"student_t:k={float(args.k):g}:n={int(n)}", {})
    if "rattle_step_size" in selected:
        params["rattle_step_size"] = float(selected["rattle_step_size"])
    if "rattle_num_steps" in selected:
        params["rattle_num_steps"] = int(selected["rattle_num_steps"])
    return params


def _load_rattle_settings(path: Path | None) -> dict[str, dict]:
    if path is None:
        return {}
    with path.open(encoding="utf-8") as handle:
        data = json.load(handle)
    if isinstance(data, dict) and isinstance(data.get("by_key"), dict):
        return data["by_key"]
    if isinstance(data, dict):
        return data
    raise ValueError(f"RATTLE settings must be a JSON object: {path}")


def _selected_coordinate_indices(post_x: np.ndarray) -> list[tuple[float, int]]:
    coordinate_medians = np.median(post_x, axis=0)
    targets = np.quantile(coordinate_medians, QUANTILES)
    return [(float(q), int(np.argmin(np.abs(coordinate_medians - target)))) for q, target in zip(QUANTILES, targets)]


def _trace_indices(length: int, thin: int) -> np.ndarray:
    return np.arange(0, length, max(int(thin), 1), dtype=int)


def _format_trace_axis(axis: plt.Axes, args: argparse.Namespace) -> None:
    axis.axvline(args.burn_in, color="#303030", linestyle="--", linewidth=0.9, zorder=3)
    axis.grid(axis="y", alpha=0.22, linewidth=0.6)
    axis.spines[["top", "right"]].set_visible(False)


def _plot_mu_traces(
    n: int,
    chains: dict[str, dict],
    args: argparse.Namespace,
    out_dir: Path,
) -> None:
    indices = _trace_indices(args.iterations + 1, args.plot_thin)
    mu_limits = np.quantile(
        np.concatenate([chain["mu"] for chain in chains.values()]), [0.001, 0.999]
    )
    pad = max(0.05 * float(mu_limits[1] - mu_limits[0]), 1e-3)
    fig, axes = plt.subplots(2, 1, figsize=(12, 6.5), sharex=True, sharey=True, layout="constrained")
    for axis, (method, chain) in zip(axes, chains.items()):
        axis.plot(indices, chain["mu"][indices], color=METHOD_COLORS[method], linewidth=0.8)
        axis.set_title(f"{method.upper()}  |  location parameter $\\mu$")
        axis.set_ylabel("$\\mu$")
        axis.set_ylim(float(mu_limits[0] - pad), float(mu_limits[1] + pad))
        _format_trace_axis(axis, args)
    axes[0].text(
        0.99,
        0.92,
        "dashed line = burn-in",
        transform=axes[0].transAxes,
        ha="right",
        va="top",
        fontsize=9,
        color="#303030",
    )
    axes[-1].set_xlabel("iteration")
    fig.suptitle(f"Student-t location traces (n={n})", fontsize=14, fontweight="bold")
    fig.savefig(out_dir / f"mu_traces_n{n}.png", dpi=180)
    plt.close(fig)


def _plot_x_quantile_traces(
    n: int,
    chains: dict[str, dict],
    args: argparse.Namespace,
    out_dir: Path,
) -> list[dict]:
    indices = _trace_indices(args.iterations + 1, args.plot_thin)
    pooled_post_x = np.concatenate(
        [chain["x"][args.burn_in :] for chain in chains.values()], axis=0
    )
    selected = _selected_coordinate_indices(pooled_post_x)
    finite_values = pooled_post_x[np.isfinite(pooled_post_x)]
    if finite_values.size:
        zoom_abs = max(abs(float(np.quantile(finite_values, 0.005))), abs(float(np.quantile(finite_values, 0.995))), 1e-6)
        raw_abs = max(abs(float(np.min(finite_values))), abs(float(np.max(finite_values))), 1e-6)
    else:
        zoom_abs = raw_abs = 1.0

    def draw(scale_mode: str, filename: str, title_suffix: str) -> None:
        fig, axes = plt.subplots(len(QUANTILES), 2, figsize=(14, 15), sharex=True, layout="constrained")
        for column, (method, chain) in enumerate(chains.items()):
            for row, (quantile, coordinate) in enumerate(selected):
                axis = axes[row, column]
                values = chain["x"][:, coordinate]
                axis.plot(indices, values[indices], color=METHOD_COLORS[method], linewidth=0.7)
                _format_trace_axis(axis, args)
                if row == 0:
                    axis.set_title(method.upper(), fontsize=12, fontweight="bold")
                axis.set_ylabel(f"q={quantile:.2f}\\n$x_{{{coordinate}}}$")
                if row == len(QUANTILES) - 1:
                    axis.set_xlabel("iteration")
                if scale_mode == "symlog":
                    axis.set_yscale("symlog", linthresh=1.0, linscale=1.0)
                    axis.set_ylim(-raw_abs, raw_abs)
                else:
                    axis.set_ylim(-zoom_abs, zoom_abs)
                    outside = np.mean(np.abs(values) > zoom_abs)
                    axis.text(0.99, 0.92, f"outside: {100.0 * outside:.1f}%", transform=axis.transAxes, ha="right", va="top", fontsize=8, color="#555555")
        fig.suptitle(
            f"Student-t latent-coordinate traces by pooled post-burn quantile (n={n}){title_suffix}",
            fontsize=14,
            fontweight="bold",
        )
        fig.text(0.5, 0.985, "Both methods use the same coordinate in each row; dashed line marks burn-in.", ha="center", va="top", fontsize=9, color="#303030")
        fig.savefig(out_dir / filename, dpi=180)
        plt.close(fig)

    draw("symlog", f"x_marginal_quantile_traces_n{n}.png", " — shared symmetric-log scale")
    draw("zoom", f"x_marginal_quantile_traces_zoom_n{n}.png", " — shared central 99% zoom")

    summaries: list[dict] = []
    for column, (method, chain) in enumerate(chains.items()):
        for quantile, coordinate in selected:
            values = chain["x"][:, coordinate]
            post = values[args.burn_in:]
            summaries.append(
                {
                    "method": method,
                    "n": n,
                    "series": f"x_coordinate_q{quantile:.2f}",
                    "coordinate": coordinate,
                    "mean": float(np.mean(post)),
                    "sd": float(np.std(post)),
                    "acf1": _acf1(post),
                    "ess": _ess(post),
                }
            )
    return summaries


def _run_case(args: argparse.Namespace, n: int) -> tuple[dict[str, dict], list[dict]]:
    params = _params(args, n)
    key = random.PRNGKey(args.seed)
    key_gibbs, key_rattle = random.split(key)
    gibbs_out = loc_student.run_gibbs(key_gibbs, args.mu_star, params.copy(), verbose=False)
    rattle_out = loc_student_rattle.run_rattle(key_rattle, args.mu_star, params.copy(), verbose=False)
    chains = {
        "gibbs": {"mu": np.asarray(gibbs_out["mu_chain"], dtype=float), "x": np.asarray(gibbs_out["x_chain"], dtype=float)},
        "rattle": {"mu": np.asarray(rattle_out["mu_chain"], dtype=float), "x": np.asarray(rattle_out["x_chain"], dtype=float)},
    }
    summary = []
    for method, chain in chains.items():
        post_mu = chain["mu"][args.burn_in:]
        residual = _constraint_residuals(chain["x"], args.mu_star, args.k)
        summary.append(
            {
                "method": method,
                "n": n,
                "series": "mu",
                "coordinate": "",
                "mean": float(np.mean(post_mu)),
                "sd": float(np.std(post_mu)),
                "acf1": _acf1(post_mu),
                "ess": _ess(post_mu),
                "max_abs_constraint_residual": float(np.max(np.abs(residual))),
            }
        )
    return chains, summary


def main() -> None:
    args = parse_args()
    if args.iterations <= args.burn_in or args.burn_in < 0:
        raise ValueError("iterations must exceed a non-negative burn-in")
    args.rattle_settings = _load_rattle_settings(args.rattle_settings_json)
    args.out.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    for n in args.n_values:
        print(f"running Gibbs and RATTLE traces: n={n}, iterations={args.iterations}", flush=True)
        chains, summary = _run_case(args, n)
        _plot_mu_traces(n, chains, args, args.out)
        rows.extend(summary)
        rows.extend(_plot_x_quantile_traces(n, chains, args, args.out))
    with (args.out / "trace_summary.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=sorted({key for row in rows for key in row}))
        writer.writeheader()
        writer.writerows(rows)
    (args.out / "trace_metadata.json").write_text(
        json.dumps(
            {
                "k": float(args.k),
                "n_values": [int(n) for n in args.n_values],
                "seed": int(args.seed),
                "iterations": int(args.iterations),
                "burn_in": int(args.burn_in),
                "plot_thin": int(args.plot_thin),
                "latent_plot_scales": ["shared symmetric-log", "shared central 99% zoom"],
                "coordinate_selection": "pooled post-burn coordinate medians across Gibbs and RATTLE",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print(args.out, flush=True)


if __name__ == "__main__":
    main()
