"""Profile the production Student-t Gibbs and RATTLE samplers by function.

The profiler warms Numba before recording timing, runs the real production
samplers, and writes raw cProfile files plus sortable per-function tables.
Compiled Numba kernels appear at their Python dispatcher boundary; cProfile
cannot split time inside native machine code without a native profiler.

Example:
    .venv/bin/python scripts/profile_student_sampler_functions.py \
        --n 50 --iterations 10000 \
        --rattle-settings-json configs/student_rattle_k2_tuned_20260817.json \
        --out results/latest/student_t_function_profile
"""

from __future__ import annotations

import argparse
import cProfile
import csv
import io
import json
import pstats
import shutil
import sys
import time
from pathlib import Path
from typing import Any

import jax.random as random

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from models import loc_student, loc_student_rattle


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n", type=int, default=50, help="Representative n to profile.")
    parser.add_argument("--k", type=float, default=2.0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--iterations", type=int, default=10_000)
    parser.add_argument("--warmup-iterations", type=int, default=3)
    parser.add_argument("--mu-star", type=float, default=0.0)
    parser.add_argument("--proposal-std-mu", type=float, default=0.3)
    parser.add_argument("--proposal-std-z", type=float, default=0.02)
    parser.add_argument("--prior-mean", type=float, default=0.0)
    parser.add_argument("--prior-std", type=float, default=10.0)
    parser.add_argument("--rattle-step-size", type=float, default=0.05)
    parser.add_argument("--rattle-num-steps", type=int, default=2)
    parser.add_argument("--rattle-settings-json", type=Path, default=None)
    parser.add_argument(
        "--chain-traces-dir",
        type=Path,
        default=Path("results/student_chain_traces_presentable_20260817"),
        help="Existing trace figures copied alongside profiling results when present.",
    )
    parser.add_argument("--top-functions", type=int, default=40)
    parser.add_argument("--out", type=Path, default=Path("results/latest/student_t_function_profile"))
    return parser.parse_args()


def _load_rattle_settings(path: Path | None) -> dict[str, dict[str, Any]]:
    if path is None:
        return {}
    with path.open(encoding="utf-8") as handle:
        data = json.load(handle)
    if isinstance(data, dict) and isinstance(data.get("by_key"), dict):
        return data["by_key"]
    if isinstance(data, dict):
        return data
    raise ValueError(f"RATTLE settings must be a JSON object: {path}")


def _params(args: argparse.Namespace, iterations: int, rattle_settings: dict[str, dict[str, Any]]) -> dict[str, Any]:
    params = {
        "n": int(args.n),
        "k": float(args.k),
        "num_iterations_T": int(iterations),
        "proposal_std_mu": float(args.proposal_std_mu),
        "proposal_std_z": float(args.proposal_std_z),
        "prior_mean": float(args.prior_mean),
        "prior_std": float(args.prior_std),
        "initialization": "central",
        "initialization_seed": int(args.seed),
        "store_x_chain": True,
        "gibbs_backend": "numba_full",
        "rattle_step_size": float(args.rattle_step_size),
        "rattle_num_steps": int(args.rattle_num_steps),
        "rattle_proj_tol": 1e-10,
        "rattle_proj_max_iters": 25,
        "rattle_reverse_position_tol": 5e-3,
        "rattle_projection_mode": "paper_fixed_direction",
        "rattle_include_gram_correction": True,
        "reverse_check": True,
    }
    key = f"student_t:k={float(args.k):g}:n={int(args.n)}"
    selected = rattle_settings.get(key, {})
    if "rattle_step_size" in selected:
        params["rattle_step_size"] = float(selected["rattle_step_size"])
    if "rattle_num_steps" in selected:
        params["rattle_num_steps"] = int(selected["rattle_num_steps"])
    return params


def _function_name(key: tuple[str, int, str]) -> str:
    filename, line, name = key
    known_model_files = {
        "loc_student.py",
        "loc_student_rattle.py",
        "student_mu_mh.py",
        "loc_logistic.py",
        "loc_laplace.py",
    }
    if str(filename) in known_model_files:
        filename = f"models/{filename}"
    try:
        filename = str(Path(filename).resolve().relative_to(REPO_ROOT))
    except ValueError:
        filename = str(filename)
    return f"{filename}:{line}:{name}"


def _profile(method: str, fn, raw_path: Path, top_functions: int) -> tuple[float, list[dict[str, Any]], str]:
    profiler = cProfile.Profile()
    started = time.perf_counter()
    profiler.enable()
    result = fn()
    profiler.disable()
    elapsed = time.perf_counter() - started
    profiler.dump_stats(raw_path)

    # Preserve full paths so the report can distinguish functions under
    # models/ from profiler and orchestration code.
    stats = pstats.Stats(profiler).sort_stats("cumulative")
    text = io.StringIO()
    stats.stream = text
    stats.print_stats(top_functions)
    rows = []
    for key, values in stats.stats.items():
        primitive_calls, total_calls, self_seconds, cumulative_seconds, _ = values
        rows.append(
            {
                "method": method,
                "function": _function_name(key),
                "primitive_calls": int(primitive_calls),
                "total_calls": int(total_calls),
                "self_seconds": float(self_seconds),
                "cumulative_seconds": float(cumulative_seconds),
            }
        )
    rows.sort(key=lambda row: row["cumulative_seconds"], reverse=True)
    return elapsed, rows, text.getvalue()


def _copy_chain_traces(source: Path, destination: Path) -> int:
    if not source.is_dir():
        return 0
    destination.mkdir(parents=True, exist_ok=True)
    copied = 0
    for path in source.iterdir():
        if path.is_file() and path.suffix.lower() in {".png", ".csv"}:
            shutil.copy2(path, destination / path.name)
            copied += 1
    return copied


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _write_report(path: Path, args: argparse.Namespace, summary: list[dict[str, Any]], profiles: dict[str, list[dict[str, Any]]]) -> None:
    lines = [
        "# Production Student-t sampler function profile",
        "",
        f"- n={args.n}, k={args.k}, iterations={args.iterations}, seed={args.seed}",
        "- Numba compilation was warmed before profiling.",
        "- cProfile reports Python-level functions and Numba dispatcher boundaries; it cannot split native time inside a compiled kernel.",
        "",
        "## Sampler totals",
        "",
        "| method | seconds | iterations/sec | latent acceptance |",
        "|---|---:|---:|---:|",
    ]
    for row in summary:
        acceptance = row.get("x_acceptance_rate", "")
        lines.append(
            f"| {row['method']} | {row['elapsed_seconds']:.6f} | {row['iterations_per_second']:.1f} | {acceptance} |"
        )
    for method, rows in profiles.items():
        lines.extend(["", f"## Top {min(15, len(rows))} {method} functions by cumulative time", ""])
        lines.extend(["| function | calls | self sec | cumulative sec |", "|---|---:|---:|---:|"])
        for row in rows[:15]:
            lines.append(
                f"| `{row['function']}` | {row['total_calls']} | {row['self_seconds']:.6f} | {row['cumulative_seconds']:.6f} |"
            )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    if args.n <= 1 or args.k <= 0.0 or args.iterations <= 0 or args.warmup_iterations <= 0:
        raise ValueError("n > 1, k > 0, iterations > 0, and warmup-iterations > 0 are required")
    args.out.mkdir(parents=True, exist_ok=True)
    rattle_settings = _load_rattle_settings(args.rattle_settings_json)
    warmup_params = _params(args, args.warmup_iterations, rattle_settings)
    profile_params = _params(args, args.iterations, rattle_settings)

    print("warming Numba kernels", flush=True)
    warmup_key = random.PRNGKey(args.seed)
    warmup_gibbs_key, warmup_rattle_key = random.split(warmup_key)
    loc_student.run_gibbs(warmup_gibbs_key, args.mu_star, warmup_params.copy(), verbose=False)
    loc_student_rattle.run_rattle(warmup_rattle_key, args.mu_star, warmup_params.copy(), verbose=False)

    profile_key = random.PRNGKey(args.seed + 1)
    gibbs_key, rattle_key = random.split(profile_key)
    gibbs_result: dict[str, Any] = {}
    rattle_result: dict[str, Any] = {}

    print("profiling production Gibbs", flush=True)
    gibbs_elapsed, gibbs_rows, gibbs_text = _profile(
        "gibbs",
        lambda: gibbs_result.update(
            loc_student.run_gibbs(gibbs_key, args.mu_star, profile_params.copy(), verbose=False)
        ),
        args.out / "gibbs.prof",
        args.top_functions,
    )
    print("profiling production RATTLE", flush=True)
    rattle_elapsed, rattle_rows, rattle_text = _profile(
        "rattle",
        lambda: rattle_result.update(
            loc_student_rattle.run_rattle(rattle_key, args.mu_star, profile_params.copy(), verbose=False)
        ),
        args.out / "rattle.prof",
        args.top_functions,
    )

    summary = [
        {
            "method": "gibbs",
            "elapsed_seconds": gibbs_elapsed,
            "iterations_per_second": args.iterations / gibbs_elapsed,
            "mu_acceptance_rate": gibbs_result.get("mu_acceptance_rate"),
            "x_acceptance_rate": "",
            "pair_acceptance_rate": gibbs_result.get("pair_acceptance_rate"),
            "rattle_step_size": "",
            "rattle_num_steps": "",
        },
        {
            "method": "rattle",
            "elapsed_seconds": rattle_elapsed,
            "iterations_per_second": args.iterations / rattle_elapsed,
            "mu_acceptance_rate": rattle_result.get("mu_acceptance_rate"),
            "x_acceptance_rate": rattle_result.get("x_acceptance_rate"),
            "pair_acceptance_rate": "",
            "rattle_step_size": profile_params["rattle_step_size"],
            "rattle_num_steps": profile_params["rattle_num_steps"],
        },
    ]
    print("writing profile artifacts", flush=True)
    _write_csv(args.out / "sampler_summary.csv", summary)
    _write_csv(args.out / "function_timing.csv", gibbs_rows + rattle_rows)
    (args.out / "gibbs_cprofile.txt").write_text(gibbs_text, encoding="utf-8")
    (args.out / "rattle_cprofile.txt").write_text(rattle_text, encoding="utf-8")
    _write_report(
        args.out / "function_profile_report.md",
        args,
        summary,
        {"Gibbs": gibbs_rows, "RATTLE": rattle_rows},
    )
    copied = _copy_chain_traces(args.chain_traces_dir, args.out / "chain_traces")
    print(f"wrote {args.out} (copied {copied} chain-trace artifacts)", flush=True)


if __name__ == "__main__":
    main()
