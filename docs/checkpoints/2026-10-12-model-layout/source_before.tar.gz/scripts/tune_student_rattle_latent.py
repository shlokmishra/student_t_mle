"""Tune production Student-t RATTLE settings against latent-x mixing.

The production sampler enforces the coarea Gram correction and a reverse
trajectory check.  This tuner keeps both requirements fixed and ranks only
numerically healthy settings using ESS/sec for mu, fixed latent coordinates,
and per-iteration latent order quantiles.

Example:
    .venv/bin/python scripts/tune_student_rattle_latent.py \
        --n-values 50,200 --seeds 0,1 --iterations 2500 --burn-in 500 \
        --out results/rattle_latent_tuning
"""

from __future__ import annotations

import argparse
import csv
import sys
import time
from collections import defaultdict
from pathlib import Path

import jax.random as random
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from analysis import effective_sample_size_1d
from models import loc_student_rattle


QUANTILES = np.array([0.05, 0.25, 0.50, 0.75, 0.95])


def _floats(text: str) -> list[float]:
    return [float(part) for part in text.split(",") if part.strip()]


def _ints(text: str) -> list[int]:
    return [int(part) for part in text.split(",") if part.strip()]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--k", type=float, default=2.0)
    parser.add_argument("--n-values", type=_ints, default=[50, 200])
    parser.add_argument("--seeds", type=_ints, default=[0, 1])
    parser.add_argument("--step-sizes", type=_floats, default=[0.025, 0.05, 0.075, 0.10, 0.15])
    parser.add_argument("--num-steps", type=_ints, default=[2, 5, 10, 20])
    parser.add_argument("--iterations", type=int, default=2500)
    parser.add_argument("--burn-in", type=int, default=500)
    parser.add_argument("--mu-star", type=float, default=0.0)
    parser.add_argument("--proposal-std-mu", type=float, default=0.3)
    parser.add_argument("--prior-mean", type=float, default=0.0)
    parser.add_argument("--prior-std", type=float, default=10.0)
    parser.add_argument("--out", type=Path, required=True)
    return parser.parse_args()


def _params(args: argparse.Namespace, n: int, step_size: float, num_steps: int) -> dict:
    return {
        "n": n,
        "k": args.k,
        "num_iterations_T": args.iterations,
        "proposal_std_mu": args.proposal_std_mu,
        "prior_mean": args.prior_mean,
        "prior_std": args.prior_std,
        "initialization": "central",
        "rattle_step_size": step_size,
        "rattle_num_steps": num_steps,
        "rattle_proj_tol": 1e-10,
        "rattle_proj_max_iters": 25,
        "rattle_reverse_position_tol": 5e-3,
        "rattle_projection_mode": "paper_fixed_direction",
        "rattle_include_gram_correction": True,
        "reverse_check": True,
    }


def _coordinate_indices(post_x: np.ndarray) -> list[int]:
    medians = np.median(post_x, axis=0)
    targets = np.quantile(medians, QUANTILES)
    return [int(np.argmin(np.abs(medians - target))) for target in targets]


def _ess_summary(mu_chain: np.ndarray, x_chain: np.ndarray, burn_in: int) -> dict[str, float]:
    post_mu = mu_chain[burn_in:]
    post_x = x_chain[burn_in:]
    coordinate_ess = np.array(
        [effective_sample_size_1d(post_x[:, coordinate]) for coordinate in _coordinate_indices(post_x)]
    )
    order_quantiles = np.quantile(post_x, QUANTILES, axis=1)
    order_ess = np.array([effective_sample_size_1d(values) for values in order_quantiles])
    return {
        "mu_ess": float(effective_sample_size_1d(post_mu)),
        "coordinate_ess_median": float(np.median(coordinate_ess)),
        "coordinate_ess_min": float(np.min(coordinate_ess)),
        "order_quantile_ess_median": float(np.median(order_ess)),
        "order_quantile_ess_min": float(np.min(order_ess)),
        "latent_ess": float(min(np.median(coordinate_ess), np.median(order_ess))),
    }


def _run_one(args: argparse.Namespace, n: int, seed: int, step_size: float, num_steps: int) -> dict:
    key = random.fold_in(random.PRNGKey(seed), n)
    start = time.perf_counter()
    result = loc_student_rattle.run_rattle(
        key, args.mu_star, _params(args, n, step_size, num_steps), verbose=False
    )
    elapsed = time.perf_counter() - start
    diagnostics = result["projection_diagnostics"]
    ess = _ess_summary(
        np.asarray(result["mu_chain"]), np.asarray(result["x_chain"]), args.burn_in
    )
    healthy = (
        diagnostics["projection_failure_count"] == 0
        and diagnostics["reverse_check_failure_count"] == 0
        and diagnostics["max_projection_residual"] <= 1e-8
        and diagnostics["max_reverse_position_error"] <= 5e-3
    )
    acceptance = float(result["x_acceptance_rate"])
    return {
        "n": n,
        "seed": seed,
        "step_size": step_size,
        "num_steps": num_steps,
        "trajectory_length": step_size * num_steps,
        "runtime_seconds": elapsed,
        "iterations_per_second": args.iterations / elapsed,
        "x_acceptance_rate": acceptance,
        "mu_acceptance_rate": float(result["mu_acceptance_rate"]),
        "healthy": healthy,
        # A constant, fully rejected chain has degenerate zero variance and can
        # otherwise receive a misleading ESS estimate.  Numerical health alone
        # is therefore not enough to make a setting usable.
        "production_eligible": healthy and acceptance >= 0.50,
        "target_acceptance_range": 0.50 <= acceptance <= 0.95,
        "projection_failure_count": diagnostics["projection_failure_count"],
        "reverse_check_failure_count": diagnostics["reverse_check_failure_count"],
        "max_projection_residual": diagnostics["max_projection_residual"],
        "max_reverse_position_error": diagnostics["max_reverse_position_error"],
        "delta_h_mean_abs": diagnostics["delta_h_mean_abs"],
        "delta_h_max_abs": diagnostics["delta_h_max_abs"],
        **ess,
        "mu_ess_per_sec": ess["mu_ess"] / elapsed,
        "latent_ess_per_sec": ess["latent_ess"] / elapsed,
    }


def _write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _aggregate(rows: list[dict]) -> list[dict]:
    grouped: dict[tuple[int, float, int], list[dict]] = defaultdict(list)
    for row in rows:
        grouped[(row["n"], row["step_size"], row["num_steps"])].append(row)
    output = []
    for (n, step_size, num_steps), group in grouped.items():
        output.append(
            {
                "n": n,
                "step_size": step_size,
                "num_steps": num_steps,
                "trajectory_length": step_size * num_steps,
                "all_production_eligible": all(row["production_eligible"] for row in group),
                "all_in_target_acceptance_range": all(row["target_acceptance_range"] for row in group),
                "mean_x_acceptance_rate": float(np.mean([row["x_acceptance_rate"] for row in group])),
                "mean_iterations_per_second": float(np.mean([row["iterations_per_second"] for row in group])),
                "mean_mu_ess_per_sec": float(np.mean([row["mu_ess_per_sec"] for row in group])),
                "mean_latent_ess_per_sec": float(np.mean([row["latent_ess_per_sec"] for row in group])),
                "worst_latent_ess_per_sec": float(np.min([row["latent_ess_per_sec"] for row in group])),
                "worst_coordinate_ess": float(np.min([row["coordinate_ess_min"] for row in group])),
                "worst_order_quantile_ess": float(np.min([row["order_quantile_ess_min"] for row in group])),
                "max_projection_residual": float(np.max([row["max_projection_residual"] for row in group])),
                "max_reverse_position_error": float(np.max([row["max_reverse_position_error"] for row in group])),
                "total_projection_failures": int(sum(row["projection_failure_count"] for row in group)),
                "total_reverse_failures": int(sum(row["reverse_check_failure_count"] for row in group)),
            }
        )
    return sorted(
        output,
        key=lambda row: (
            not row["all_production_eligible"],
            -row["worst_latent_ess_per_sec"],
            -row["mean_latent_ess_per_sec"],
        ),
    )


def main() -> None:
    args = parse_args()
    if args.iterations <= args.burn_in or args.burn_in < 0:
        raise ValueError("iterations must exceed a non-negative burn-in")
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    for n in args.n_values:
        for step_size in args.step_sizes:
            for num_steps in args.num_steps:
                for seed in args.seeds:
                    row = _run_one(args, n, seed, step_size, num_steps)
                    rows.append(row)
                    print(
                        f"n={n} seed={seed} eps={step_size:g} L={num_steps} "
                        f"accept={row['x_acceptance_rate']:.3f} "
                        f"latent_ess/sec={row['latent_ess_per_sec']:.2f} "
                        f"eligible={row['production_eligible']}",
                        flush=True,
                    )
    _write_csv(args.out / "seed_results.csv", rows)
    aggregate = _aggregate(rows)
    _write_csv(args.out / "aggregate_results.csv", aggregate)
    for row in aggregate:
        if row["all_production_eligible"]:
            print(
                f"best eligible n={row['n']}: eps={row['step_size']:g}, L={row['num_steps']}, "
                f"latent_ess/sec={row['mean_latent_ess_per_sec']:.2f}",
                flush=True,
            )
            break


if __name__ == "__main__":
    main()
