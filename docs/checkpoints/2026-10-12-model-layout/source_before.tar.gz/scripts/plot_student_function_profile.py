"""Make Gibbs and RATTLE function-level time-split plots from cProfile CSVs.

Example:
    .venv/bin/python scripts/plot_student_function_profile.py \
        --profile-dir results/latest/student_t_function_profile
"""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib-cache")

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


COLORS = {"gibbs": "#1769aa", "rattle": "#c62828", "other": "#8a8a8a"}
LABELS = {
    "loc_student.py:322:run_gibbs_kernel_dispatch": "Numba Gibbs transition",
    "loc_student.py:377:run_gibbs": "Gibbs orchestration",
    "loc_student_rattle.py:350:_rattle_trajectory": "RATTLE trajectory (forward + reverse)",
    "loc_student_rattle.py:440:run_rattle": "RATTLE loop / proposal bookkeeping",
    "loc_student_rattle.py:343:_hamiltonian": "Hamiltonian wrapper",
    "loc_student_rattle.py:334:_potential_energy": "Potential-energy wrapper",
    "_linalg.py:2598:norm": "Reverse-position norm",
    "~:0:<built-in method numpy.asarray>": "NumPy array conversion",
    "serialize.py:30:_numba_unpickle": "Numba dispatcher deserialization",
    "~:0:<method 'dot' of 'numpy.ndarray' objects>": "NumPy dot product",
    "multiarray.py:751:dot": "NumPy dot dispatch",
    "~:0:<built-in method builtins.max>": "Python max",
    "~:0:<built-in method builtins.abs>": "Python abs",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--profile-dir", type=Path, default=Path("results/latest/student_t_function_profile")
    )
    parser.add_argument("--top-functions", type=int, default=10)
    parser.add_argument(
        "--min-share", type=float, default=0.002,
        help="Group functions below this exclusive-time share into Other (default: 0.2%%).",
    )
    parser.add_argument(
        "--comparison-dir",
        type=Path,
        default=Path("results/student_sampler_profile_v1"),
        help="Multi-setup Gibbs/RATTLE comparison directory.",
    )
    return parser.parse_args()


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _label(function: str) -> str:
    if function in LABELS:
        return LABELS[function]
    return function.rsplit(":", 1)[-1].replace("_", " ")


def _is_plot_candidate(function: str) -> bool:
    return "<lambda>" not in function and "Profiler' objects>" not in function


def _model_rows(rows: list[dict[str, str]], method: str) -> list[dict[str, str]]:
    model_names = {
        "loc_student.py",
        "loc_student_rattle.py",
        "student_mu_mh.py",
        "loc_logistic.py",
        "loc_laplace.py",
    }

    def is_model_function(function: str) -> bool:
        return function.startswith("models/") or function.split(":", 1)[0] in model_names

    return sorted(
        [
            row
            for row in rows
            if row["method"] == method
            and is_model_function(row["function"])
            and _is_plot_candidate(row["function"])
        ],
        key=lambda row: float(row["self_seconds"]),
        reverse=True,
    )


def _components(
    rows: list[dict[str, str]], total_seconds: float, top_functions: int, min_share: float
) -> list[tuple[str, float]]:
    usable = [
        (_label(row["function"]), float(row["self_seconds"]))
        for row in rows
        if _is_plot_candidate(row["function"])
        and float(row["self_seconds"]) >= float(total_seconds) * float(min_share)
    ]
    usable.sort(key=lambda item: item[1], reverse=True)
    selected = usable[:top_functions]
    remainder = max(float(total_seconds) - sum(seconds for _, seconds in selected), 0.0)
    if remainder >= float(total_seconds) * float(min_share):
        selected.append(("Other profiled functions", remainder))
    return selected


def _plot(method: str, components: list[tuple[str, float]], total_seconds: float, subtitle: str, out_path: Path) -> None:
    labels = [label for label, _ in components][::-1]
    values = [seconds for _, seconds in components][::-1]
    colors = [COLORS["other"] if label == "Other profiled functions" else COLORS[method] for label in labels]
    height = max(4.5, 0.53 * len(labels) + 1.9)
    fig, axis = plt.subplots(figsize=(11, height), layout="constrained")
    bars = axis.barh(labels, values, color=colors, edgecolor="none")
    max_value = max(values, default=1.0)
    axis.set_xlim(0.0, max_value * 1.22)
    for bar, seconds in zip(bars, values):
        share = 100.0 * seconds / max(total_seconds, 1e-12)
        axis.text(
            bar.get_width() + max_value * 0.015,
            bar.get_y() + bar.get_height() / 2.0,
            f"{seconds:.3f} s  ({share:.1f}%)",
            va="center",
            fontsize=10,
        )
    axis.set_xlabel("exclusive cProfile time (seconds)")
    axis.set_title(f"{method.upper()}: function-level time split", fontsize=15, fontweight="bold", pad=16)
    axis.text(0.0, 1.01, subtitle, transform=axis.transAxes, fontsize=10, color="#404040")
    axis.grid(axis="x", alpha=0.2, linewidth=0.6)
    axis.spines[["top", "right", "left"]].set_visible(False)
    axis.tick_params(axis="y", length=0)
    fig.savefig(out_path, dpi=190)
    plt.close(fig)


def _plot_model_functions(method: str, rows: list[dict[str, str]], total_seconds: float, out_path: Path) -> None:
    labels = [row["function"].replace("models/", "") for row in rows][::-1]
    values = [float(row["self_seconds"]) for row in rows][::-1]
    if not values:
        return
    fig, axis = plt.subplots(figsize=(12, max(4.5, 0.42 * len(labels) + 2.0)), layout="constrained")
    bars = axis.barh(labels, values, color=COLORS[method], edgecolor="none")
    max_value = max(values + [1e-12])
    axis.set_xlim(0.0, max_value * 1.25)
    for bar, seconds in zip(bars, values):
        axis.text(bar.get_width() + max_value * 0.015, bar.get_y() + bar.get_height() / 2.0, f"{seconds:.6f} s", va="center", fontsize=9)
    axis.set_xlabel("exclusive cProfile time (seconds)")
    axis.set_title(f"{method.upper()}: functions defined under models/", fontsize=15, fontweight="bold", pad=28)
    axis.text(0.0, 1.015, f"Total sampler wall time: {total_seconds:.3f} s; compiled Numba internals appear at dispatcher boundaries.", transform=axis.transAxes, fontsize=9, color="#404040")
    axis.grid(axis="x", alpha=0.2, linewidth=0.6)
    axis.spines[["top", "right", "left"]].set_visible(False)
    axis.tick_params(axis="y", length=0)
    fig.savefig(out_path, dpi=190)
    plt.close(fig)


def _plot_comparison(comparison_dir: Path, out_dir: Path) -> list[Path]:
    summary_path = comparison_dir / "student_sampler_profile_summary.csv"
    if not summary_path.is_file():
        return []
    data = pd.read_csv(summary_path)
    data = data[data["method"].isin(["gibbs_numba_full", "rattle"])].copy()
    if data.empty:
        return []
    out_dir.mkdir(parents=True, exist_ok=True)
    data["method_label"] = data["method"].map({"gibbs_numba_full": "Gibbs (numba_full)", "rattle": "RATTLE"})
    metrics = [
        ("iterations_per_sec", "iterations/sec", "iter_per_sec", True),
        ("ess_mu_per_sec_mean", "ESS(μ)/sec", "ess_per_sec", True),
        ("sec_per_iteration_mean", "seconds/iteration", "sec_per_iter", True),
        ("esjd_mu_per_sec_mean", "ESJD(μ)/sec", "esjd_per_sec", True),
    ]
    paths = []
    for metric, ylabel, filename, log_y in metrics:
        if metric == "iterations_per_sec":
            data[metric] = 1.0 / data["sec_per_iteration_mean"]
        if metric not in data:
            continue
        ks = sorted(data["k"].dropna().unique())
        fig, axes = plt.subplots(len(ks), 1, figsize=(9, max(4.2, 3.8 * len(ks))), squeeze=False, layout="constrained")
        for axis, k_value in zip(axes[:, 0], ks):
            part = data[data["k"].eq(k_value)].sort_values("n")
            for method, method_part in part.groupby("method_label"):
                axis.plot(method_part["n"], method_part[metric], marker="o", linewidth=1.8, label=method)
            axis.set_xscale("log")
            if log_y:
                axis.set_yscale("log")
            axis.set_xlabel("n")
            axis.set_ylabel(ylabel)
            axis.set_title(f"k={float(k_value):g}")
            axis.grid(True, which="both", alpha=0.22)
            axis.legend()
        path = out_dir / f"{filename}.png"
        fig.savefig(path, dpi=190)
        plt.close(fig)
        paths.append(path)
    return paths


def main() -> None:
    args = parse_args()
    timing_path = args.profile_dir / "function_timing.csv"
    summary_path = args.profile_dir / "sampler_summary.csv"
    if not timing_path.is_file() or not summary_path.is_file():
        raise FileNotFoundError("profile-dir must contain function_timing.csv and sampler_summary.csv")
    timings = _read_csv(timing_path)
    summaries = {row["method"]: row for row in _read_csv(summary_path)}
    for method in ("gibbs", "rattle"):
        if method not in summaries:
            raise ValueError(f"No sampler summary for {method}")
        summary = summaries[method]
        total = float(summary["elapsed_seconds"])
        rows = [row for row in timings if row["method"] == method]
        subtitle = (
            f"Warmed profile: {total:.3f} s total, {float(summary['iterations_per_second']):,.0f} iterations/s; "
            "bars use exclusive time."
        )
        _plot(
            method,
            _components(rows, total, args.top_functions, args.min_share),
            total,
            subtitle,
            args.profile_dir / f"{method}_function_time_split.png",
        )
        model_rows = _model_rows(timings, method)
        _plot_model_functions(
            method,
            model_rows,
            total,
            args.profile_dir / f"{method}_model_function_time_split.png",
        )
        with (args.profile_dir / "model_function_timing.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=timings[0].keys())
            writer.writeheader()
            writer.writerows([row for row in timings if _model_rows([row], row["method"])])
    comparison_paths = _plot_comparison(args.comparison_dir, args.profile_dir / "comparison_figures")
    print("comparison figures:", ", ".join(str(path) for path in comparison_paths), flush=True)
    print(args.profile_dir, flush=True)


if __name__ == "__main__":
    main()
