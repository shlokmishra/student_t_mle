"""Create and verify a non-destructive repository checkpoint (standard library only).

Run before editing/moving existing files. The destination must be new. Working
files, including ignored research outputs, are hashed and archived. Rebuildable
environments/caches and managed agent settings are explicitly excluded. Git
history and staged/unstaged changes are saved separately; the index is untouched.
"""

import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import tarfile
import time


ROOT_EXCLUSIONS = {".git", ".venv", "venv", ".agents", ".codex"}
CACHE_EXCLUSIONS = {"__pycache__", ".pytest_cache"}


def digest(stream):
    h = hashlib.sha256()
    for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
        h.update(block)
    return h.hexdigest()


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--max-gib", type=float, default=30)
    args = parser.parse_args()
    root, dest = args.root.resolve(), args.destination.resolve()
    if dest == root or root.is_relative_to(dest):
        parser.error("destination must not contain the source root")
    dest.mkdir(parents=True, exist_ok=False)
    started = time.time()
    tracked = set(os.fsdecode(p) for p in git(root, "ls-files", "-z").split(b"\0") if p)
    untracked = set(os.fsdecode(p) for p in git(root, "ls-files", "--others", "--exclude-standard", "-z").split(b"\0") if p)
    for filename, command in {
        "git-status.txt": ("status", "--porcelain=v1", "--untracked-files=all"),
        "unstaged.patch": ("diff", "--binary", "--full-index"),
        "staged.patch": ("diff", "--cached", "--binary", "--full-index"),
        "git-head.txt": ("rev-parse", "HEAD"),
        "git-refs.txt": ("show-ref",),
    }.items():
        (dest / filename).write_bytes(git(root, *command))
    files, excluded, special = [], [], []
    for base, dirs, names in os.walk(root, followlinks=False):
        base = Path(base)
        for name in list(dirs):
            p = base / name
            if (p == dest or name in CACHE_EXCLUSIONS
                    or (base == root and name in ROOT_EXCLUSIONS)):
                excluded.append(str(p.relative_to(root)))
                dirs.remove(name)
            elif p.is_symlink():
                files.append(p)
                dirs.remove(name)
        for name in names:
            p = base / name
            if p.is_symlink() or p.is_file():
                files.append(p)
            else:
                special.append(str(p.relative_to(root)))
    files.sort()
    size = sum(p.lstat().st_size for p in files)
    if special:
        raise RuntimeError(f"Unsupported special files: {special}")
    if size > args.max_gib * 1024**3:
        raise RuntimeError(f"Source size {size} exceeds ceiling; no archive written")
    if shutil.disk_usage(dest).free < 2 * size + 1024**3:
        raise RuntimeError("Insufficient free disk headroom")
    print(f"Preserving {len(files)} entries, {size / 1024**3:.3f} GiB", flush=True)
    rows = []
    with tarfile.open(dest / "worktree.tar", "w", dereference=False) as archive:
        for i, p in enumerate(files):
            rel = p.relative_to(root).as_posix()
            before = p.lstat()
            row = {"path": rel, "bytes": before.st_size,
                   "mode": stat.S_IMODE(before.st_mode), "mtime_ns": before.st_mtime_ns,
                   "git_state": "tracked" if rel in tracked else "untracked" if rel in untracked else "ignored"}
            if p.is_symlink():
                row.update(kind="symlink", link_target=os.readlink(p))
            else:
                with p.open("rb") as stream:
                    row.update(kind="file", sha256=digest(stream))
            archive.add(p, arcname=rel, recursive=False)
            after = p.lstat()
            if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
                raise RuntimeError(f"Source changed while archiving: {rel}")
            rows.append(row)
            if i % 1000 == 0:
                print(f"Archived {i + 1}/{len(files)}", flush=True)
    with (dest / "manifest.jsonl").open("w") as stream:
        for row in rows:
            stream.write(json.dumps(row, sort_keys=True) + "\n")
    expected = {r["path"]: r for r in rows}
    seen = set()
    with tarfile.open(dest / "worktree.tar", "r|") as archive:
        for member in archive:
            row = expected[member.name]
            if member.name in seen:
                raise RuntimeError(f"Duplicate archive member: {member.name}")
            seen.add(member.name)
            if row["kind"] == "symlink":
                assert member.issym() and member.linkname == row["link_target"]
            else:
                assert member.isfile() and member.size == row["bytes"]
                with archive.extractfile(member) as stream:
                    assert digest(stream) == row["sha256"], member.name
            assert member.mode == row["mode"], member.name
    assert seen == expected.keys()
    subprocess.run(["git", "-C", str(root), "bundle", "create", str(dest / "history.bundle"), "--all"], check=True)
    verification = subprocess.run(["git", "-C", str(root), "bundle", "verify", str(dest / "history.bundle")], capture_output=True, text=True, check=True)
    (dest / "bundle-verification.txt").write_text(verification.stdout + verification.stderr)
    groups = collections.defaultdict(lambda: {"entries": 0, "bytes": 0})
    states = collections.Counter()
    for row in rows:
        group = row["path"].split("/")[0] if "/" in row["path"] else "(root)"
        groups[group]["entries"] += 1
        groups[group]["bytes"] += row["bytes"]
        states[row["git_state"]] += 1
    summary = {"root": str(root), "destination": str(dest), "head": git(root, "rev-parse", "HEAD").decode().strip(),
               "started_unix": started, "elapsed_seconds": time.time() - started,
               "entries": len(rows), "bytes": size, "git_states": dict(states),
               "groups": dict(groups), "excluded": sorted(excluded),
               "archive_payload_verified": True, "bundle_verified": True,
               "limitations": ["Same-filesystem checkpoint; not an offsite backup", "Rebuild environment from captured package versions", "Does not preserve empty directories, ACLs, xattrs, or unreachable Git objects"]}
    (dest / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (dest / "SHA256SUMS").open("w") as sums:
        for p in sorted(dest.iterdir()):
            if p.is_file() and p.name != "SHA256SUMS":
                with p.open("rb") as stream:
                    sums.write(f"{digest(stream)}  {p.name}\n")
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
