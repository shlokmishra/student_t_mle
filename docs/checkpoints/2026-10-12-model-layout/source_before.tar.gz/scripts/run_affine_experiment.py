"""Run and compare the standalone local affine-normalization sampler."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/student_t_mle-matplotlib")

import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from kde_ref.moments import posterior_grid_bounds, raw_weighted_posterior_moments
from kde_ref.posterior import get_normalized_posterior_pdf
from models import loc_affine


QUANTILES = np.array([0.025, 0.25, 0.5, 0.75, 0.975])


def _float_list(value):
    return [float(item) for item in value.split(",") if item.strip()]


def effective_sample_size(values):
    values = np.asarray(values, dtype=float)
    values = values[np.isfinite(values)]
    n = values.size
    if n <= 1:
        return float(n)
    centered = values - float(np.mean(values))
    variance = float(np.dot(centered, centered) / n)
    if variance <= 0.0:
        return float(n)
    paired_sum = 0.0
    previous_pair = np.inf
    for lag in range(1, n - 1, 2):
        rho_1 = float(np.dot(centered[:-lag], centered[lag:]) / (n * variance))
        rho_2 = float(np.dot(centered[: -(lag + 1)], centered[lag + 1 :]) / (n * variance))
        pair = rho_1 + rho_2
        if pair <= 0.0:
            break
        pair = min(pair, previous_pair)
        paired_sum += pair
        previous_pair = pair
    return float(max(1.0, min(n, n / (1.0 + 2.0 * paired_sum))))


def _reference_grid(mu_star, params, mle_samples, grid_size):
    posterior_pdf = get_normalized_posterior_pdf(
        mu_star, params, mle_samples, use_grid=True, n_grid=grid_size
    )
    lo, hi = posterior_grid_bounds(
        mu_star, params["prior_mean"], params["prior_std"], mle_samples
    )
    grid = np.linspace(lo, hi, int(grid_size))
    density = np.asarray(posterior_pdf(grid), dtype=float)
    density /= np.trapezoid(density, grid)
    cdf = np.concatenate(
        [[0.0], np.cumsum((density[:-1] + density[1:]) * np.diff(grid) / 2.0)]
    )
    cdf /= cdf[-1]
    mean = float(np.trapezoid(grid * density, grid))
    variance = float(np.trapezoid((grid - mean) ** 2 * density, grid))
    quantiles = np.interp(QUANTILES, cdf, grid)
    return grid, density, cdf, mean, variance, quantiles


def _distribution_distances(chain, grid, cdf):
    ordered = np.sort(np.asarray(chain, dtype=float))
    n = ordered.size
    reference_cdf = np.interp(ordered, grid, cdf, left=0.0, right=1.0)
    upper = np.arange(1, n + 1) / n
    lower = np.arange(0, n) / n
    ks = float(max(np.max(np.abs(upper - reference_cdf)), np.max(np.abs(lower - reference_cdf))))
    probabilities = (np.arange(n) + 0.5) / n
    reference_quantiles = np.interp(probabilities, cdf, grid)
    wasserstein = float(np.mean(np.abs(ordered - reference_quantiles)))
    return ks, wasserstein


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=["normal", "logistic", "student"], default="normal")
    parser.add_argument("--n", type=int, default=20)
    parser.add_argument("--k", type=float, default=3.0)
    parser.add_argument("--known-scale", type=float, default=1.0)
    parser.add_argument("--mu-star", type=float, default=0.0)
    parser.add_argument("--iterations", type=int, default=5000)
    parser.add_argument("--burn-in", type=int, default=1000)
    parser.add_argument("--mle-simulations", type=int, default=20000)
    parser.add_argument("--tau-q-values", type=_float_list, default=[0.05, 0.1, 0.2, 0.4, 0.8])
    parser.add_argument("--proposal-std-mu", type=float, default=0.25)
    parser.add_argument("--prior-mean", type=float, default=0.0)
    parser.add_argument("--prior-std", type=float, default=10.0)
    parser.add_argument("--kde-bw-method", default="scott")
    parser.add_argument("--grid-size", type=int, default=4000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--out", type=Path, default=Path("results/affine_experiment"))
    return parser.parse_args()


def main():
    args = parse_args()
    if args.burn_in < 0 or args.burn_in >= args.iterations:
        raise ValueError("burn-in must lie in [0, iterations)")
    args.out.mkdir(parents=True, exist_ok=True)
    base_params = {
        "model": args.model,
        "n": args.n,
        "k": args.k,
        "known_scale": args.known_scale,
        "num_iterations_T": args.iterations,
        "proposal_std_mu": args.proposal_std_mu,
        "prior_mean": args.prior_mean,
        "prior_std": args.prior_std,
        "kde_bw_method": args.kde_bw_method,
        "store_x_chain": False,
    }

    reference_started = time.perf_counter()
    mle_samples = loc_affine.get_benchmark_mle_samples(
        args.seed, base_params, num_simulations=args.mle_simulations, verbose=True
    )
    reference_seconds = time.perf_counter() - reference_started
    raw_reference = raw_weighted_posterior_moments(
        mle_samples, args.mu_star, args.prior_mean, args.prior_std
    )
    grid, density, cdf, ref_mean, ref_variance, ref_quantiles = _reference_grid(
        args.mu_star, base_params, mle_samples, args.grid_size
    )
    np.savez_compressed(args.out / "reference.npz", mle_samples=mle_samples, mu=grid, density=density)

    rows = []
    chains = {}
    for index, tau_q in enumerate(args.tau_q_values):
        params = {**base_params, "tau_q": tau_q}
        started = time.perf_counter()
        result = loc_affine.run_gibbs(
            args.seed + 1000 + index, args.mu_star, params, verbose=True
        )
        seconds = time.perf_counter() - started
        retained = np.asarray(result["mu_chain"], dtype=float)[args.burn_in + 1 :]
        ess = effective_sample_size(retained)
        chain_quantiles = np.quantile(retained, QUANTILES)
        ks, wasserstein = _distribution_distances(retained, grid, cdf)
        rows.append(
            {
                "model": args.model,
                "n": args.n,
                "k": args.k if args.model == "student" else np.nan,
                "tau_q": tau_q,
                "latent_proposal": result["latent_proposal"],
                "iterations": args.iterations,
                "burn_in": args.burn_in,
                "wall_time_sec": seconds,
                "iterations_per_sec": args.iterations / seconds,
                "mu_ess": ess,
                "mu_ess_per_sec": ess / seconds,
                "latent_acceptance_rate": result["latent_acceptance_rate"],
                "mu_acceptance_rate": result["mu_acceptance_rate"],
                "max_mle_residual": result["max_mle_residual"],
                "posterior_mean": float(np.mean(retained)),
                "posterior_sd": float(np.std(retained, ddof=1)),
                "reference_mean": ref_mean,
                "reference_sd": float(np.sqrt(ref_variance)),
                "raw_reference_mean": raw_reference["posterior_mean"],
                "raw_reference_sd": raw_reference["posterior_sd"],
                "raw_reference_q025": raw_reference["posterior_q025"],
                "raw_reference_q500": raw_reference["posterior_q50"],
                "raw_reference_q975": raw_reference["posterior_q975"],
                "ks_distance": ks,
                "wasserstein_distance": wasserstein,
                **{f"posterior_q{int(1000*q):03d}": value for q, value in zip(QUANTILES, chain_quantiles)},
                **{f"reference_q{int(1000*q):03d}": value for q, value in zip(QUANTILES, ref_quantiles)},
            }
        )
        chains[f"tau_q_{tau_q:g}"] = result["mu_chain"]

    summary = pd.DataFrame(rows)
    summary.to_csv(args.out / "summary.csv", index=False)
    np.savez_compressed(args.out / "chains.npz", **chains)
    metadata = {**vars(args), "out": str(args.out), "reference_wall_time_sec": reference_seconds}
    (args.out / "metadata.json").write_text(json.dumps(metadata, indent=2, sort_keys=True) + "\n")

    figure, axis = plt.subplots(figsize=(8, 5))
    axis.plot(grid, density, color="black", linewidth=2.0, label="selected-MLE KDE reference")
    for key, chain in chains.items():
        retained = np.asarray(chain)[args.burn_in + 1 :]
        axis.hist(retained, bins=50, density=True, histtype="step", linewidth=1.2, label=key.replace("_", " "))
    axis.set_xlabel("mu")
    axis.set_ylabel("density")
    axis.set_title(f"Affine-normalization sampler: {args.model}, n={args.n}")
    axis.legend()
    figure.tight_layout()
    figure.savefig(args.out / "posterior_overlay.png", dpi=180)
    plt.close(figure)
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
