"""Build portable inventory/dependency tables from a preservation manifest.

Static literal/import matches are leads for review, not complete runtime graphs.
No numerical model is imported and no original experiment output is modified.
"""

import argparse
import ast
import collections
import csv
import json
from pathlib import Path


def write_csv(path, fields, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    args.out.mkdir(parents=True, exist_ok=True)
    entries = [json.loads(line) for line in (args.checkpoint / "manifest.jsonl").read_text().splitlines()]
    paths = {row["path"] for row in entries}
    modules = {str(Path(p).with_suffix("")).replace("/", "."): p for p in paths if p.endswith(".py")}
    local_roots = {"models", "kde_ref", "diagnostics", "reporting", "scripts", "dashboard", "analysis"}
    source_roots = local_roots | {"tests", "docs", "configs", "hpc"}
    imports, literals, errors = [], [], []
    for row in entries:
        rel = row["path"]
        if rel.split("/")[0] not in source_roots:
            continue
        p = root / rel
        if p.suffix not in {".py", ".md", ".tex", ".yaml", ".json", ".sbatch", ".sh"}:
            continue
        content = p.read_text(errors="replace")
        if p.suffix == ".py":
            try:
                tree = ast.parse(content)
            except SyntaxError as exc:
                errors.append({"path": rel, "error": str(exc)})
                continue
            for node in ast.walk(tree):
                names = []
                if isinstance(node, ast.Import):
                    names = [a.name for a in node.names]
                elif isinstance(node, ast.ImportFrom):
                    package = rel.split("/")[:-1]
                    prefix = ".".join(package[:len(package) - node.level + 1]) if node.level else ""
                    base = ".".join(s for s in [prefix, node.module] if s)
                    names = [base] + [base + "." + a.name for a in node.names]
                for name in sorted(set(names)):
                    if name.split(".")[0] in local_roots:
                        target = modules.get(name, modules.get(name + ".__init__", ""))
                        if target or name in local_roots:
                            imports.append({"source": rel, "line": node.lineno, "import": name,
                                            "resolved_file": target, "kind": "static_import"})
        # Include path fragments so constructed paths are visible to a reviewer.
        for line_number, line in enumerate(content.splitlines(), 1):
            if any(marker in line for marker in ("results", "tmp/", "evidence/", "diagnostic_outputs", "includegraphics", "graphicspath", "_archive_")):
                literals.append({"source": rel, "line": line_number, "text": line.strip(),
                                 "status": "literal_or_fragment_requires_review"})
    write_csv(args.out / "local_imports.csv", ["source", "line", "import", "resolved_file", "kind"], imports)
    write_csv(args.out / "artifact_literals.csv", ["source", "line", "text", "status"], literals)
    fields = ["path", "bytes", "git_state", "kind", "sha256", "link_target"]
    write_csv(args.out / "preservation_manifest.csv", fields,
              [{key: row.get(key, "") for key in fields} for row in entries])
    groups = collections.defaultdict(lambda: {"entries": 0, "bytes": 0})
    for row in entries:
        group = row["path"].split("/")[0] if "/" in row["path"] else "(root)"
        groups[group]["entries"] += 1
        groups[group]["bytes"] += row["bytes"]
    write_csv(args.out / "directory_inventory.csv", ["directory", "entries", "bytes"],
              [dict(directory=key, **value) for key, value in sorted(groups.items())])
    runs = collections.defaultdict(lambda: {"entries": 0, "bytes": 0})
    for row in entries:
        parts = Path(row["path"]).parts
        if len(parts) < 2 or parts[0] not in {"results", "tmp"}:
            continue
        # Preserve the separate latest/* studies as independent run groups.
        depth = 3 if len(parts) > 3 and parts[:2] == ("results", "latest") else 2
        group = "/".join(parts[:depth])
        runs[group]["entries"] += 1
        runs[group]["bytes"] += row["bytes"]
    run_rows = []
    for group, values in sorted(runs.items()):
        if any(s in group for s in ("student_n3", "student_mle_transition", "student_global_mle", "student_score_vs")):
            disposition = "retain_for_n3_and_selector_reconciliation"
        elif any(s in group for s in ("student_latent", "student_acceptance", "student_sampler_profile", "student_t_function_profile")):
            disposition = "retain_supporting_tuning_or_diagnostic_evidence"
        elif group == "tmp/presentation_long_chains":
            disposition = "retain_scientific_arrays_linked_to_presentation_evidence"
        else:
            disposition = "historical_artifact_review_before_indexed_archival"
        run_rows.append(dict(path=group, **values, proposed_disposition=disposition,
                             provenance_status="see_ledger_or_unreconciled", action_taken="preserved_in_place_and_archive"))
    write_csv(args.out / "artifact_runs.csv", ["path", "entries", "bytes", "proposed_disposition", "provenance_status", "action_taken"], run_rows)
    (args.out / "inventory_validation.json").write_text(json.dumps({
        "manifest_entries": len(entries), "unique_paths": len(paths),
        "local_import_edges": len(imports), "artifact_literal_lines": len(literals),
        "parse_errors": errors, "scope": "source paths present in preservation manifest",
        "limitations": "Static imports and textual path fragments; dynamic paths need manual review"
    }, indent=2) + "\n")
    print(f"Inventoried {len(entries)} files; {len(imports)} local imports; {len(literals)} artifact references")


if __name__ == "__main__":
    main()
