"""Prepare lightweight figures for the n=3 Gibbs--RATTLE discussion note.

This script only reads existing audit outputs and exact chamber-graph objects. It
does not run either sampler.  Each figure is written as both PNG and PDF.
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, Normalize
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from reporting.diagnostics.verify_student_n3_components import (  # noqa: E402
    chamber_graph,
    chamber_name,
    connected_components,
    predicted_mle,
)

RESULTS = REPO_ROOT / "results" / "student_n3_branch_components_clean"
GRID_RESULTS = REPO_ROOT / "results"

MLE_COLOR = "#287d5a"
NON_MLE_COLOR = "#c44e52"
GIBBS_COLOR = "#3b6fb6"
RATTLE_COLOR = "#d4862f"
NEUTRAL = "#555555"


def _rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def _save(fig: plt.Figure, out: Path, stem: str) -> None:
    for suffix in (".png", ".pdf"):
        fig.savefig(out / f"{stem}{suffix}", dpi=220, bbox_inches="tight")
    plt.close(fig)


def _hexagon(axis: plt.Axes) -> None:
    vertices = np.asarray([(1, 0), (1, -1), (0, -1), (-1, 0), (-1, 1), (0, 1), (1, 0)])
    axis.plot(vertices[:, 0], vertices[:, 1], color="black", linewidth=0.8)


def plot_branch_sheet_map(out: Path) -> None:
    rows = _rows(RESULTS / "branch_sheet_map.csv")
    branches = [f"{value:03b}" for value in range(8)]
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        grouped[str(row["branch"]).zfill(3)].append(row)

    fig, axes = plt.subplots(2, 4, figsize=(10.8, 5.4), sharex=True, sharey=True)
    cmap = ListedColormap([NON_MLE_COLOR, MLE_COLOR])
    for axis, branch in zip(axes.flat, branches):
        selected = grouped[branch]
        axis.scatter(
            [float(row["u1"]) for row in selected],
            [float(row["u2"]) for row in selected],
            c=[int(row["mle_indicator"]) for row in selected],
            cmap=cmap,
            vmin=-0.5,
            vmax=1.5,
            s=4,
            linewidths=0,
            rasterized=True,
        )
        _hexagon(axis)
        axis.axhline(0, color="0.8", linewidth=0.45)
        axis.axvline(0, color="0.8", linewidth=0.45)
        axis.plot([-1, 1], [1, -1], color="0.8", linewidth=0.45)
        axis.set_title(f"branch code {branch}", fontsize=10)
        axis.set_aspect("equal")
        axis.set_xlim(-1.05, 1.05)
        axis.set_ylim(-1.05, 1.05)
    for axis in axes[-1]:
        axis.set_xlabel(r"$u_1=2\sqrt{k}z_1$")
    for axis in axes[:, 0]:
        axis.set_ylabel(r"$u_2=2\sqrt{k}z_2$")
    handles = [
        plt.Line2D([], [], marker="o", linestyle="", color=MLE_COLOR, label="MLE-valid"),
        plt.Line2D([], [], marker="o", linestyle="", color=NON_MLE_COLOR, label="non-MLE"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=2, frameon=False, bbox_to_anchor=(0.5, 0.075))
    fig.text(
        0.5,
        0.038,
        r"Branch code: 0 = inner, 1 = outer; $u_3=-u_1-u_2$.",
        ha="center",
        fontsize=9.5,
    )
    fig.text(
        0.5,
        0.010,
        r"White $z_i=0$ cuts on outer sheets represent $|x_i|\to\infty$ ends, not finite connections.",
        ha="center",
        fontsize=9.5,
    )
    fig.suptitle("Same score hexagon, different inverse-branch sheets", fontsize=13)
    fig.tight_layout(rect=(0, 0.13, 1, 0.95))
    _save(fig, out, "hexagon_branch_sheet_mle_map")


def plot_component_graph(out: Path) -> None:
    graph = chamber_graph()
    components = connected_components(graph)
    central = components[0]
    hub = next(node for node in central if sum(node[0]) == 0)
    rim = central - {hub}
    # Removing the all-inner hub leaves a 12-cycle.  Lay that cycle out on a
    # circle so the finite-fold edges do not cross.
    rim_graph = {node: sorted(graph[node] & rim, key=chamber_name) for node in rim}
    start = min(rim, key=chamber_name)
    cycle = [start]
    previous = None
    current = start
    while len(cycle) < len(rim):
        candidates = [node for node in rim_graph[current] if node != previous]
        next_node = next((node for node in candidates if node not in cycle), candidates[0])
        cycle.append(next_node)
        previous, current = current, next_node

    positions = {hub: (1.9, 0.0)}
    for index, node in enumerate(cycle):
        angle = math.pi / 2.0 - 2.0 * math.pi * index / len(cycle)
        positions[node] = (1.9 + 2.05 * math.cos(angle), 2.05 * math.sin(angle))

    tails = components[1:]
    for index, component in enumerate(tails):
        ordered = sorted(component, key=lambda node: sum(node[0]))
        column = index // 3
        row = index % 3
        y = 1.85 - 1.85 * row
        left_x = 5.05 + 2.15 * column
        positions[ordered[0]] = (left_x, y)
        positions[ordered[1]] = (left_x + 1.05, y)

    fig, axis = plt.subplots(figsize=(12.2, 6.2))
    for left, neighbors in graph.items():
        for right in neighbors:
            if chamber_name(left) >= chamber_name(right):
                continue
            x1, y1 = positions[left]
            x2, y2 = positions[right]
            axis.plot([x1, x2], [y1, y2], color="0.72", linewidth=1.0, zorder=1)
    for node, (x, y) in positions.items():
        color = MLE_COLOR if predicted_mle(node) else NON_MLE_COLOR
        axis.text(
            x,
            y,
            chamber_name(node),
            ha="center",
            va="center",
            color="white",
            fontsize=7.5,
            zorder=3,
            bbox={"boxstyle": "round,pad=0.30", "facecolor": color, "edgecolor": "white"},
        )

    for index, component in enumerate(tails):
        non_all_outer = next(node for node in component if sum(node[0]) == 2)
        inner_coordinate = non_all_outer[0].index(0) + 1
        outer_sign = "+" if next(sign for bit, sign in zip(*non_all_outer) if bit) > 0 else "-"
        column = index // 3
        row = index % 3
        axis.text(5.57 + 2.15 * column, 2.22 - 1.85 * row, rf"$\mathcal{{C}}_{{{inner_coordinate},{outer_sign}}}$", ha="center", color=NON_MLE_COLOR, fontsize=10, weight="bold")

    axis.text(1.9, 2.68, r"$\mathcal{C}_0$: 13 chambers, MLE-valid", ha="center", color=MLE_COLOR, weight="bold")
    axis.text(6.63, 2.68, "six tail components (2 chambers each), non-MLE", ha="center", color=NON_MLE_COLOR, weight="bold")
    axis.text(4.25, -2.82, r"No finite edge: apparent contact requires $z_i\to0$, $|x_i|\to\infty$", ha="center", fontsize=9.5)
    axis.text(4.25, -3.16, r"Label key: 0 = inner, 1 = outer; +/− = outer sign; . = inner coordinate", ha="center", fontsize=9.5)
    axis.set_xlim(-0.6, 8.25)
    axis.set_ylim(-3.35, 3.05)
    axis.axis("off")
    fig.suptitle("Finite-fold adjacency: 25 chambers form exactly 7 components", fontsize=14)
    _save(fig, out, "chamber_component_connectivity")


def plot_restart_trapping(out: Path) -> None:
    rows = _rows(RESULTS / "rattle_restart_summary.csv")
    fig, axes = plt.subplots(1, 3, figsize=(10.8, 3.7), sharey=True)
    rng = np.random.default_rng(731)
    for axis, k in zip(axes, (1.0, 2.0, 3.0)):
        selected = [row for row in rows if float(row["k"]) == k]
        for x, kind, color, label in (
            (0, "gibbs_mle_restart", MLE_COLOR, "MLE start"),
            (1, "gibbs_non_mle_restart", NON_MLE_COLOR, "non-MLE start"),
        ):
            values = [float(row["outside_occupancy"]) for row in selected if row["initial_kind"] == kind]
            jitter = rng.uniform(-0.10, 0.10, len(values))
            axis.scatter(x + jitter, values, s=30, color=color, alpha=0.85, label=label)
        accept = [float(row["x_acceptance_rate"]) for row in selected]
        central_count = sum(row["initial_kind"] == "gibbs_mle_restart" for row in selected)
        tail_count = sum(row["initial_kind"] == "gibbs_non_mle_restart" for row in selected)
        axis.text(
            0.5,
            0.49,
            f"{central_count} central + {tail_count} tail chains\n"
            f"acceptance {min(accept):.3f}–{max(accept):.3f}\n"
            "0 projection/reverse failures",
            ha="center",
            va="center",
            fontsize=8.6,
        )
        axis.set_title(f"k={int(k)}")
        axis.set_xticks([0, 1], ["central-component\nstart", "tail-component\nstart"])
        axis.grid(axis="y", color="0.9")
    axes[0].set_ylabel("fraction of retained states\nin non-MLE components")
    fig.suptitle("RATTLE retains the component of its exact initial state", fontsize=13)
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    _save(fig, out, "rattle_exact_restart_trapping")


def plot_likelihood_exit(out: Path) -> None:
    rows = _rows(RESULTS / "likelihood_curves.csv")
    event_id = "Gibbs k=2, seed=0 exit"
    selected = [row for row in rows if row["event_id"] == event_id]
    fig, axis = plt.subplots(figsize=(6.6, 4.0))
    for state, color, style in (("before", MLE_COLOR, "-"), ("after", NON_MLE_COLOR, "--")):
        subset = [row for row in selected if row["state"] == state]
        axis.plot(
            [float(row["mu"]) for row in subset],
            [float(row["relative_loglik"]) for row in subset],
            style,
            color=color,
            linewidth=2.0,
            label=state,
        )
    axis.axvline(0, color="black", linewidth=0.9, linestyle=":", label=r"released root $\mu^*=0$")
    after_rows = [row for row in selected if row["state"] == "after"]
    stationary_y = float(min(after_rows, key=lambda row: abs(float(row["mu"])))["relative_loglik"])
    axis.annotate(
        "$\\mu^*=0$ remains stationary,\n"
        "but is no longer the global maximum",
        xy=(0.0, stationary_y),
        xytext=(0.75, -2.4),
        arrowprops={"arrowstyle": "->", "color": NEUTRAL},
        fontsize=9,
        color=NEUTRAL,
    )
    axis.set_xlabel(r"location $\mu$")
    axis.set_ylabel("log likelihood (each curve shifted to max = 0)")
    axis.set_title("A Gibbs branch switch preserves score zero\nbut changes the global MLE (k=2, n=3)")
    axis.grid(color="0.9")
    axis.legend(frameon=False)
    _save(fig, out, "gibbs_exit_likelihood")


def plot_merge_gap(out: Path) -> None:
    rows = _rows(RESULTS / "branch_switch_events.csv")
    fig, axis = plt.subplots(figsize=(6.8, 4.2))
    for method, color, label in (("gibbs", GIBBS_COLOR, "Gibbs"), ("rattle", RATTLE_COLOR, "RATTLE")):
        values = np.sort(np.asarray([
            max(float(row["min_normalized_endpoint_merge_gap"]), 1e-7)
            for row in rows if row["method"] == method
        ]))
        cdf = np.arange(1, values.size + 1) / values.size
        axis.plot(values, cdf, color=color, linewidth=2.2, label=f"{label} (N={values.size:,})")
        median = float(np.median(values))
        axis.scatter([median], [0.5], color=color, s=35, zorder=3)
        median_label = f"{100.0 * median:.3g}%"
        axis.text(
            median,
            0.44 if method == "gibbs" else 0.56,
            f"{label} median {median_label}",
            color=color,
            ha="center",
            fontsize=9,
        )
    axis.set_xscale("log")
    axis.set_xlabel(r"normalized endpoint gap to merge, $||z_i|-z_{\max}|/z_{\max}$")
    axis.set_ylabel(r"fraction of switches with gap $\leq x$ (empirical CDF)")
    axis.set_title("RATTLE branch switches occur almost exclusively near finite merges")
    axis.grid(color="0.9", which="both")
    axis.legend(frameon=False, loc="lower right")
    _save(fig, out, "branch_switch_merge_gap")


def _grid_rows() -> dict[tuple[str, float, int], dict[str, str]]:
    paths = [
        GRID_RESULTS / "student_mle_transition_grid_k123_n3_10_20_50" / "summary.csv",
        GRID_RESULTS / "student_mle_transition_grid_remaining_k23" / "summary.csv",
        GRID_RESULTS / "student_mle_transition_grid_k1_refined" / "summary.csv",
        GRID_RESULTS / "student_mle_transition_grid_n3_refined" / "summary.csv",
    ]
    result: dict[tuple[str, float, int], dict[str, str]] = {}
    for path in paths:
        for row in _rows(path):
            result[(row["method"], float(row["k"]), int(row["n"]))] = row
    return result


def plot_exit_grid(out: Path) -> None:
    rows = _grid_rows()
    ks = (1.0, 2.0, 3.0)
    ns = (3, 10, 20, 50)
    matrices: dict[tuple[str, str], np.ndarray] = {}
    for method in ("gibbs", "rattle"):
        for field in ("outside_occupancy", "mle_exit_probability"):
            matrices[(method, field)] = np.asarray(
                [[100 * float(rows[(method, k, n)][field]) for n in ns] for k in ks]
            )
    norms = {
        "outside_occupancy": Normalize(
            vmin=0.0,
            vmax=max(float(np.max(matrices[(method, "outside_occupancy")])) for method in ("gibbs", "rattle")),
        ),
        "mle_exit_probability": Normalize(
            vmin=0.0,
            vmax=max(float(np.max(matrices[(method, "mle_exit_probability")])) for method in ("gibbs", "rattle")),
        ),
    }
    fig, axes = plt.subplots(2, 2, figsize=(8.4, 6.25), sharex=True, sharey=True)
    images = {}
    for row_index, method in enumerate(("gibbs", "rattle")):
        for col_index, (field, title) in enumerate((
            ("outside_occupancy", "non-MLE occupancy"),
            ("mle_exit_probability", "exit probability | MLE"),
        )):
            matrix = matrices[(method, field)]
            axis = axes[row_index, col_index]
            image = axis.imshow(matrix, norm=norms[field], cmap="YlOrRd", aspect="auto")
            images[field] = image
            for i in range(len(ks)):
                for j in range(len(ns)):
                    value = matrix[i, j]
                    label = "0 obs." if value == 0.0 else (f"{value:.1f}" if value >= 0.05 else "<0.1")
                    axis.text(j, i, label, ha="center", va="center", fontsize=8.5)
            method_label = "Gibbs" if method == "gibbs" else "RATTLE"
            axis.set_title(f"{method_label}: {title}")
            axis.set_xticks(range(len(ns)), ns)
            axis.set_yticks(range(len(ks)), [int(k) for k in ks])
    for col_index, field in enumerate(("outside_occupancy", "mle_exit_probability")):
        fig.colorbar(images[field], ax=axes[:, col_index], fraction=0.035, pad=0.03, label="percent")
    for axis in axes[-1]:
        axis.set_xlabel("n")
    for axis in axes[:, 0]:
        axis.set_ylabel("k")
    fig.suptitle("Where score-zero states fail the global-MLE check", fontsize=13)
    fig.text(
        0.5,
        0.015,
        r"For $n=3$, RATTLE chains were initialized in the central MLE-valid component; zeros are component-conditional observations.",
        ha="center",
        fontsize=9,
    )
    fig.subplots_adjust(left=0.08, right=0.90, bottom=0.12, top=0.88, wspace=0.30, hspace=0.28)
    _save(fig, out, "exit_occupancy_grid")


def write_summary_numbers(out: Path) -> None:
    rows = _rows(GRID_RESULTS / "student_mle_transition_grid_n3_refined" / "summary.csv")
    fields = [
        "method", "k", "n", "transitions", "outside_occupancy", "mle_exit_count",
        "mle_exit_probability", "mean_score_sjd_all", "mean_score_sjd_exits",
        "fraction_exits_with_branch_switch",
    ]
    with (out / "n3_main_numbers.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row[field] for field in fields})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--out",
        type=Path,
        default=REPO_ROOT / "results" / "student_n3_discussion_note" / "figures",
    )
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    plot_branch_sheet_map(args.out)
    plot_component_graph(args.out)
    plot_restart_trapping(args.out)
    plot_likelihood_exit(args.out)
    plot_merge_gap(args.out)
    plot_exit_grid(args.out)
    write_summary_numbers(args.out.parent)
    print(f"wrote discussion figures to {args.out}")


if __name__ == "__main__":
    main()
