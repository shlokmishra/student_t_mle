"""Final comparison reporting utilities."""

