"""Prospectively specified talk evidence, isolated from production samplers."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
import numpy as np
from models import loc_student, loc_student_rattle
from models.student_location_mle import global_mle

OUT = ROOT / "docs/presentation/evidence/long_chain_study"
RAW = ROOT / "tmp/presentation_long_chains"


def provenance():
    paths = [Path(__file__), OUT / "protocol.json"]
    paths += [ROOT / "models" / name for name in (
        "loc_student.py", "loc_student_rattle.py", "student_location_mle.py",
        "student_mu_mh.py", "numba_math.py")]
    return {"host": socket.gethostname(), "job": os.getenv("SLURM_JOB_ID"),
            "sha256": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                       for p in paths}}


def main(task):
    protocol = json.loads((OUT / "protocol.json").read_text())
    RAW.mkdir(parents=True, exist_ok=True)
    info = provenance()
    if task == 4:
        rng = np.random.default_rng(protocol["reference_seed"])
        data = rng.standard_t(protocol["k"], (protocol["reference_datasets"], protocol["n"]))
        global_mle(data[0], protocol["k"])
        start = time.perf_counter()
        estimates = np.array([global_mle(x, protocol["k"]) for x in data])
        assert np.isfinite(estimates).all()
        np.savez_compressed(OUT / "reference.npz", mle=estimates)
        info.update(seconds=time.perf_counter()-start, count=len(estimates),
                    estimator="models.student_location_mle.global_mle; certified stationary enumeration")
        (OUT / "reference.json").write_text(json.dumps(info, indent=2)+"\n")
        print(json.dumps(info), flush=True)
        return
    seed = protocol["seeds"][task]
    key = np.array([0, seed], dtype=np.uint32)
    params = {key: protocol[key] for key in (
        "n", "k", "prior_mean", "prior_std", "proposal_std_mu", "proposal_std_z",
        "rattle_step_size", "rattle_num_steps", "reverse_check",
        "rattle_include_gram_correction", "rattle_projection_mode")}
    params.update(num_iterations_T=protocol["iterations"],
                  initialization=protocol["initializations"][task], initialization_seed=seed,
                  store_x_chain=True, gibbs_backend="numba_full")
    initial = loc_student._initial_x(0.0, protocol["n"], protocol["k"], params)
    assert np.array_equal(initial, loc_student_rattle._initial_x(0.0, protocol["n"], protocol["k"], params))
    methods = [("gibbs", loc_student.run_gibbs), ("rattle", loc_student_rattle.run_rattle)]
    if task % 2:
        methods.reverse()
    for name, run in methods:
        if (OUT / f"{name}_{seed}.json").exists():
            print(f"Already saved {name}, seed {seed}", flush=True)
            continue
        run(key, 0.0, dict(params, num_iterations_T=2000), verbose=False)
        print(f"Warmed {name}, seed {seed}; starting {protocol['iterations']} iterations", flush=True)
        start = time.perf_counter()
        result = run(key, 0.0, params, verbose=False)
        seconds = time.perf_counter()-start
        mu, x = np.asarray(result.pop("mu_chain")), np.asarray(result.pop("x_chain"))
        assert len(mu) == len(x) == protocol["iterations"]+1
        assert np.isfinite(mu).all() and np.isfinite(x).all()
        residual = np.abs(np.sum(x/(protocol["k"]+x*x), axis=1))
        assert residual.max() < 1e-8
        keep = slice(protocol["burn_in"]+1, None)
        indices = np.linspace(protocol["burn_in"]+1, len(mu)-1,
                              protocol["audit_states_per_chain"], dtype=int)
        selected = np.array([global_mle(x[i], protocol["k"]) for i in indices])
        latent = np.quantile(x[keep], [.5, .95], axis=1).T
        raw_path = RAW / f"{name}_{seed}.npz"
        if raw_path.exists():
            with np.load(raw_path) as previous:
                assert np.array_equal(previous["mu"], mu) and np.array_equal(previous["x"], x)
            print("Exact replay matches arrays saved before metadata export failed", flush=True)
        np.savez_compressed(raw_path, mu=mu, x=x)
        np.savez_compressed(OUT / f"{name}_{seed}_summaries.npz", mu=mu[keep],
                            median=latent[:, 0], q95=latent[:, 1],
                            audit_indices=indices, audit_selected_mle=selected,
                            initial_x=initial)
        result.update(info, method=name, seed=seed, params=params, elapsed_seconds=seconds,
                      max_score_residual=float(residual.max()),
                      selected_mle_mismatch_fraction=float(np.mean(np.abs(selected) > 1e-6)))
        result.pop("x_final", None)
        (OUT / f"{name}_{seed}.json").write_text(json.dumps(result, indent=2)+"\n")
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", type=int, choices=range(5), required=True)
    main(parser.parse_args().task)
