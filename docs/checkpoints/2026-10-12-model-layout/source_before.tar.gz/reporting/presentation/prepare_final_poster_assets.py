"""Vector poster figures from the frozen long-chain study; no new MCMC."""

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import trapezoid
from scipy.stats import gaussian_kde, norm

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "docs/presentation/evidence/long_chain_study"
OUT = ROOT / "docs/presentation/Images/latex_poster"
REVIEW = ROOT / "tmp/poster_final_review"
INK, TEAL, CORAL, BG, LINE = "#203330", "#17675F", "#934C48", "#F6F8F7", "#BACBC6"
METHODS = [("gibbs", "Gibbs", TEAL), ("rattle", "RATTLE", CORAL)]


def style(ax, axis="y"):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis=axis, color=LINE, lw=.7)
    ax.set_axisbelow(True)


def save(fig, name):
    fig.savefig(OUT / f"{name}.pdf")
    fig.savefig(REVIEW / f"{name}.png", dpi=110)
    plt.close(fig)


def figures():
    OUT.mkdir(parents=True, exist_ok=True)
    REVIEW.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "STIXGeneral", "mathtext.fontset": "stix",
        "font.size": 26, "text.color": INK, "axes.labelcolor": INK,
        "axes.edgecolor": LINE, "xtick.color": INK, "ytick.color": INK,
        "figure.facecolor": BG, "axes.facecolor": BG, "savefig.facecolor": BG,
        "pdf.fonttype": 42})
    summary = json.loads((EVIDENCE / "summary.json").read_text())
    protocol, stats = summary["protocol"], summary["methods"]
    assert (protocol["k"], protocol["n"], protocol["iterations"], protocol["burn_in"]) == (2, 10, 200000, 40000)
    inputs = [EVIDENCE / "summary.json", EVIDENCE / "reference.npz"]
    arrays = {}
    for method, _, _ in METHODS:
        paths = [EVIDENCE / f"{method}_{seed}_summaries.npz" for seed in protocol["seeds"]]
        inputs.extend(paths)
        arrays[method] = np.stack([np.load(path)["mu"] for path in paths])
        assert arrays[method].shape == (4, 160000)
        np.testing.assert_allclose(np.quantile(arrays[method], [.025, .5, .975]),
                                   stats[method]["summaries"]["mu"]["quantiles"], atol=1e-12)
    hashes = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in inputs}

    # Cache only derived plotting grids, keyed by every input file's content.
    cache, provenance = REVIEW / "density_curves.npz", REVIEW / "figure_provenance.json"
    if cache.exists() and provenance.exists() and json.loads(provenance.read_text())["sha256"] == hashes:
        curves = dict(np.load(cache))
    else:
        grid = np.linspace(-2.5, 2.5, 501)
        bank = np.load(EVIDENCE / "reference.npz")["mle"]
        reference = gaussian_kde(bank)
        wide = np.linspace(-40, 40, 8001)
        normalizer = trapezoid(norm.pdf(wide, 0, 10)*reference(-wide), wide)
        curves = {"grid": grid, "kde": norm.pdf(grid, 0, 10)*reference(-grid)/normalizer}
        for method, _, _ in METHODS:
            curves[method] = gaussian_kde(arrays[method].ravel())(grid)
        np.savez(cache, **curves)

    fig, axs = plt.subplots(1, 2, figsize=(14.2, 5.0), gridspec_kw={"width_ratios": [1.5, 1]})
    fig.subplots_adjust(left=.095, right=.985, bottom=.22, top=.76, wspace=.38)
    for method, name, color in METHODS:
        axs[0].plot(curves["grid"], curves[method], lw=3, color=color, label=name)
    axs[0].plot(curves["grid"], curves["kde"], lw=2.6, ls="--", color=INK, label="Selected-MLE KDE")
    axs[0].set(xlabel=r"Population center $\mu$", ylabel="Probability density", xlim=(-2.5, 2.5), ylim=(0, 1.12))
    axs[0].set_xticks([-2, -1, 0, 1, 2])
    axs[0].set_yticks([0, .5, 1])
    fig.legend(*axs[0].get_legend_handles_labels(), loc="upper center", ncol=3,
               bbox_to_anchor=(.52, .99), frameon=False, fontsize=25,
               handlelength=1.7, columnspacing=1.0)
    quantiles = [stats[m]["summaries"]["mu"]["quantiles"] for m, _, _ in METHODS]
    quantiles.append(summary["reference"]["1.0"]["quantiles"])
    for y, color, (lo, med, hi) in zip([2, 1, 0], [TEAL, CORAL, INK], quantiles):
        axs[1].plot([lo, hi], [y, y], color=color, lw=4, solid_capstyle="butt")
        axs[1].scatter(med, y, color=color, s=75, zorder=3)
    axs[1].set(yticks=[2, 1, 0], yticklabels=["Gibbs", "RATTLE", "KDE"],
               ylim=(-.65, 2.65), xlim=(-1.2, 1.2), xlabel=r"95% interval for $\mu$")
    axs[1].set_xticks([-1, 0, 1])
    for ax in axs:
        style(ax)
    save(fig, "posterior_long")

    fig = plt.figure(figsize=(14.2, 5.1))
    cost = fig.add_axes([.12, .23, .23, .49])
    rate = fig.add_axes([.615, .23, .355, .49])
    fig.text(.02, .91, "Cost per sweep", fontsize=29, weight="bold")
    fig.text(.02, .80, "Lower is better", fontsize=24, color=TEAL)
    fig.text(.435, .91, "Bulk ESS per second", fontsize=29, weight="bold")
    fig.text(.435, .80, "Higher is better", fontsize=24, color=TEAL)
    times = [1000*stats[m]["ms_per_iteration"] for m, _, _ in METHODS]
    cost.barh([1, 0], times, color=[TEAL, CORAL], height=.45)
    cost.set(yticks=[1, 0], yticklabels=["Gibbs", "RATTLE"], xlabel="Microseconds",
             xticks=[0, 20, 40, 60], xlim=(0, 60), ylim=(-.5, 1.5))
    for y, value, color in zip([1, 0], times, [TEAL, CORAL]):
        cost.text(value+1.5, y, f"{value:.1f}", va="center", color=color, fontsize=25)
    rates = {}
    for y, key in zip([2, 1, 0], ["mu", "median", "q95"]):
        values = [stats[m]["summaries"][key]["bulk_ess_per_second"] for m, _, _ in METHODS]
        rates[key] = values
        rate.plot(values, [y, y], color=LINE, lw=2.5)
        for (method, name, color), value in zip(METHODS, values):
            rate.scatter(value, y, color=color, marker="o" if method == "gibbs" else "s", s=85)
            label = f"{value/1000:.0f}k" if value >= 10000 else f"{value/1000:.1f}k" if value >= 1000 else f"{value:.0f}"
            rate.text(value, y+.19, label, color=color, ha="center", fontsize=24)
    rate.set(xscale="log", xlim=(100, 200000), ylim=(-.55, 2.65), yticks=[2, 1, 0],
             yticklabels=[r"Center $\mu$", "Data median", "Data 95th\npercentile"],
             xlabel="ESS / second (log scale)")
    rate.set_xticks([100, 1000, 10000, 100000], [r"$10^2$", r"$10^3$", r"$10^4$", r"$10^5$"])
    rate.minorticks_off()
    for ax in [cost, rate]:
        style(ax, "x")
        ax.spines["left"].set_visible(False)
        ax.tick_params(axis="y", length=0, pad=7)
        ax.tick_params(labelsize=24)
    save(fig, "efficiency_long")

    # Keep the algebra illustration on the same print palette as the findings.
    y, k, z = np.linspace(-8, 8, 2400), 2., .2
    roots = [(1-np.sqrt(1-4*k*z*z))/(2*z), (1+np.sqrt(1-4*k*z*z))/(2*z)]
    fig, ax = plt.subplots(figsize=(14.2, 5.7))
    fig.subplots_adjust(left=.12, right=.98, bottom=.20, top=.85)
    ax.plot(y, y/(k+y*y), color=TEAL, lw=3)
    ax.axhline(z, color=CORAL, ls="--", lw=1.5)
    ax.scatter(roots, [z, z], color=[TEAL, CORAL], s=100, zorder=3)
    for root, label, xy, color in zip(roots, [r"Inner branch $y_-$", r"Outer branch $y_+$"],
                                    [(-4, .32), (3.5, .32)], [TEAL, CORAL]):
        ax.annotate(label, (root, z), xytext=xy, fontsize=28,
                    arrowprops={"arrowstyle": "->", "color": color, "lw": 1.3})
    ax.set(xlabel=r"Residual $y=x-t$", ylabel=r"Score contribution $\psi(y)$", ylim=(-.4, .4))
    style(ax)
    save(fig, "branches")
    provenance.write_text(json.dumps({"sha256": hashes, "source": "Frozen 2026-09-10 long-chain study",
        "selection": "All four chains per method, all 160000 retained draws per chain",
        "density": "Gaussian KDE; Scott bandwidth; no display-range renormalization",
        "microseconds_per_sweep": times, "bulk_ess_per_second": rates,
        "center_intervals": quantiles, "new_mcmc": False}, indent=2)+"\n")
    print("Prepared vector posterior, efficiency and branch figures from verified saved evidence.", flush=True)


if __name__ == "__main__":
    figures()
