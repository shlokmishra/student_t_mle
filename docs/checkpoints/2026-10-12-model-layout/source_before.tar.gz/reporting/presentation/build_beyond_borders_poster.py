"""Legacy PowerPoint poster builder.

The current editable master is docs/presentation/beyond_borders_research_poster.tex;
use build_latex_poster.py for the authoritative PDF and matching display copy.
This older builder retains the first technical layout for historical reproduction.
"""
import json
import re

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.mathtext import math_to_image
import numpy as np
from scipy.stats import gaussian_kde
from PIL import Image
from pptx.util import Inches
from pptx.dml.color import RGBColor

from build_general_audience_deck import Deck, BG, INK, TEAL, CORAL, LILAC, MUTED, LINE, ASSETS, DOCS, ROOT

OUT = ROOT / "tmp/presentation_results_story"
MATH = ASSETS / "technical_poster"
WIDTH, HEIGHT = 48, 36


def technical_figures():
    MATH.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 25,
                         "text.color": "#"+INK, "axes.labelcolor": "#"+INK,
                         "xtick.color": "#"+MUTED, "ytick.color": "#"+MUTED,
                         "axes.edgecolor": "#"+LINE, "figure.facecolor": "#"+BG,
                         "axes.facecolor": "#"+BG, "savefig.facecolor": "#"+BG})
    def clean(ax):
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", color="#"+LINE, lw=.8)
        ax.set_axisbelow(True)

    fig, ax = plt.subplots(figsize=(14.8, 6.5))
    fig.subplots_adjust(left=.13, right=.98, bottom=.2, top=.9)
    y = np.linspace(-8, 8, 2400)
    k, z = 2., .2
    near, far = (1-np.sqrt(1-4*k*z*z))/(2*z), (1+np.sqrt(1-4*k*z*z))/(2*z)
    ax.plot(y, y/(k+y*y), color="#"+TEAL, lw=3.5)
    ax.axhline(z, color="#"+LILAC, ls="--", lw=2)
    ax.scatter([near, far], [z,z], color=["#"+TEAL,"#"+CORAL], s=120, zorder=4)
    ax.annotate("Inner branch", (near,z), xytext=(-3.5,.31), fontsize=26,
                arrowprops={"arrowstyle":"->", "color":"#"+TEAL})
    ax.annotate("Outer branch", (far,z), xytext=(4.,.31), fontsize=26,
                arrowprops={"arrowstyle":"->", "color":"#"+CORAL})
    ax.set(xlabel=r"Residual $y=x-t$", ylabel=r"Score contribution $z=\psi(y)$", ylim=(-.39,.4))
    clean(ax)
    fig.savefig(MATH/"branches.png", dpi=320)
    plt.close(fig)

    reference = np.load(DOCS/"evidence/results_story/information_reference.npz")["student_10_mle"]
    kde = gaussian_kde(reference, bw_method="scott")
    grid = np.linspace(-2.5, 4., 900)
    fig, ax = plt.subplots(figsize=(14.8, 6.4))
    fig.subplots_adjust(left=.12, right=.98, bottom=.21, top=.77)
    for mu, color, style in [(0.,TEAL,"-"),(1.5,CORAL,"--")]:
        ax.plot(grid, kde(grid-mu), color="#"+color, ls=style, lw=3.8,
                label=rf"Center $\mu={mu:g}$")
    ax.legend(frameon=False, ncol=2, loc="lower left", bbox_to_anchor=(0,1.04), fontsize=27)
    ax.set(xlabel=r"Possible released estimate $t$", ylabel="Probability density")
    clean(ax)
    fig.savefig(MATH/"kde_shift.png", dpi=320)
    plt.close(fig)


def build():
    technical_figures()
    d = Deck([])
    d.prs.slide_width, d.prs.slide_height = Inches(WIDTH), Inches(HEIGHT)
    d.s = d.prs.slides.add_slide(d.prs.slide_layouts[6])
    d.s.background.fill.solid()
    d.s.background.fill.fore_color.rgb = RGBColor.from_string(BG)
    paragraphs, equations, visuals = [], [], []

    def text(value,x,y,w,h,size=26,color=INK,bold=False):
        paragraphs.append(value)
        return d.text(value,x,y,w,h,size,color,bold)

    def heading(value,x,y):
        d.shape(x,y+.08,.11,.54,CORAL)
        text(value,x+.3,y,14.45,.72,36,TEAL,True)

    def figure(path,x,y,w,h,kind="plot"):
        with Image.open(path) as im:
            ratio=im.width/im.height
            iw,ih=min(w,h*ratio),min(h,w/ratio)
            dpi=min(im.width/iw,im.height/ih)
        shape=d.s.shapes.add_picture(str(path),Inches(x+(w-iw)/2),Inches(y+(h-ih)/2),
                                     width=Inches(iw),height=Inches(ih))
        visuals.append(dict(name=path.stem,kind=kind,x=x,y=y,width=w,height=h,
                            image_width=iw,image_height=ih,effective_dpi=dpi))
        return shape

    def eq(name,value,x,y,w=14.8,h=1.1,size=36):
        path=MATH/(name+".png")
        math_to_image("$"+value+"$",path,prop=FontProperties(size=size),dpi=600,
                      format="png",color="#"+INK)
        with Image.open(path) as im:
            iw,ih=im.width/600,im.height/600
        scale=min(1,w/iw,h/ih)
        if size*scale < 24:
            raise ValueError(f"Equation {name} too small: {size*scale:.1f} pt")
        shape=figure(path,x,y,min(w,iw*scale),h,"equation")
        shape._element.nvPicPr.cNvPr.set("descr", value)
        equations.append(dict(name=name,latex=value,size_pt=round(size*scale,2),x=x,y=y,width=w,height=h))

    text("Student-t Gibbs Sampling from a Released Estimate",1.2,.65,45.6,1.5,80,INK,True)
    text("Exploiting score algebra, building a shifted KDE reference, and testing what conditioning means",1.2,2.23,45.6,.8,40,TEAL)
    text("Shlok Mishra  |  Second-year PhD student  |  Department of Statistics, Texas A&M University",1.2,3.16,45.6,.75,40)
    text("Faculty advisor: Dr. Patricia Ning  |  Paris collaborators: Christian P. Robert and Antoine Luciano",1.2,4.07,45.6,.7,36,MUTED)
    d.shape(1.2,5.1,45.6,.04,TEAL)
    for x in [16.15,31.55]:
        d.shape(x,5.7,.025,27.0,LINE)
    a,b,c=1.2,16.6,32.0

    heading("01 / Problem & useful algebra",a,5.75)
    text("If only a fitted population center is released, what can still be inferred about the population and hidden data? "
         "We reconstruct compatible datasets. We studied Student, Logistic and Laplace location-only and scale-only models; "
         "here location is unknown and scale is fixed at one.",a,6.65,14.8,2.15)
    eq("model",r"X_i\mid\mu\sim t_k(\mu,1),\quad\mu\sim\pi_0,\quad t=T(x)",a,9.0)
    text("n counts observations; k is known degrees of freedom. T selects the global maximum-likelihood estimate (MLE). "
         "The log-likelihood derivative gives the score equation below, after dropping a constant.",a,10.25,14.8,1.3)
    eq("score",r"y_i=x_i-t,\quad z_i=\psi(y_i)=\frac{y_i}{k+y_i^2},\quad\sum_i z_i=0",a,11.6,h=1.1)
    eq("inverse",r"y_{\pm}(z)=\frac{1\pm\sqrt{1-4kz^2}}{2z},\quad |z|<a=\frac{1}{2\sqrt{k}}",a,12.95,h=1.2)
    figure(MATH/"branches.png",a,14.4,14.8,6.5)
    text("Student k=2: a central or extreme observation can produce the same score. "
         "The nonlinear constraint becomes a linear sum; both inverse branches matter.",a,21.03,14.8,1.05,23,MUTED)

    heading("Related models",a,22.5)
    text("Logistic: use the same score-pair construction, but the transformation is monotone. "
         "There is one inverse, so no branch-selection step. The estimator-conditioning Jacobian still requires attention. [1]",a,23.4,14.8,1.35)
    eq("logistic",r"z=\tanh(y/2),\quad y=\log\frac{1+z}{1-z},\quad |z|<1",a,24.85,h=.9)
    text("Laplace: for odd n, pin the unique sample median at t. Draw half the remaining observations below t "
         "and half above t from truncated Laplace laws, alternating with the center update. "
         "This is an order constraint, not a smooth surface. Even-n conventions are separate. [1]",a,26.0,14.8,2.4)
    heading("Paris collaboration",a,29.0)
    text("At CEREMADE, Université Paris Dauphine–PSL, Christian Robert's group was developing a privacy framework "
         "for European data-sharing needs. Working with Christian and Antoine at PariSanté Campus connected "
         "theory to computation. Fellows reflection: cross-disciplinary discussion and unexpected behavior reshaped my research questions.",a,29.9,14.8,2.5)

    heading("02 / Full Student-t Gibbs sweep",b,5.75)
    text("A two-block Metropolis-within-Gibbs algorithm for the score-conditioned target. "
         "Here fμ(y) is the Student residual density centered at μ − t, with k degrees of freedom. [1, 2]",b,6.65,14.8,1.3)
    def step(num,title,y):
        d.shape(b,y+.08,.08,.48,CORAL)
        text(num,b+.3,y,1,.62,32,CORAL,True)
        text(title,b+1.3,y,13.5,.62,32,TEAL,True)

    step("1","Initialize a feasible state",8.1)
    text("Choose a center and residual pairs (+r, -r), adding zero for odd n. "
         "Set x = t + y, so the score sum is zero. Choose positive proposal scales τ (center) and σ (score).",b,8.9,14.8,1.35)
    step("2","Update the population center",10.5)
    text("Propose μ' from Normal(μ, τ²); accept with the probability below. Otherwise retain μ.",b,11.25,14.8,.9)
    eq("mu_accept",r"\alpha_\mu=\min\!\left(1,\frac{\pi_0(\mu')}{\pi_0(\mu)}\prod_i\frac{t_k(x_i-\mu')}{t_k(x_i-\mu)}\right)",b,12.15,h=1.2)
    step("3","Select a pair; preserve its sum",13.55)
    text("Randomly permute indices into disjoint pairs. For each (i,j), hold other observations fixed "
         "and define the feasible interval I = (L,U).",b,14.3,14.8,1.15)
    eq("interval",r"\delta=z_i+z_j,\quad L=\max(-a,\delta-a),\quad U=\min(a,\delta+a)",b,15.55,h=1.25)
    step("4","Propose in one dimension",17.15)
    text("With z = zᵢ, propose u from Normal(z, σ²) truncated to I. Its normalizing probability is Z(z).",b,17.9,14.8,.85)
    eq("normalizer",r"Z(v)=\Phi((U-v)/\sigma)-\Phi((L-v)/\sigma)",b,18.85,h=1.05)
    step("5","Accept the score-space move",20.3)
    eq("z_accept",r"\alpha_z=\min\!\left(1,\frac{q_\mu(u)q_\mu(\delta-u)Z(z)}{q_\mu(z)q_\mu(\delta-z)Z(u)}\right)",b,21.1,h=1.25,size=40)
    text("Accept zᵢ = u with this probability; otherwise keep zᵢ = z. Set zⱼ = δ − zᵢ. "
         "Φ is the standard normal cumulative distribution function; Z corrects proposal asymmetry.",b,22.5,14.8,1.3)
    step("6","Draw both inverse-branch labels",24.15)
    eq("branch_weights",r"w_\mu(y)=\frac{f_\mu(y)}{|\psi'(y)|},\quad q_\mu(z)=\sum_{b\in\{-,+\}}w_\mu(y_b(z))",b,24.9,h=1.1)
    text("For each coordinate, independently choose an inverse branch with probability w/q; set x = t + y. "
         "Draw branches even after a rejected score proposal.",b,26.15,14.8,1.2)
    step("7","Complete the sweep and repeat",27.7)
    text("Process every pair; leave any unpaired coordinate unchanged. Repeat from step 2. "
         "Monitor score residuals, center/latent traces and effective sample sizes.",b,28.45,14.8,1.25)
    eq("derivative",r"\psi'(y)=\frac{k-y^2}{(k+y^2)^2},\qquad \sum_i\psi(x_i-t)=0",b,30.05,h=1.1)
    text("Numerics: use the stable inner root 2kz / (1 + √(1 − 4kz²)); at z = 0 use y = 0. Guard singular endpoints. [2]",b,31.35,14.8,1.0,23,MUTED)
    visuals.append(dict(name="Numbered Student update diagram",kind="algorithm_diagram",x=b,y=8.1,width=14.8,height=24.25,
                        image_width=14.8,image_height=24.25,effective_dpi=None))

    heading("03 / KDE: simulate once, shift",c,5.75)
    text("Location equivariance gives T(μ + U) = μ + T(U). Simulate centered datasets U, compute their "
         "selected MLEs, and fit a kernel density estimate (KDE) to their density g. "
         "One simulation bank supplies the likelihood for every candidate center. [1, 3]",c,6.65,14.8,2.15)
    eq("kde_identity",r"p(t\mid\mu)=g(t-\mu)\ \approx\ g_h(t-\mu)",c,9.0,h=1.0,size=32)
    eq("kde_posterior",r"\widehat{\pi}_h(\mu\mid t)\ \propto\ \pi_0(\mu)\,g_h(t-\mu)",c,10.15,h=1.0,size=32)
    figure(MATH/"kde_shift.png",c,11.55,14.8,6.4)
    text("Student k=2, n=10: KDE from 12,000 selected MLEs at center zero. "
         "The dashed curve shifts the same density by 1.5. This is a reusable posterior reference, not an exact finite-simulation truth.",c,18.1,14.8,1.25,23,MUTED)

    heading("Compact findings",c,19.75)
    text("A branch jump retained score zero but changed the global MLE. Separately, compiled Numba achieved "
         "1.4–2.4 times compiled JAX scan throughput in saved tests; this is not a RATTLE comparison. [4, 5]",c,20.65,14.8,1.75)
    figure(ASSETS/"exit.png",c,22.55,14.8,4.8)
    text("Late-stay discovery: actual Student k=2, n=3 Gibbs move. Teal: before; coral: after. "
         "The released zero remains stationary, but the highest likelihood peak moves away. [5]",c,27.47,14.8,1.0,23,MUTED)

    heading("Challenges & next steps",c,28.85)
    eq("mle_correction",r"R(x)=\left|\sum_i\psi'(x_i-t)\right|\,\mathbf{1}\{T(x)=t\}",c,29.7,h=1.1)
    text("Exact MLE conditioning needs this additional factor. Check KDE bandwidth and simulation sensitivity; "
         "then compare latent exploration and effective samples/second against RATTLE and extend to joint location-scale families. "
         "Population inference does not establish privacy.",c,30.95,14.8,1.75)

    d.shape(1.2,33.25,45.6,.035,TEAL)
    text("Acknowledgments",1.2,33.53,14.8,.58,32,TEAL,True)
    text("Dr. Patricia Ning; Christian P. Robert; Antoine Luciano; Texas A&M; CEREMADE; OCEAN ERC; "
         "PariSanté Campus; CIUP; Beyond Borders. Research data are simulated.",1.2,34.24,14.8,1.17,20)
    text("Sources & reproducibility",16.6,33.53,30.2,.58,32,TEAL,True)
    text("[1] Project manuscript, Student Gibbs notes, and location-model code (unpublished). "
         "[2] Student inverse-branch correctness audit and production numba_full kernel. "
         "[3] Frozen selected-MLE reference bank; Gaussian KDE, Scott bandwidth. "
         "[4] Saved Grace benchmark: 162 runs, 60,000 updates each. "
         "[5] Recorded k=2, seed=0 Gibbs exit. Equations and evidence paths accompany the editable source.",16.6,34.24,30.2,1.17,20)

    errors=list(d.fit_errors)
    for _,name,x,y,w,h in d.boxes:
        if min(x,y)<0 or x+w>WIDTH or y+h>HEIGHT:
            errors.append("Out of bounds: "+name)
    for i,(_,name,x,y,w,h) in enumerate(d.boxes):
        for _,other,ox,oy,ow,oh in d.boxes[i+1:]:
            if min(x+w,ox+ow)-max(x,ox)>.025 and min(y+h,oy+oh)-max(y,oy)>.025:
                errors.append("Overlapping text boxes: "+name+" / "+other)
        for e in equations:
            if min(x+w,e["x"]+e["width"])-max(x,e["x"])>.025 and min(y+h,e["y"]+e["height"])-max(y,e["y"])>.025:
                errors.append("Text/equation overlap: "+name+" / "+e["name"])
    if errors:
        raise ValueError("\n".join(errors))
    OUT.mkdir(parents=True,exist_ok=True)
    words=len(re.findall(r"\b[\w'-]+\b"," ".join(paragraphs)))
    assert 500 <= words <= 800,words
    graphic_area=sum(v["width"]*v["height"] for v in visuals if v["kind"] in ("plot","algorithm_diagram"))
    extra_equation_area=sum(e["width"]*e["height"] for e in equations if e["x"] != b)
    metrics=dict(width_inches=WIDTH,height_inches=HEIGHT,editable_text_words=words,
                 graphic_regions_fraction=graphic_area/(WIDTH*HEIGHT),
                 graphics_plus_external_equations_fraction=(graphic_area+extra_equation_area)/(WIDTH*HEIGHT),
                 visuals=visuals,equations=equations,body_font_pt=26,caption_font_pt=23,references_font_pt=20)
    (OUT/"poster_metrics.json").write_text(json.dumps(metrics,indent=2)+"\n")
    (DOCS/"beyond_borders_research_poster.md").write_text(
        "# Beyond Borders Technical Research Poster\n\n"
        "Visual source: reporting/presentation/build_beyond_borders_poster.py.\n"
        "48 inches wide by 36 inches high. Text is editable in PowerPoint; equations are 600-dpi "
        "graphics with editable LaTeX below and in their alternative text.\n\n"+
        "\n\n".join(paragraphs)+"\n\n## Equation Sources\n\n"+
        "\n\n".join("### "+e["name"]+"\n\n$$\n"+e["latex"]+"\n$$" for e in equations)+"\n")
    d.s.notes_slide.notes_text_frame.text=(
        "Technical revision requested by presenter. Full score-conditioned Student sweep; Logistic and odd-n Laplace summaries; "
        "shifted KDE reference. Sources: docs/paper/paper.tex sections 5 and 7; "
        "docs/student_inverse_branch_correctness_audit.md; models/loc_student.py update_pairs. "
        "Exact MLE target additionally includes abs(sum psi_prime) times a selected-global-MLE indicator. "
        "Photo intentionally omitted; Paris context retained. See docs/presentation/submission_review.md.\n\n"+
        "\n".join(e["name"]+": "+e["latex"] for e in equations))
    target=OUT/"beyond_borders_research_poster.pptx"
    d.prs.save(target)
    print(f"Built {target}: {words} editable words; three columns; no text-box overflow.")


if __name__=="__main__":
    build()
