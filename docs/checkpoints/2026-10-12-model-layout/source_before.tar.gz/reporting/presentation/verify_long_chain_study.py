"""Check saved study provenance and derived summaries without rerunning MCMC."""

import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "docs/presentation/evidence/long_chain_study"
RAW = ROOT / "tmp/presentation_long_chains"


def main():
    protocol = json.loads((OUT / "protocol.json").read_text())
    summary = json.loads((OUT / "summary.json").read_text())
    assert summary["protocol"] == protocol
    kept = protocol["iterations"]-protocol["burn_in"]
    initial = {}
    for method in ["gibbs", "rattle"]:
        for seed in protocol["seeds"]:
            meta = json.loads((OUT / f"{method}_{seed}.json").read_text())
            for path, expected in meta["sha256"].items():
                if path.startswith("models/") or path.endswith("protocol.json"):
                    assert hashlib.sha256((ROOT / path).read_bytes()).hexdigest() == expected
            with np.load(RAW / f"{method}_{seed}.npz") as raw, np.load(OUT / f"{method}_{seed}_summaries.npz") as reduced:
                mu, x = raw["mu"], raw["x"]
                assert x.shape == (protocol["iterations"]+1, protocol["n"])
                assert mu.shape == (len(x),) and mu[0] == 0
                assert np.isfinite(x).all() and np.isfinite(mu).all()
                assert np.array_equal(mu[-kept:], reduced["mu"])
                quantiles = np.quantile(x[-kept:], [.5, .95], axis=1)
                assert np.array_equal(quantiles[0], reduced["median"])
                assert np.array_equal(quantiles[1], reduced["q95"])
                residual = np.abs(np.sum(x/(2+x*x), axis=1)).max()
                assert residual == meta["max_score_residual"] and residual < 1e-8
                assert np.array_equal(reduced["initial_x"], x[0])
                if method == "gibbs":
                    initial[seed] = x[0].copy()
                else:
                    assert np.array_equal(initial[seed], x[0])
                assert np.array_equal(reduced["audit_indices"], np.linspace(40001, 200000, 1000, dtype=int))
                assert np.mean(np.abs(reduced["audit_selected_mle"]) > 1e-6) == meta["selected_mle_mismatch_fraction"]
    bank = np.load(OUT / "reference.npz")["mle"]
    assert bank.shape == (50000,) and np.isfinite(bank).all()
    assert hashlib.sha256((OUT / "reference.npz").read_bytes()).hexdigest() == summary["reference_sha256"]
    report = {"status": "passed", "chains": 8, "unique_updates": 1600000,
              "retained_per_method": 640000, "reference_datasets": 50000,
              "checks": ["production source hashes unchanged", "frozen protocol",
                         "matched initial datasets", "finite full chains", "score residuals",
                         "exact derived quantiles", "fixed MLE audit indices", "reference checksum"]}
    (OUT / "verification.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
