"""Typeset the talk's editable LaTeX source, then render robust PNG assets."""

import os
from pathlib import Path
import shutil
import subprocess

import pymupdf as fitz

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "docs/presentation/talk_equations.tex"
OUT = ROOT / "tmp/presentation_equations_latex"
ASSETS = ROOT / "docs/presentation/Images/general_audience/polished"
TEXBIN = Path("/sw/eb/sw/texlive/20230313-GCC-13.2.0/bin/x86_64-linux")
NAMES = ["score", "pair_before", "pair_after", "weight", "logistic", "shift", "posterior"]


def prepare_equations():
    OUT.mkdir(parents=True, exist_ok=True)
    executable = shutil.which("pdflatex") or str(TEXBIN / "pdflatex")
    env = dict(os.environ, PATH=str(Path(executable).parent)+os.pathsep+os.environ["PATH"])
    result = subprocess.run([executable, "-halt-on-error", "-interaction=nonstopmode",
                             f"-output-directory={OUT}", str(SOURCE)], cwd=ROOT,
                            env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (OUT / "compile.txt").write_text(result.stdout)
    if result.returncode or "Overfull" in result.stdout:
        raise RuntimeError(result.stdout[-6000:])
    document = fitz.open(OUT / "talk_equations.pdf")
    assert len(document) == len(NAMES)
    for page, name in zip(document, NAMES):
        assert page.get_text().strip(), name
        page.get_pixmap(dpi=900, alpha=False).save(ASSETS / f"eq_{name}.png")
        single = fitz.open()
        single.insert_pdf(document, from_page=page.number, to_page=page.number)
        single.save(ASSETS / f"eq_{name}.pdf")
        # Keep vector exports for editing, but never embed SVG overrides in PPTX.
        (ASSETS / f"eq_{name}.svg").write_text(page.get_svg_image(text_as_path=True))
    print(f"Typeset {len(NAMES)} equations; opaque 900-dpi PNGs, PDF and SVG sources.")


if __name__ == "__main__":
    prepare_equations()
