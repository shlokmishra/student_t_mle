"""Focused talk visuals: exact illustrative geometry and frozen chain summaries."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import numpy as np
from scipy.stats import norm

ROOT = Path(__file__).resolve().parents[2]
ASSETS = ROOT / "docs/presentation/Images/general_audience/polished"
EVIDENCE = ROOT / "docs/presentation/evidence/long_chain_study"
REVIEW = ROOT / "tmp/presentation_feedback_3"
INK, TEAL, CORAL, BG, LINE = "#183B3A", "#16766D", "#C45546", "#F0F5F4", "#CEDDD9"


def save(fig, name):
    fig.savefig(ASSETS / f"{name}.png", dpi=260)
    fig.savefig(ASSETS / f"{name}.pdf")
    plt.close(fig)


def style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(labelsize=17)
    ax.set_axisbelow(True)
    ax.grid(axis="y", color=LINE, lw=.7)


def prepare_feedback():
    REVIEW.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 20,
        "text.color": INK, "axes.labelcolor": INK, "axes.edgecolor": LINE,
        "xtick.color": INK, "ytick.color": INK, "mathtext.fontset": "stix",
        "figure.facecolor": BG, "axes.facecolor": BG, "savefig.facecolor": BG,
        "pdf.fonttype": 42})

    # A single fixed Student dataset: relative likelihood, not a posterior.
    data = np.array([-5.5, -5.1, -4.8, 4.0, 5.0, 6.0])
    centers = np.linspace(-8, 8, 2401)
    ll = -np.log1p((data[:, None]-centers)**2).sum(axis=0)
    peaks = np.flatnonzero((ll[1:-1] > ll[:-2]) & (ll[1:-1] > ll[2:]))+1
    assert len(peaks) == 2
    best, lower = sorted(peaks, key=lambda i: ll[i], reverse=True)
    relative = np.exp(ll-ll.max())
    assert .2 < relative[lower] < .5
    fig, ax = plt.subplots(figsize=(12, 3.6))
    fig.subplots_adjust(left=.12, right=.97, bottom=.23, top=.83)
    ax.plot(centers, relative, lw=3, color=TEAL)
    ax.fill_between(centers, 0, relative, color=TEAL, alpha=.09)
    ax.scatter(centers[peaks], relative[peaks], c=[TEAL, CORAL], s=80, zorder=3)
    ax.annotate("Highest peak: the MLE", (centers[best], 1), xytext=(-2.7, 1.03),
        fontsize=20, arrowprops={"arrowstyle": "->", "color": TEAL}, color=TEAL)
    ax.annotate("A lower local peak", (centers[lower], relative[lower]), xytext=(.3, .70),
        fontsize=20, arrowprops={"arrowstyle": "->", "color": CORAL}, color=CORAL)
    ax.set(xlabel="Candidate population center", ylabel="Relative likelihood",
           xlim=(-8, 8), ylim=(-.02, 1.23), xticks=[-8, -4, 0, 4, 8], yticks=[0, .5, 1])
    style(ax)
    save(fig, "talk_likelihood_clear")

    # Equal-probability bands connect density area to simulated possibilities.
    grid = np.linspace(-2.7, 3, 1601)
    density = norm.pdf(grid, .15, .75)
    lo, hi = norm.ppf([.05, .95], .15, .75)
    fig, ax = plt.subplots(figsize=(12, 4.15))
    fig.subplots_adjust(left=.12, right=.97, bottom=.20, top=.83)
    cuts = norm.ppf(np.linspace(.05, .95, 10), .15, .75)
    for left, right in zip(cuts[:-1], cuts[1:]):
        mask = (grid >= left) & (grid <= right)
        ax.fill_between(grid, 0, density, where=mask, color=TEAL, alpha=.20)
        ax.vlines(right, 0, norm.pdf(right, .15, .75), color=BG, lw=2)
    ax.plot(grid, density, color=TEAL, lw=3)
    ax.annotate("90% probability in this interval", (.15, .25), xytext=(-1.4, .61),
        fontsize=23, color=TEAL, arrowprops={"arrowstyle": "->", "color": TEAL})
    draws = np.random.default_rng(20260904).normal(.15, .75, 60)
    # All 60 illustrative independent draws, stacked only for legibility.
    occupied = {}
    heights = []
    for value in draws:
        key = round(value/.12)
        level = occupied.get(key, 0)
        heights.append(-.055-level*.025)
        occupied[key] = level+1
    ax.scatter(draws, heights, s=27, color=CORAL, edgecolors="none")
    ax.text(2.95, -.19, "Simulated draws", ha="right", color=CORAL, fontsize=18)
    ax.set(xlabel="Possible population center", ylabel="Probability density",
           xlim=(-2.7, 3), ylim=(-.23, .69), yticks=[0, .25, .5])
    style(ax)
    save(fig, "talk_posterior_intuition")

    # A proven isosurface mesher avoids holes from a single inverse chart.
    # Newton-project vertices onto the exact level set after interpolation.
    from skimage.measure import marching_cubes
    k, bound = 2., 3.8
    line = np.linspace(-bound, bound, 111)
    q = line/(k+line*line)
    field = q[:, None, None]+q[None, :, None]+q[None, None, :]
    vertices, faces, _, _ = marching_cubes(field, level=0, spacing=(line[1]-line[0],)*3,
                                          allow_degenerate=False)
    vertices = vertices.astype(float)-bound
    for _ in range(4):
        residual = (vertices/(k+vertices**2)).sum(axis=1)
        gradient = (k-vertices**2)/(k+vertices**2)**2
        vertices -= residual[:, None]*gradient/(gradient*gradient).sum(axis=1)[:, None]
    mesh_error = float(np.max(np.abs((vertices/(k+vertices**2)).sum(axis=1))))
    fig = plt.figure(figsize=(8.6, 5.25))
    ax = fig.add_axes([.015, .065, .96, .93], projection="3d", computed_zorder=False)
    surface = Poly3DCollection(vertices[faces], facecolors="#399589",
        linewidths=0, alpha=1, shade=True, lightsource=LightSource(azdeg=310, altdeg=35), zorder=1)
    surface.set_rasterized(True)
    surface.set_edgecolor("none")
    ax.add_collection3d(surface)
    points = np.array([[-2., 2., 0.], [0., -2., 2.], [2., 0., -2.]])
    assert np.allclose((points/(k+points**2)).sum(axis=1), 0)
    ax.scatter(*points.T, s=68, c="#F6D68D", edgecolor=INK, linewidth=.9,
               depthshade=False, zorder=5)
    ax.set(xlim=(-bound, bound), ylim=(-bound, bound), zlim=(-bound, bound),
           xticks=[-3, 0, 3], yticks=[-3, 0, 3], zticks=[-3, 0, 3])
    ax.set_xlabel(r"Observation $x_1$", labelpad=12, fontsize=19)
    ax.set_ylabel(r"Observation $x_2$", labelpad=12, fontsize=19)
    ax.set_zlabel(r"Observation $x_3$", labelpad=9, fontsize=19)
    ax.tick_params(labelsize=15, pad=1)
    ax.set_box_aspect((1, 1, .85), zoom=.89)
    ax.view_init(elev=23, azim=-56)
    for axis in [ax.xaxis, ax.yaxis, ax.zaxis]:
        axis.pane.fill = False
        axis._axinfo["grid"].update(color=LINE, linewidth=.55)
    save(fig, "talk_student_manifold_3d")
    assert mesh_error < 1e-12

    # Frozen, consecutive traces: no new chains or favorable-window selection.
    summary = json.loads((EVIDENCE / "summary.json").read_text())
    fig, axs = plt.subplots(1, 3, figsize=(12.2, 4.0))
    fig.subplots_adjust(left=.06, right=.965, bottom=.23, top=.81, wspace=.30)
    keys = ["mu", "median", "q95"]
    for ax, key, title in zip(axs, keys, ["Population center", "Data median", "Data 95th percentile"]):
        vals = []
        for method, name, color in [("gibbs", "Gibbs", TEAL), ("rattle", "RATTLE", CORAL)]:
            v = np.load(EVIDENCE / f"{method}_101_summaries.npz")[key][:2000]
            assert len(v) == 2000
            vals.append(v)
            ax.plot(np.arange(1, 2001), v, color=color, lw=.8, alpha=.85, label=name)
        ax.set_title(title, loc="left", fontsize=20, pad=30)
        ax.legend(loc="upper right", fontsize=11, frameon=True, facecolor=BG,
                  framealpha=.94, edgecolor="none", handlelength=1.3, borderpad=.3, labelspacing=.2)
        if key == "q95":
            ax.set_yscale("symlog", linthresh=2)
            ax.set_ylim(0, max(np.max(v) for v in vals)*1.7)
            ax.set_yticks([0, 2, 10, 100], ["0", "2", "10", "100"])
        else:
            limit = max(np.abs(v).max() for v in vals)*1.16
            ax.set_ylim(-limit, limit*1.35)
        ax.set(xlim=(0, 2000), xticks=[0, 1000, 2000], xlabel="Retained step")
        ax.tick_params(axis="x", labelsize=15)
        style(ax)
    fig.text(.705, .83, "Linear to 2; logarithmic above", color=INK, fontsize=13)
    save(fig, "talk_trace_focus")

    fig, ax = plt.subplots(figsize=(12, 4.0))
    fig.subplots_adjust(left=.27, right=.82, bottom=.24, top=.82)
    ratios = {}
    for row, key in zip([2, 1, 0], keys):
        values = [summary["methods"][method]["summaries"][key]["bulk_ess_per_second"]
                  for method in ["rattle", "gibbs"]]
        ax.plot(values, [row, row], lw=5, color=LINE, solid_capstyle="round")
        for value, label, color, marker in zip(values, ["RATTLE", "Gibbs"], [CORAL, TEAL], ["s", "o"]):
            ax.scatter(value, row, c=color, s=110, marker=marker, label=label if row==2 else None, zorder=3)
            ax.text(value, row+.17, f"{value:,.0f}", fontsize=18, color=color, ha="center")
        ratios[key] = values[1]/values[0]
        ratio_label = f"{ratios[key]:.1f}x" if ratios[key] < 20 else f"{ratios[key]:.0f}x"
        ax.text(1.08, row, ratio_label, transform=ax.get_yaxis_transform(),
                fontsize=24, weight="bold", color=TEAL, va="center")
    ax.set(xscale="log", xlim=(200, 150000), ylim=(-.45, 2.65), yticks=[2, 1, 0],
           yticklabels=["Population center", "Data median", "Data 95th percentile"],
           xlabel="Bulk effective samples per second (log scale)")
    ax.set_xticks([1000, 10000, 100000], ["1,000", "10,000", "100,000"])
    ax.minorticks_off()
    ax.legend(loc="lower left", bbox_to_anchor=(0, 1.02), ncol=2, fontsize=15,
              frameon=False, handletextpad=.3, columnspacing=1.2)
    ax.text(1.08, 1.05, "Gibbs / RATTLE", transform=ax.transAxes, fontsize=14, color=TEAL)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.tick_params(axis="y", length=0, pad=15, labelsize=19)
    ax.tick_params(axis="x", labelsize=17)
    ax.grid(axis="x", color=LINE, lw=.8)
    ax.set_axisbelow(True)
    save(fig, "talk_efficiency_focus")

    report = {"new_mcmc": False, "trace_selection": "seed 101, first 2000 retained consecutive states",
        "manifold": {"k": k, "n": 3, "release": 0, "view_cube": [-bound, bound],
                     "max_vertex_score_residual": mesh_error, "triangles": len(faces),
                     "target": "score-zero surface, not selected-MLE surface; finite viewing cube",
                     "method": "scikit-image marching cubes followed by analytic Newton projection"},
        "likelihood_example": {"student_k": 1, "observations": data.tolist(),
                              "local_peak_relative_heights": relative[peaks].tolist()},
        "posterior_illustration": {"distribution": "Normal(0.15, 0.75^2)", "central_probability": .9,
                                   "interval": [lo, hi], "draws": 60},
        "ess_rate_ratios": ratios}
    (REVIEW / "figure_checks.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    prepare_feedback()
