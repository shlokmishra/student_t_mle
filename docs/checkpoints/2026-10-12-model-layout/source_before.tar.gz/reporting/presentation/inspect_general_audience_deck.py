"""Inspect a LibreOffice PDF export and create slide/contact-sheet previews.

Requires PyMuPDF, python-pptx and Pillow. Takes a matching PPTX and PDF, checks
that editable text survived rendering, and flags clipped or overlapping text.
"""

import argparse
import json
import re
from pathlib import Path

import pymupdf as fitz
from PIL import Image, ImageDraw
from pptx import Presentation


def normalized(text):
    return re.sub(r"\s+", "", text).replace("\u00ad", "")


def inspect(pptx, pdf, out):
    out.mkdir(parents=True, exist_ok=True)
    deck = Presentation(pptx)
    rendered = fitz.open(pdf)
    assert len(rendered) == len(deck.slides) > 0
    issues = []
    for number, (page, slide) in enumerate(zip(rendered, deck.slides), 1):
        texts = [shape.text for shape in slide.shapes if shape.has_text_frame]
        actual = normalized(page.get_text())
        for text in texts:
            if normalized(text) not in actual:
                issues.append(f"Slide {number}: text missing or reordered: {text[:80]}")
        lines = [line for block in page.get_text("dict")["blocks"] if "lines" in block
                 for line in block["lines"] if any(s["text"].strip() for s in line["spans"])]
        for i, line in enumerate(lines):
            box = fitz.Rect(line["bbox"])
            if not page.rect.contains(box):
                issues.append(f"Slide {number}: rendered text outside page: {box}")
            for other in lines[i+1:]:
                intersection = box & fitz.Rect(other["bbox"])
                if not intersection.is_empty and intersection.width > 2 and intersection.height > 2:
                    issues.append(f"Slide {number}: rendered text lines overlap: {line['spans'][0]['text']} / {other['spans'][0]['text']}")
        page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False).save(out / f"slide-{number:02d}.png")
    for start in range(1, len(rendered)+1, 6):
        sheet = Image.new("RGB", (1600, 1428), "#DCE7E3")
        draw = ImageDraw.Draw(sheet)
        for offset, number in enumerate(range(start, min(start+6, len(rendered)+1))):
            thumb = Image.open(out / f"slide-{number:02d}.png")
            thumb.thumbnail((780, 439), Image.Resampling.LANCZOS)
            x, y = 10+(offset%2)*800, 26+(offset//2)*476
            sheet.paste(thumb, (x, y))
            draw.text((x, y-18), f"SLIDE {number:02d}", fill="#183B3A")
        sheet.save(out / f"contact-{start:02d}.png")
    result = {"slides": len(rendered), "issues": issues,
              "checks": ["All editable text present in rendered PDF", "Rendered text inside page bounds",
                         "No intersecting rendered text lines", f"{len(rendered)} slide PNG previews"]}
    (out / "layout_check.json").write_text(json.dumps(result, indent=2)+"\n")
    print(json.dumps(result, indent=2))
    if issues:
        raise SystemExit(1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx", type=Path)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    inspect(args.pptx, args.pdf, args.out)
