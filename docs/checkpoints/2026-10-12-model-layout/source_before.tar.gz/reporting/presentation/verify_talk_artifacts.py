"""Cross-check rendered figures and the portable deck against current sources."""

from io import BytesIO
import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image
import pymupdf as fitz
from pptx import Presentation

ROOT = Path(__file__).resolve().parents[2]
REVIEW = ROOT / "tmp/presentation_long_chain_review"
ASSETS = ROOT / "docs/presentation/Images/general_audience/polished"


def main(review):
    source = Presentation(ROOT / "tmp/presentation_polish/beyond_borders_general_audience.pptx")
    pdf = fitz.open(review / "beyond_borders_general_audience.pdf")
    portable = Presentation(review / "portable/beyond_borders_general_audience_portable.pptx")
    checks = []
    assert len(source.slides) == len(pdf) == len(portable.slides) > 0
    for i, slide in enumerate(source.slides):
        assert slide.notes_slide.notes_text_frame.text == portable.slides[i].notes_slide.notes_text_frame.text
        for shape in slide.shapes:
            if shape.shape_type != 13:
                continue
            name = shape._element.nvPicPr.cNvPr.get("descr", "")
            if not name.startswith(("talk_", "eq_", "IMG_")):
                continue
            extension = "jpg" if name.startswith("IMG_") else "png"
            if not (ASSETS / f"{name}.{extension}").exists():
                extension = "png"
            assert shape.image.blob == (ASSETS / f"{name}.{extension}").read_bytes(), name
            rect = fitz.Rect(shape.left/12700, shape.top/12700,
                             (shape.left+shape.width)/12700, (shape.top+shape.height)/12700)
            pix = pdf[i].get_pixmap(matrix=fitz.Matrix(2, 2), clip=rect, alpha=False)
            actual = np.frombuffer(pix.samples, np.uint8).reshape(pix.height, pix.width, 3)
            expected = Image.open(BytesIO(shape.image.blob)).convert("RGB")
            if name.startswith("IMG_"):
                width, height = expected.size
                expected = expected.crop((shape.crop_left*width, shape.crop_top*height,
                    (1-shape.crop_right)*width, (1-shape.crop_bottom)*height))
            expected = expected.resize((pix.width, pix.height), Image.Resampling.LANCZOS)
            error = float(np.abs(actual.astype(float)-np.asarray(expected).astype(float)).mean())
            assert error < 8, (i+1, name, error)
            checks.append({"slide": i+1, "asset": name, "mean_pixel_error": error})
        pix = pdf[i].get_pixmap(matrix=fitz.Matrix(300/72, 300/72), alpha=False)
        embedded = Image.open(BytesIO(portable.slides[i].shapes[0].image.blob)).convert("RGB")
        assert embedded.size == (pix.width, pix.height)
        assert embedded.tobytes() == pix.samples, i+1
    for name in ["talk_likelihood_clear", "talk_posterior_intuition", "talk_student_manifold_3d",
                 "talk_long_posterior", "talk_trace_focus", "talk_efficiency_focus"]:
        doc = fitz.open(ASSETS / f"{name}.pdf")
        for page in doc:
            for word in page.get_text("words"):
                assert page.rect.contains(fitz.Rect(word[:4])), (name, word)
    rerender = fitz.open(review / "portable/beyond_borders_general_audience_portable.pdf")
    assert len(rerender) == len(pdf)
    errors = []
    for a, b in zip(pdf, rerender):
        assert a.rect == b.rect
        actual = np.frombuffer(a.get_pixmap(alpha=False).samples, np.uint8).astype(float)
        reproduced = np.frombuffer(b.get_pixmap(alpha=False).samples, np.uint8).astype(float)
        error = float(np.abs(actual-reproduced).mean())
        assert error < 10, error
        errors.append(error)
    report = {"status": "passed", "slides": len(source.slides), "figure_checks": checks,
              "portable_slide_pixels_match_pdf": True, "notes_preserved": True,
              "portable_office_rerender_mean_pixel_errors": errors,
              "new_figure_text_in_bounds": True}
    (review / "artifact_validation.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--review-dir", type=Path, default=REVIEW)
    main(parser.parse_args().review_dir)
