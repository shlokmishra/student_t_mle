"""Independent finite-dimensional checks of the poster algebra and saved numbers.

These checks do not prove normalizability or global MCMC convergence.
"""

import json
from pathlib import Path
import sys

import arviz as az
import numpy as np
from scipy.optimize import brentq
from scipy.stats import gaussian_kde, norm, t

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from models import loc_student
from models.student_location_mle import global_mle

EVIDENCE = ROOT / "docs/presentation/evidence/long_chain_study"
OUT = ROOT / "tmp/poster_final_review"


def roots(z, k):
    discriminant = np.sqrt(1-4*k*z*z)
    return np.array([2*k*z/(1+discriminant), (1+discriminant)/(2*z)])


def derivative(y, k):
    return (k-y*y)/(k+y*y)**2


def q(z, k, loc):
    y = roots(z, k)
    return np.sum(t.pdf(y-loc, k)/np.abs(derivative(y, k)))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    summary = json.loads((EVIDENCE / "summary.json").read_text())
    checks = []
    for k in [1., 2., 3.]:
        for z in np.array([-.91, -.25, .07, .83])/(2*np.sqrt(k)):
            y = roots(z, k)
            np.testing.assert_allclose(y/(k+y*y), z, atol=1e-13)
            step = 1e-5
            finite = ((y+step)/(k+(y+step)**2)-(y-step)/(k+(y-step)**2))/(2*step)
            np.testing.assert_allclose(finite, derivative(y, k), rtol=2e-7, atol=1e-10)
            expected = t.logpdf(y-.3, k)-np.log(np.abs(derivative(y, k)))
            actual = np.array([loc_student.inverse_branch_log_weight(float(v), .3, k) for v in y])
            np.testing.assert_allclose(actual-actual[0], expected-expected[0], atol=1e-12)
    checks += ["Student inverse roots", "score derivative by finite differences", "branch weights versus production"]

    k, delta, current, proposed, sigma = 2., .07, -.08, .19, .16
    a = 1/(2*np.sqrt(k))
    low, high = max(-a, delta-a), min(a, delta+a)
    Z = lambda v: norm.cdf((high-v)/sigma)-norm.cdf((low-v)/sigma)
    target = lambda v: q(v, k, .3)*q(delta-v, k, .3)
    proposal = lambda u, v: norm.pdf((u-v)/sigma)/sigma/Z(v)
    ratio = target(proposed)*Z(current)/(target(current)*Z(proposed))
    forward = target(current)*proposal(proposed, current)*min(1, ratio)
    reverse = target(proposed)*proposal(current, proposed)*min(1, 1/ratio)
    np.testing.assert_allclose(forward, reverse, rtol=1e-13)
    checks.append("Hastings Z(current)/Z(proposed) detailed-balance flux")
    z = np.linspace(-.9, .9, 31)
    y = np.log((1+z)/(1-z))
    np.testing.assert_allclose(np.tanh(y/2), z, atol=1e-14)
    step = 1e-6
    finite = (np.log((1+z+step)/(1-z-step))-np.log((1+z-step)/(1-z+step)))/(2*step)
    np.testing.assert_allclose(finite, 2/(1-z*z), rtol=1e-8)
    checks.append("Logistic inverse and inverse Jacobian")

    x = np.array([-2.3, -.8, -.5, -.1, .2, .4, .7, .9, 1.4, 4.1])
    fitted = global_mle(x, 2.)
    analytic = derivative(x-fitted, 2.)
    analytic /= analytic.sum()
    numerical = []
    for i in range(len(x)):
        perturb = np.eye(len(x))[i]*1e-5
        numerical.append((global_mle(x+perturb, 2.)-global_mle(x-perturb, 2.))/(2e-5))
    np.testing.assert_allclose(numerical, analytic, atol=1e-7, rtol=1e-5)
    np.testing.assert_allclose(global_mle(x+1.5, 2.), fitted+1.5, atol=1e-11)
    checks += ["selected-estimator Jacobian via implicit differentiation", "MLE location equivariance"]

    # A Gaussian KDE times a Normal prior is an exactly evaluable Normal mixture.
    bank = np.load(EVIDENCE / "reference.npz")["mle"]
    bandwidth = float(np.sqrt(gaussian_kde(bank).covariance[0, 0]))
    reference = {}
    for multiplier in [.7, 1., 1.3]:
        h = bandwidth*multiplier
        weights = norm.pdf(bank, 0, np.sqrt(100+h*h))
        weights /= weights.sum()
        means, sd = -bank*100/(100+h*h), np.sqrt(100*h*h/(100+h*h))
        cdf = lambda value: np.sum(weights*norm.cdf((value-means)/sd))
        quantiles = [brentq(lambda value: cdf(value)-p, -10, 10, xtol=1e-12) for p in [.025, .5, .975]]
        reference[str(multiplier)] = quantiles
        np.testing.assert_allclose(quantiles, summary["reference"][str(multiplier)]["quantiles"], atol=1e-4)
    checks.append("KDE posterior intervals independently checked by analytic Gaussian-mixture CDF")

    diagnostic_errors = []
    for method in ["gibbs", "rattle"]:
        stats = summary["methods"][method]
        elapsed = sum(json.loads((EVIDENCE/f"{method}_{seed}.json").read_text())["elapsed_seconds"]
                      for seed in summary["protocol"]["seeds"])
        np.testing.assert_allclose(1000*elapsed/800000, stats["ms_per_iteration"], rtol=1e-13)
        for key in ["mu", "median", "q95"]:
            values = np.stack([np.load(EVIDENCE/f"{method}_{seed}_summaries.npz")[key]
                               for seed in summary["protocol"]["seeds"]])
            expected = stats["summaries"][key]
            bulk, rhat = float(az.ess(values, method="bulk")), float(az.rhat(values, method="rank"))
            np.testing.assert_allclose(bulk, expected["bulk_ess"], rtol=1e-10)
            np.testing.assert_allclose(bulk/elapsed, expected["bulk_ess_per_second"], rtol=1e-10)
            np.testing.assert_allclose(rhat, expected["rank_split_rhat"], rtol=1e-10)
            diagnostic_errors.append(abs(bulk-expected["bulk_ess"]))
    checks.append("all six bulk ESS/rank-split R-hat estimates and timing denominators recomputed")
    # At n=2,C=0, paired endpoint singularities give a nonintegrable 1/epsilon law.
    a = 1/(2*np.sqrt(2.))
    singular = [eps*q(a-eps, 2., 0.)*q(-a+eps, 2., 0.) for eps in [1e-5, 1e-6, 1e-7]]
    assert singular[-1] > 0 and abs(singular[-1]/singular[-2]-1) < 1e-4
    report = {"status": "passed", "checks": checks, "reference_quantiles_independent": reference,
              "max_bulk_ess_reproduction_error": max(diagnostic_errors),
              "n2_endpoint_epsilon_times_pair_density": singular,
              "scope": "Finite checks, not a proof of global invariance under floating-point guards or ergodicity"}
    (OUT / "math_audit.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
