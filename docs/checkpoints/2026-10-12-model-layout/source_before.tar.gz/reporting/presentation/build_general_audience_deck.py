"""Build the editable, themed Beyond Borders deck from the existing narrative.

Requires python-pptx, Pillow, matplotlib, numpy and PyYAML. Scientific plots
read saved results only. Speaker notes and citations come from the Markdown.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
from pathlib import Path

from matplotlib.font_manager import FontProperties, findfont
import yaml
from PIL import ImageFont
from lxml import etree
from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.util import Inches, Pt
from pptx.oxml.xmlchemy import OxmlElement
from prepare_methods_talk_assets import prepare
from prepare_feedback_talk_assets import prepare_feedback

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "docs/presentation"
ASSETS = DOCS / "Images/general_audience/polished"
PREVIEW = ROOT / "tmp/presentation_polish"
BG, INK, TEAL, CORAL = "F0F5F4", "183B3A", "16766D", "C45546"
MUTED, LINE, WHITE, LILAC = "516865", "CEDDD9", "FFFFFF", "7774A4"
FONT = "DejaVu Sans"
W, H = 13.333333, 7.5


class Deck:
    def __init__(self, notes):
        self.prs = Presentation()
        self.prs.slide_width, self.prs.slide_height = Inches(W), Inches(H)
        self.notes = notes
        self.boxes = []
        self.media_boxes = []
        self.equation_checks = []
        self.fit_errors = []
        # Carry the palette and typeface into PowerPoint's editable theme.
        theme = next(r.target_part for r in self.prs.slide_master.part.rels.values()
                     if r.reltype.endswith("/theme"))
        xml = etree.fromstring(theme.blob)
        ns = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main"}
        scheme = xml.find(".//a:clrScheme", ns)
        for name, color in {"dk1": INK, "lt1": WHITE, "dk2": MUTED, "lt2": BG,
                            "accent1": TEAL, "accent2": CORAL, "accent3": LILAC,
                            "accent4": "3F859B", "accent5": "9DAF72", "accent6": "D6A347",
                            "hlink": MUTED, "folHlink": TEAL}.items():
            node = scheme.find("a:"+name, ns)
            for child in list(node):
                node.remove(child)
            etree.SubElement(node, "{"+ns["a"]+"}srgbClr", val=color)
        for node in xml.findall(".//a:fontScheme//a:latin", ns):
            node.set("typeface", FONT)
        theme._blob = etree.tostring(xml, xml_declaration=True, encoding="UTF-8", standalone=True)

    def shape(self, x, y, w, h, fill, kind=MSO_SHAPE.RECTANGLE, line=None):
        s = self.s.shapes.add_shape(kind, Inches(x), Inches(y), Inches(w), Inches(h))
        s.fill.solid()
        s.fill.fore_color.rgb = RGBColor.from_string(fill)
        if line:
            s.line.color.rgb = RGBColor.from_string(line)
            s.line.width = Pt(2)
        else:
            s.line.fill.background()
        s._element.spPr.append(OxmlElement("a:effectLst"))
        for effect in s._element.xpath(".//a:effectRef"):
            effect.set("idx", "0")
        return s

    def text(self, text, x, y, w, h, size=24, color=INK, bold=False, align=PP_ALIGN.LEFT):
        font = ImageFont.truetype(findfont(FontProperties(family=FONT, weight="bold" if bold else "normal")), size*4)
        lines = []
        # Fix line breaks in the source, so office renderers need not auto-fit.
        for paragraph in text.split("\n"):
            current = ""
            for word in paragraph.split():
                trial = (current + " " + word).strip()
                if font.getlength(trial)/4 > w*72-5 and current:
                    lines.append(current)
                    current = word
                else:
                    current = trial
            lines.append(current)
        needed = sum(size*(1.18 if line else .42)/72 for line in lines)
        if needed > h + .025:
            self.fit_errors.append(f"Slide {len(self.prs.slides)} text needs {needed:.2f}in, has {h}: {text}")
        s = self.s.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
        tf = s.text_frame
        tf.clear()
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.word_wrap = False
        tf.auto_size = MSO_AUTO_SIZE.NONE
        tf.vertical_anchor = MSO_ANCHOR.TOP
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = line
            p.alignment = align
            p.space_before = p.space_after = Pt(0)
            p.line_spacing = Pt(size*(1.18 if line else .42))
            p.font.name = FONT
            p.font.size = Pt(size if line else size*.35)
            p.font.bold = bold
            p.font.color.rgb = RGBColor.from_string(color)
        self.boxes.append((len(self.prs.slides), text[:55], x, y, w, h))
        return s

    def slide(self, title, section, dark=False, title_height=1.1):
        self.s = self.prs.slides.add_slide(self.prs.slide_layouts[6])
        self.s.background.fill.solid()
        self.s.background.fill.fore_color.rgb = RGBColor.from_string(INK if dark else BG)
        i = len(self.prs.slides)
        self.s.notes_slide.notes_text_frame.text = self.notes[i-1]
        self.shape(.55, .39, .36, .065, CORAL)
        self.text(section.upper(), 1.04, .28, 10.8, .25, 12, "B8D8CF" if dark else TEAL, True)
        if title:
            self.text(title, .65, .88, 12.0, title_height, 32, WHITE if dark else INK, True)
        self.shape(.65, 6.98, 12.03, .012, "39605A" if dark else LINE)
        self.text("SHLOK MISHRA  /  BEYOND BORDERS", .65, 7.12, 10, .2, 10,
                  "B8D8CF" if dark else MUTED)
        self.text(f"{i:02d}", 12.02, 7.08, .65, .26, 13,
                  "B8D8CF" if dark else MUTED, align=PP_ALIGN.RIGHT)

    def rule(self, x, y, w, color=LINE):
        self.shape(x, y, w, .025, color)

    def caption(self, text, color=INK):
        self.rule(.65, 6.12, .6, CORAL)
        self.text(text, 1.45, 6.08, 11.1, .7, 21, color)

    def source(self, text, url):
        shape = self.text(text, .7, 6.77, 11.9, .2, 12, MUTED)
        for paragraph in shape.text_frame.paragraphs:
            for run in paragraph.runs:
                run.hyperlink.address = url
                run.font.underline = False
                run.font.color.rgb = RGBColor.from_string(MUTED)

    def image(self, name, x=.65, y=2.02, w=12.0, h=3.9):
        from PIL import Image
        path = ASSETS / (name + ".png")
        with Image.open(path) as im:
            ratio = im.width / im.height
            pixels = im.size
            opaque = "A" not in im.getbands() or im.getchannel("A").getextrema() == (255, 255)
        iw, ih = min(w, h*ratio), min(h, w/ratio)
        if name.startswith("eq_"):
            ppi = min(pixels[0]/iw, pixels[1]/ih)
            assert opaque and ppi >= 300, (name, opaque, ppi)
            self.equation_checks.append({"slide": len(self.prs.slides), "asset": name,
                                         "effective_ppi": round(ppi, 1), "opaque": opaque})
        self.media_boxes.append((len(self.prs.slides), name, x+(w-iw)/2, y+(h-ih)/2, iw, ih))
        picture = self.s.shapes.add_picture(str(path), Inches(x+(w-iw)/2), Inches(y+(h-ih)/2),
                                          width=Inches(iw), height=Inches(ih))
        picture._element.nvPicPr.cNvPr.set("descr", name)

    def photo(self, name, top, x=.65, y=2.02, w=7.45, h=4.4):
        from PIL import Image
        path = ASSETS / (name + ".jpg")
        if not path.exists():
            path = ASSETS / (name + ".png")
        with Image.open(path) as source:
            ratio = source.width / source.height
        self.media_boxes.append((len(self.prs.slides), name, x, y, w, h))
        picture = self.s.shapes.add_picture(str(path), Inches(x), Inches(y),
                                            width=Inches(w), height=Inches(h))
        if ratio <= w/h:
            visible_fraction = ratio*h/w
            assert 0 <= top <= 1-visible_fraction
            picture.crop_top = top
            picture.crop_bottom = 1-top-visible_fraction
        else:
            fraction = w/(h*ratio)
            picture.crop_left = picture.crop_right = (1-fraction)/2
        picture._element.nvPicPr.cNvPr.set("descr", name)

    def flow(self, points, color):
        for index, (a, b) in enumerate(zip(points, points[1:])):
            connector = self.s.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,
                Inches(a[0]), Inches(a[1]), Inches(b[0]), Inches(b[1]))
            connector.line.color.rgb = RGBColor.from_string(color)
            connector.line.width = Pt(2)
            connector._element.spPr.append(OxmlElement("a:effectLst"))
            for effect in connector._element.xpath(".//a:effectRef"):
                effect.set("idx", "0")
            if index == len(points)-2:
                tip = OxmlElement("a:tailEnd")
                tip.set("type", "triangle")
                tip.set("w", "med")
                tip.set("len", "med")
                connector._element.spPr.get_or_add_ln().append(tip)

    def column(self, x, title, body, w=5.55, color=TEAL):
        self.rule(x, 2.12, .7, color)
        self.text(title, x, 2.42, w, .7, 26, color, True)
        self.text(body, x, 3.25, w, 2.72, 24)

    def arrow(self, x, y, w=.7, color=CORAL, left=False):
        self.shape(x, y, w, .28, color, MSO_SHAPE.LEFT_ARROW if left else MSO_SHAPE.RIGHT_ARROW)

    def plot_sidebar(self, title, name, items, section="03 / How we explored"):
        self.slide(title, section)
        self.image(name, .5, 2.03, 8.65, 3.95)
        self.shape(9.42, 2.18, .02, 3.43, LINE)
        for j, (head, body, color) in enumerate(items):
            y = 2.22 + j*1.85
            self.text(head, 9.7, y, 2.9, .55, 24, color, True)
            self.text(body, 9.7, y+.7, 2.9, 1.05, 24, MUTED)


def build():
    raw = (DOCS / "beyond_borders_general_audience.md").read_text()
    meta = yaml.safe_load(raw.split("---", 2)[1])
    blocks = re.split(r"^## ", raw, flags=re.M)[1:]
    notes = ["Timing: 40 seconds.\nShlok Mishra, second-year PhD student in Statistics, Texas A&M University. Faculty advisors: Dr. Patricia Ning and Dr. Bani Mallick (co-supervisor).\n" + meta["institute"]]
    notes += [re.search(r"::: notes\n(.*?)\n:::", b, re.S).group(1) for b in blocks]
    assert len(notes) == 28
    if not args.reuse_assets:
        prepare()
        prepare_feedback()
    d = Deck(notes)

    d.slide("", "Beyond Borders Fellows' Symposium / Paris, France", dark=True)
    d.text("What Can One\nNumber Reveal?", .72, 1.0, 11.7, 1.9, 48, WHITE, True)
    d.text("Reconstructing uncertainty from a published estimate", .77, 3.05, 11.8, .65, 27, "C4E0D8")
    d.rule(.77, 4.01, .8, CORAL)
    d.text("Shlok Mishra", .77, 4.22, 11.8, .55, 28, WHITE, True)
    d.text("Second-year PhD student in Statistics\nDepartment of Statistics, Texas A&M University", .77, 4.85, 11.8, .85, 24, "C4E0D8")
    d.text("Faculty advisor: Dr. Patricia Ning\nCo-supervisor: Dr. Bani Mallick", .77, 5.94, 11.8, .85, 24, "C4E0D8")

    d.slide("A public number, a private dataset", "Opening scenario")
    d.column(.7, "An organization publishes", "An estimated population center.\n\nThe individual observations remain private.")
    d.column(6.9, "An observer tries to infer", "How certain is that center?\n\nCould the hidden data contain unusual observations?", color=CORAL)
    d.caption("The distinction: learning about a population versus learning about its hidden data.")

    d.slide("Paris: a city and a campus", "01 / The setting", title_height=.6)
    d.text("Paris, France", .7, 1.8, 7.5, .45, 25, TEAL, True)
    d.text("Home at CIUP", 8.65, 1.8, 3.95, .45, 25, CORAL, True)
    d.photo("IMG_7897_bright", .16, x=.7, y=2.38, w=7.5, h=3.56)
    d.photo("IMG_1995", .25, x=8.65, y=2.38, w=3.95, h=3.56)
    d.caption("Home at CIUP; research with Christian's group at PariSanté Campus.")
    d.text("CIUP: Cité internationale universitaire de Paris.", .7, 6.77, 11.9, .2, 12, MUTED)

    d.slide("People I worked with", "01 / CEREMADE")
    d.photo("IMG_3665", .205)
    d.text("Christian P. Robert", 8.55, 2.23, 4.05, .95, 26, TEAL, True)
    d.text("CEREMADE\nUniversité Paris\nDauphine–PSL", 8.55, 3.17, 4.05, 1.3, 24)
    d.text("Antoine Luciano", 8.55, 4.65, 4.05, .6, 26, CORAL, True)
    d.text("Christian's former PhD;\nnow an Oxford postdoc.", 8.55, 5.47, 4.05, 1.12, 24)
    d.text("Research group", .65, 6.57, 7.45, .3, 15, MUTED)

    d.slide("OCEAN: foundations for learning and privacy", "01 / Why this group, in Paris")
    d.column(.7, "An ERC Synergy project",
             "Foundations for learning and decision-making when data are distributed.")
    d.column(6.9, "Christian's group",
             "Developing a new decision-theoretic privacy framework.\n\nMy contribution: inference from a released estimate.", color=CORAL)
    d.caption("OCEAN = On intelligenCE And Networks. ERC = European Research Council.")
    d.s.notes_slide.notes_text_frame.text += "\nOfficial project report: https://cordis.europa.eu/project/id/101071601/reporting"

    d.slide("One estimate leaves many possibilities", "02 / Why a posterior?")
    d.column(.7, "An estimate is uncertain",
             "A fitted center varies from sample to sample.\n\nOne number does not describe our remaining uncertainty.")
    d.column(6.9, "Possibilities need weights",
             "Combine a statistical model, prior beliefs and the release.\n\nThe posterior assigns probabilities to what remains possible.", color=CORAL)
    d.caption("We seek uncertainty about the population and hidden data, not one guessed reconstruction.")

    d.slide("Likelihood: how well does a center fit the data?", "03 / Essential ideas")
    d.text("Keep the observations unchanged. Try different population centers.",
           .7, 2.02, 12, .65, 24, TEAL)
    d.image("talk_likelihood_clear", .65, 2.68, 12, 3.25)
    d.caption("The highest peak is the maximum-likelihood estimate (MLE). The lower peak is a worse fit.")

    d.slide("Posterior: uncertainty after the release", "03 / Essential ideas")
    d.image("talk_posterior_intuition", .55, 1.98, 12.1, 4.08)
    d.caption("Shaded area represents probability. Dots are simulated possibilities, not the hidden records.")
    d.text("Conceptual illustration, not an experimental result.", .7, 6.77, 11.9, .2, 12, MUTED)

    d.slide("Why sample on a thin set?", "03 / From the release to a constraint", title_height=.6)
    d.image("talk_student_manifold_3d", .2, 1.7, 8.4, 4.4)
    d.text("One point = one dataset", 8.75, 2.08, 3.9, .95, 25, TEAL, True)
    d.text("Three observations.\nOne score equation.\nTwo dimensions remain.", 8.75, 3.2, 3.9, 1.65, 24)
    d.text("Unconstrained draws almost surely miss it.", 8.75, 4.94, 3.9, .95, 24, CORAL)
    d.caption("Student k = 2, n = 3, release = 0. This is the score-zero surface, not yet exact MLE conditioning.")

    d.slide("Gibbs alternates two conditional updates", "03 / Our approach")
    d.text("A / Update the center", .95, 2.35, 5.0, .5, 26, TEAL, True)
    d.text("Hold the dataset fixed.\n\nPropose a new center; accept or reject using its posterior density.",
           .95, 3.12, 5.0, 1.95, 24)
    d.text("B / Update the data", 7.4, 2.35, 5.0, .5, 26, CORAL, True)
    d.text("Hold the center fixed.\n\nChange the observations within the constrained set.",
           7.4, 3.12, 5.0, 1.95, 24)
    d.arrow(6.22, 2.48, w=.64, color=TEAL)
    d.flow([(9.9, 5.22), (9.9, 5.70), (3.45, 5.70), (3.45, 5.22)], CORAL)
    d.caption("A Metropolis-within-Gibbs sampler: repeat the two updates to build a chain.")

    d.slide("The algebra turns a nonlinear constraint linear", "04 / Outcome 1: the Student construction")
    d.text("Each observation contributes a score relative to the release.",
           .7, 2.1, 11.9, .5, 26)
    d.image("eq_score", .8, 2.88, 11.6, 1.72)
    for x, head, body, color in [
        (.75, "x: hidden data", "t: released estimate", TEAL),
        (5.02, "z: score contribution", "All scores must sum to zero.", CORAL)]:
        d.text(head, x, 4.77, 7.25 if x > 1 else 4.1, .5, 25, color, True)
        d.text(body, x, 5.38, 7.25 if x > 1 else 4.1, .65, 24)
    d.caption("k controls Student tail heaviness. Score zero is necessary for a fitted center, not sufficient.")

    d.slide("Change two scores; keep their sum fixed", "04 / Outcome 1: a worked update")
    d.text("Before", 1.1, 2.5, 2.1, .5, 25, TEAL, True)
    d.image("eq_pair_before", 4.0, 2.31, 6.8, .62)
    d.text("Proposed", 1.1, 3.84, 2.15, .5, 25, CORAL, True)
    d.image("eq_pair_after", 4.0, 3.65, 6.8, .62)
    d.rule(1.1, 3.25, 10.9)
    d.text("Add 0.08 to one score. Subtract 0.08 from its partner.", 1.1, 5.0, 11.0, .65, 24)
    d.caption("The pair still sums to 0.04. Every other score stays fixed.")

    d.slide("Feasibility is only the first step", "04 / Outcome 1: complete the update")
    for x, number, head, body, color in [
        (.75, "01", "Propose", "Keep both scores\nin their allowed range.", TEAL),
        (4.95, "02", "Accept or reject", "Use density weights\nand proposal correction.", CORAL),
        (9.15, "03", "Repeat", "Visit the other pairs\nin a random order.", LILAC)]:
        d.text(number, x, 2.4, 2.0, .7, 38, color, True)
        d.text(head, x, 3.43, 3.45, .55, 25, color, True)
        d.text(body, x, 4.32, 3.45, 1.3, 24)
    d.caption("Preserving the equation keeps a move feasible; the probability rule gives it the right weight.")

    d.plot_sidebar("Returning to data: one score, two observations", "talk_branches", [
        ("A / Nearby", "Near the\nrelease.", TEAL),
        ("B / Extreme", "Same score.\nFarther away.", CORAL)], "04 / Outcome 1: inverse branches")
    d.caption("The Student map is not one-to-one. Keeping both inverse solutions permits branch changes.")

    d.slide("Both branches matter, but not equally", "04 / Outcome 1: the probability rule")
    d.column(.7, "Plausibility",
             "The Student density favors values compatible with the current population center.")
    d.column(6.9, "Coordinate distortion",
             "The inverse Jacobian corrects the change from observations to scores.", color=CORAL)
    d.caption("A branch needs both factors. A nearby solution is not automatically the only plausible one.")

    d.slide("Turn weights into branch probabilities", "04 / Outcome 1: the probability rule")
    d.image("eq_weight", 1.1, 2.34, 11.1, 1.42)
    d.text("y is the observation minus the released estimate.", .95, 4.18, 11.4, .55, 24)
    d.text("The derivative measures the score-map slope.", .95, 4.96, 11.4, .55, 24)
    d.caption("Calculate both weights, normalize them, then draw a branch. Not a 50/50 coin flip.")

    d.slide("The same strategy simplifies in other models", "04 / Outcome 1: related constructions")
    d.column(.7, "Logistic: one inverse",
             "Its score map is monotone.\n\nPreserve the pair sum, then invert uniquely: no branch lottery.")
    d.column(6.9, "Laplace: fix the median",
             "For odd n, keep the middle observation at the release.\n\nUpdate the others below or above it.", color=CORAL)
    d.caption("Student, Logistic, Laplace: location-only and scale-only studied; joint location-scale is next.")

    d.slide("KDE: simulate once, shift, update uncertainty", "04 / Outcome 2: an independent reference")
    d.image("talk_kde_shift", .5, 2.0, 7.8, 3.95)
    d.text("50,000 centered datasets", 8.65, 2.12, 3.95, .9, 24, TEAL, True)
    d.text("Compute their fitted centers. Smooth this sample into a density.", 8.65, 3.14, 3.95, 1.25, 24)
    d.text("Shift for a candidate center, then multiply by its prior density.", 8.65, 4.65, 3.95, 1.25, 24, CORAL)
    d.image("eq_shift", .7, 6.06, 5.0, .56)
    d.image("eq_posterior", 6.0, 6.06, 6.5, .56)
    d.text("KDE = kernel density estimation.", .7, 6.77, 11.9, .2, 12, MUTED)

    d.slide("RATTLE: a constrained-motion comparator", "04 / Outcome 3: computational comparison")
    d.column(.7, "Gibbs: use the algebra",
             "Change score pairs.\n\nSample inverse branches.\n\nAvoid a full-data projection solve.")
    d.column(6.9, "RATTLE: use the geometry",
             "Propose a trajectory.\n\nProject back to the constraint.\n\nCheck the reverse move.", color=CORAL)
    d.caption("Both methods require probability corrections. Different update costs motivate the comparison.")

    d.slide("One release narrows the center, not to a point", "04 / Outcome 3: new long-chain evidence", title_height=.6)
    d.text("95% intervals: KDE [-0.86, 0.87]; prior [-19.6, 19.6].", .7, 1.52, 11.9, .4, 24, TEAL)
    d.image("talk_long_posterior", .55, 1.98, 12.0, 4.05)
    d.caption("Gibbs and RATTLE: score-conditioned. Shifted KDE: selected-MLE reference. Compare, do not equate.")
    d.text("Student: k = 2, n = 10, scale = 1, release = 0. Normal prior: mean 0, SD 10. Four chains per method; 200,000 updates each.",
           .7, 6.77, 11.9, .2, 12, MUTED)

    d.slide("The center is not the whole hidden dataset", "04 / Outcome 3: inspect the chains")
    d.image("talk_trace_focus", .5, 1.98, 12.1, 4.08)
    d.caption("First 2,000 retained steps, seed 101. Both centers move; Gibbs makes larger upper-tail excursions here.")

    d.slide("What does one second of computation buy?", "04 / Outcome 3: efficiency at these settings")
    d.image("talk_efficiency_focus", .5, 1.98, 12.1, 4.08)
    d.caption("Effective sample size (ESS) adjusts for dependence. Fixed tuning; these summaries cannot certify global mixing.")
    d.text("Per-sweep cost: Gibbs 7.3 microseconds; RATTLE 43.5. Timings include burn-in and state storage, exclude compilation.",
           .7, 6.77, 11.9, .2, 12, MUTED)

    d.slide("The late discovery: Student's best fit moved", "05 / The late discovery")
    d.image("talk_exit", .45, 2.05, 7.6, 3.9)
    d.text("Student location", 8.48, 2.1, 4.1, .55, 25, CORAL, True)
    d.text("Not concave.\nZero score can miss\nthe best fit.", 8.48, 2.78, 4.1, 1.2, 24)
    d.text("Logistic and Laplace", 8.48, 4.05, 4.1, .55, 24, TEAL, True)
    d.text("Concave log likelihood.\nUnique: Logistic;\nLaplace with odd n.", 8.48, 4.75, 4.1, 1.22, 24)
    d.caption("Known scale. Even-n Laplace can have an interval of maximizers. No blanket joint location-scale claim.")

    d.slide("What remains before exact inference?", "05 / Challenges, significance and next steps")
    for y, head, body, color in [
        (2.1, "Correct the target", "Account for the selected maximum and its Jacobian factor.", TEAL),
        (3.19, "Validate exploration", "Stress-test tail exploration and initialization sensitivity.", CORAL),
        (4.28, "Extend the method", "Check KDE sensitivity; make location and scale unknown together.", LILAC)]:
        d.text(head, .72, y, 4.05, .8, 25, color, True)
        d.text(body, 5.08, y, 7.4, .95, 24)
        d.rule(.72, y+.99, 11.9)
    d.caption("Reliable inference from limited releases is a building block, not itself a privacy guarantee.")

    d.slide("What the international experience changed", "06 / Fellows reflection")
    for x, num, head, body, color in [
        (.7, "01", "Translate", "Connect privacy\nquestions to explicit\nstatistical models.", TEAL),
        (4.9, "02", "Collaborate", "Link theory and code\nthrough discussion\nwith the host group.", LILAC),
        (9.0, "03", "Reconsider", "Let an unexpected\nresult change the\nresearch question.", CORAL)]:
        d.text(num, x, 2.3, 2, .93, 48, color, True)
        d.text(head, x, 3.62, 3.6, .6, 28, color, True)
        d.text(body, x, 4.49, 3.65, 1.57, 24)
    d.caption("Paris supplied the collaborators and setting for this shift from implementation to foundations.")

    d.slide("Three takeaways", "06 / Closing")
    takeaways = [
        "Exploit the algebra: a difficult constraint becomes a pairwise update.",
        "Use the shift identity: one simulation bank gives a numerical reference.",
        "Measure cost and exploration, then verify the exact inferential target."]
    for i, text in enumerate(takeaways):
        y = 2.04+i*1.02
        d.text(f"0{i+1}", .72, y, .85, .58, 29, [TEAL, LILAC, CORAL][i], True)
        d.text(text, 1.85, y, 10.75, .88, 25, INK, True)
    d.rule(.72, 5.3, 11.9)
    d.text("With thanks", .72, 5.63, 2.4, .43, 21, TEAL, True)
    d.text("Dr. Patricia Ning · Dr. Bani Mallick (co-supervisor)\nChristian P. Robert · Antoine Luciano\nTexas A&M · CEREMADE · OCEAN ERC · CIUP · Beyond Borders\nMSC L.T. Jordan Institute", 3.3, 5.46, 9.2, 1.4, 20)

    d.slide("", "Questions", dark=True)
    d.text("What can one\npublished number reveal?", .75, 1.6, 11.9, 2.1, 44, WHITE, True)
    d.rule(.8, 4.31, .85, CORAL)
    d.text("Shlok Mishra", .8, 4.76, 11.6, .7, 31, WHITE, True)
    d.text("Research visit in Paris, France\nWith Christian P. Robert and Antoine Luciano", .8, 5.65, 11.5, .95, 24, "C4E0D8")

    d.slide("Selected references", "References / after the talk", title_height=.6)
    references = [
        ("Metropolis-Hastings", "Hastings (1970). Biometrika 57(1), 97–109.", "https://doi.org/10.1093/biomet/57.1.97"),
        ("Kernel density estimation", "Silverman (1986). Density Estimation for Statistics and Data Analysis.", "https://ned.ipac.caltech.edu/level5/March02/Silverman/Silver_contents.html"),
        ("RATTLE", "Andersen (1983). Journal of Computational Physics 52(1), 24–34.", "https://doi.org/10.1016/0021-9991(83)90014-1"),
        ("MCMC diagnostics", "Vehtari et al. (2021). Bayesian Analysis 16(2), 667–718.", "https://doi.org/10.1214/20-BA1221"),
        ("Conditioning on a manifold", "Diaconis, Holmes & Shahshahani (2013). IMS Collections 10, 102–125.", "https://doi.org/10.1214/12-IMSCOLL1006"),
        ("Location models", "SciPy User Guide: Logistic and Laplace distributions.", "https://docs.scipy.org/doc/scipy/tutorial/stats/continuous_laplace.html")]
    for i, (label, citation, url) in enumerate(references):
        y = 1.8+i*.78
        d.text(label, .72, y, 11.8, .34, 19, TEAL, True)
        shape = d.text(citation, .72, y+.36, 11.8, .36, 19)
        for p in shape.text_frame.paragraphs:
            for run in p.runs:
                run.hyperlink.address = url
                run.font.underline = False
                run.font.color.rgb = RGBColor.from_string(INK)
    context = d.text("Project context: European Commission, OCEAN. Full titles and source links are in the notes.",
                     .72, 6.64, 11.8, .26, 14, MUTED)
    for paragraph in context.text_frame.paragraphs:
        for run in paragraph.runs:
            run.hyperlink.address = "https://cordis.europa.eu/project/id/101071601/reporting"
            run.font.underline = False
            run.font.color.rgb = RGBColor.from_string(MUTED)

    # Check content boxes, including intentional blank space, before replacing a deck.
    errors = list(d.fit_errors)
    for i, name, x, y, w, h in d.boxes:
        if x < 0 or y < 0 or x+w > W+.001 or y+h > H+.001:
            errors.append(f"Out of bounds on slide {i}: {name}")
    for a, first in enumerate(d.boxes):
        i, name, x, y, w, h = first
        for j, other, ox, oy, ow, oh in d.boxes[a+1:]:
            if j == i and min(x+w, ox+ow)-max(x, ox) > .025 and min(y+h, oy+oh)-max(y, oy) > .025:
                errors.append(f"Text boxes overlap on slide {i}: {name} / {other}")
    for i, name, x, y, w, h in d.media_boxes:
        if x < 0 or y < 0 or x+w > W+.001 or y+h > H+.001:
            errors.append(f"Image out of bounds on slide {i}: {name}")
        for j, other, ox, oy, ow, oh in d.boxes:
            if j == i and min(x+w, ox+ow)-max(x, ox) > .025 and min(y+h, oy+oh)-max(y, oy) > .025:
                errors.append(f"Image/text overlap on slide {i}: {name} / {other}")
    if errors:
        raise ValueError("\n".join(errors))
    assert len(d.prs.slides) == len(notes) == 28
    PREVIEW.mkdir(parents=True, exist_ok=True)
    target = DOCS / "beyond_borders_general_audience.pptx"
    backup = PREVIEW / "beyond_borders_general_audience_before_polish.pptx"
    if target.exists() and not backup.exists():
        shutil.copy2(target, backup)
    candidate = PREVIEW / "beyond_borders_general_audience.pptx"
    d.prs.save(candidate)
    reopened = Presentation(candidate)
    assert len(reopened.slides) == 28
    assert all(s.has_notes_slide and s.notes_slide.notes_text_frame.text for s in reopened.slides)
    assert len(d.equation_checks) == 6
    timings = [int(re.search(r"Timing: (\d+) seconds", note).group(1)) for note in notes]
    assert sum(timings) <= 1800
    (PREVIEW / "methods_talk_structure.json").write_text(json.dumps({
        "slides": len(notes), "aspect_ratio": "16:9", "seconds_per_slide": timings,
        "total_seconds": sum(timings), "findings_seconds": sum(timings[10:22]),
        "text_fit_errors": 0, "image_text_overlaps": 0,
        "notes_on_every_slide": True, "media": d.media_boxes,
        "equations": d.equation_checks, "equation_embedding": "ordinary opaque PNG; no SVG override",
    }, indent=2)+"\n")
    if args.publish:
        shutil.copy2(candidate, target)
    print(f"Built {candidate}: {len(notes)} slides; notes on all slides; no text-box overlaps or overflow.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publish", action="store_true", help="Replace the current deck after structural checks.")
    parser.add_argument("--reuse-assets", action="store_true", help="Reuse previously generated scientific figures for layout-only iterations.")
    args = parser.parse_args()
    build()
