"""Figures for the methods-centered talk; frozen evidence, no new MCMC runs."""

import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import cumulative_trapezoid, trapezoid
from scipy.stats import gaussian_kde, norm

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "docs/presentation"
ASSETS = DOCS / "Images/general_audience/polished"
INK, TEAL, CORAL, BG, LINE = "#183B3A", "#16766D", "#C45546", "#F0F5F4", "#CEDDD9"


def prepare():
    ASSETS.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 24, "axes.labelsize": 26,
        "text.color": INK, "axes.labelcolor": INK, "axes.edgecolor": LINE,
        "xtick.color": INK, "ytick.color": INK, "mathtext.fontset": "stix",
        "figure.facecolor": BG, "axes.facecolor": BG, "savefig.facecolor": BG,
        "pdf.fonttype": 42,
    })

    def save(fig, name):
        fig.savefig(ASSETS / (name + ".png"), dpi=240, bbox_inches="tight", pad_inches=.12)
        fig.savefig(ASSETS / (name + ".pdf"), bbox_inches="tight", pad_inches=.12)
        plt.close(fig)

    def axes(width=8.8, height=4.35):
        fig, ax = plt.subplots(figsize=(width, height))
        fig.subplots_adjust(left=.15, right=.97, bottom=.24, top=.88)
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", color=LINE, lw=.8)
        ax.set_axisbelow(True)
        return fig, ax

    mu = np.linspace(-9, 9, 1800)
    normal = np.array([-1.3, -.8, -.2, .1, .4, .9, 1.2])
    student = np.array([-5.5, -5.1, -4.8, -4.6, 4.7, 5.0])
    curves = [-.5*np.sum((normal[:, None]-mu)**2, axis=0),
              -np.sum(np.log1p((student[:, None]-mu)**2), axis=0)]
    fig, axs = plt.subplots(1, 2, figsize=(12, 3.7))
    fig.subplots_adjust(left=.105, right=.98, bottom=.26, top=.78, wspace=.33)
    for ax, curve, title, color in zip(axs, curves,
            ("Normal: one peak", "Student: competing peaks"), (TEAL, CORAL)):
        curve -= curve.max()
        ax.plot(mu, curve, color=color, lw=3)
        ax.set_title(title, fontsize=24, loc="left", pad=16)
        ax.set_xlabel("Candidate center", fontsize=24)
        ax.spines[["top", "right"]].set_visible(False)
        ax.set_xticks([-8, 0, 8])
        ax.tick_params(labelsize=22)
    axs[0].set_ylabel("Relative log likelihood", fontsize=23)
    peaks = np.flatnonzero((curves[1][1:-1] > curves[1][:-2]) &
                          (curves[1][1:-1] > curves[1][2:])) + 1
    assert len(peaks) == 2 and abs(np.diff(curves[1][peaks])[0]) > 2
    best = peaks[np.argmax(curves[1][peaks])]
    axs[1].scatter(mu[best], 0, s=85, color=INK, zorder=3)
    axs[1].annotate("Best fit", (mu[best], 0), xytext=(.46, .83),
                    textcoords="axes fraction", fontsize=23,
                    arrowprops={"arrowstyle": "->", "color": INK})
    save(fig, "talk_hills")

    fig, ax = axes()
    grid = np.linspace(-3, 3, 600)
    density = norm.pdf(grid, .15, .75)
    ax.plot(grid, density, color=TEAL, lw=3)
    ax.fill_between(grid, 0, density, where=(grid >= -.5) & (grid <= .8), color=TEAL, alpha=.22)
    draws = np.random.default_rng(20260904).normal(.15, .75, 22)
    ax.scatter(draws, np.full_like(draws, -.045), s=38, color=CORAL)
    ax.set(xlabel="Possible population center", ylabel="Probability density", ylim=(-.08, .6))
    ax.set_yticks([0, .2, .4])
    save(fig, "talk_sampling")

    fig, ax = plt.subplots(figsize=(7.5, 4.05))
    fig.subplots_adjust(left=.16, right=.97, bottom=.24, top=.93)
    line = np.linspace(-3.5, 3.5, 100)
    ax.plot(line, -line, color=TEAL, lw=3)
    ax.scatter([-2, 0, 2], [2, 0, -2], color=TEAL, s=100, zorder=3)
    ax.scatter([2], [1.7], color=CORAL, marker="x", s=120, linewidth=3, zorder=3)
    ax.text(-3.25, -2.8, "Mean = 0", color=TEAL, fontsize=24)
    ax.text(.7, 2.65, "Not compatible", color=CORAL, fontsize=22)
    ax.set(xlabel=r"First observation $x_1$", ylabel=r"Second observation $x_2$",
           xlim=(-3.5, 3.5), ylim=(-3.5, 3.5), xticks=[-3, 0, 3], yticks=[-3, 0, 3])
    ax.spines[["top", "right"]].set_visible(False)
    ax.axhline(0, color=LINE, lw=.8, zorder=0)
    ax.axvline(0, color=LINE, lw=.8, zorder=0)
    save(fig, "talk_manifold_motivation")

    fig, ax = axes()
    y, k, z = np.linspace(-8, 8, 1600), 2., .2
    roots = np.array([(1-np.sqrt(1-4*k*z*z))/(2*z), (1+np.sqrt(1-4*k*z*z))/(2*z)])
    assert np.allclose(roots/(k+roots**2), z)
    ax.plot(y, y/(k+y*y), color=TEAL, lw=3)
    ax.axhline(z, color=CORAL, ls="--", lw=1.8)
    ax.scatter(roots, [z, z], c=[TEAL, CORAL], s=120, zorder=3)
    for root, label, color in zip(roots, ("A", "B"), (TEAL, CORAL)):
        ax.text(root, z-.14, label, color=color, ha="center", weight="bold")
    ax.set(xlabel="Residual: observation minus release", ylabel="Score contribution", ylim=(-.4, .4))
    ax.set_yticks([-.4, 0, .4])
    save(fig, "talk_branches")

    bank_path = DOCS / "evidence/long_chain_study/reference.npz"
    bank = np.load(bank_path)["mle"]
    assert len(bank) == 50000 and np.isfinite(bank).all()
    kde = gaussian_kde(bank, bw_method="scott")
    fig, ax = axes()
    grid = np.linspace(-2.5, 4, 700)
    for center, color, ls in ((0, TEAL, "-"), (1.5, CORAL, "--")):
        ax.plot(grid, kde(grid-center), color=color, ls=ls, lw=3, label=rf"$\mu={center:g}$")
    ax.legend(frameon=False, ncol=2, fontsize=24, loc="lower center", bbox_to_anchor=(.5, 1.02))
    ax.set(xlabel=r"Released estimate $t$", ylabel="Probability density")
    ax.set_yticks([0, .5, 1])
    save(fig, "talk_kde_shift")

    grid = np.linspace(-40, 40, 8001)
    prior = norm.pdf(grid, 0, 10)
    posterior = prior*kde(-grid)
    posterior /= trapezoid(posterior, grid)
    assert np.isclose(trapezoid(posterior, grid), 1)
    cdf = cumulative_trapezoid(posterior, grid, initial=0)
    interval = np.interp([.025, .975], cdf, grid)
    fig, ax = axes()
    ax.plot(grid, prior, color=CORAL, ls="--", lw=3, label="Prior")
    ax.plot(grid, posterior, color=TEAL, lw=3, label="KDE posterior")
    ax.fill_between(grid, 0, posterior, where=(grid >= interval[0]) & (grid <= interval[1]), color=TEAL, alpha=.15)
    ax.legend(frameon=False, fontsize=23, ncol=2, loc="lower center", bbox_to_anchor=(.5, 1.02))
    ax.set(xlabel=r"Population center $\mu$", ylabel="Probability density", xlim=(-3, 3))
    ax.set_yticks([0, .5, 1])
    save(fig, "talk_kde_posterior")

    source = DOCS / "evidence/gibbs_rattle_profile/student_sampler_profile_summary.csv"
    with source.open() as handle:
        rows = list(csv.DictReader(handle))
    ns = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000]
    values = {}
    for name, key, multiplier, ylabel in (
            ("talk_iteration_cost", "sec_per_iteration_mean", 1000, "Time per iteration (ms)"),
            ("talk_ess_rate", "ess_mu_per_sec_mean", 1, "Effective samples\nper second")):
        fig, ax = axes()
        for method, label, color, marker, ls in (
                ("gibbs_numba_full", "Gibbs", TEAL, "o", "-"),
                ("rattle", "RATTLE", CORAL, "s", "--")):
            selected = sorted((r for r in rows if r["method"] == method), key=lambda r:int(r["n"]))
            assert [int(r["n"]) for r in selected] == ns
            assert all(float(r["k"]) == 2 and int(r["num_seeds"]) == 3 for r in selected)
            raw_values = np.array([float(r[key]) for r in selected])
            vals = raw_values*multiplier
            values.setdefault(method, {})[key] = raw_values.tolist()
            ax.plot(ns, vals, color=color, marker=marker, ls=ls, lw=3, ms=6, label=label)
        ax.set_xscale("log")
        ax.set_yscale("log")
        ax.minorticks_off()
        ax.set_xticks([10, 100, 1000, 10000], ["10", "100", "1,000", "10,000"])
        ax.tick_params(axis="x", labelsize=22)
        ax.set_xlabel(r"Sample size $n$")
        ax.set_ylabel(ylabel, fontsize=24)
        ax.legend(frameon=False, ncol=2, fontsize=24, loc="lower center", bbox_to_anchor=(.5, 1.02))
        save(fig, name)
    ratios = np.array(values["rattle"]["sec_per_iteration_mean"])/np.array(values["gibbs_numba_full"]["sec_per_iteration_mean"])
    assert (ratios[:-1] > 1).all() and .9 < ratios[-1] < 1.1

    with (ROOT / "results/student_n3_branch_components_clean/likelihood_curves.csv").open() as handle:
        rows = [r for r in csv.DictReader(handle) if r["event_id"] == "Gibbs k=2, seed=0 exit"]
    fig, ax = axes()
    for state, color, ls in (("before", TEAL, "-"), ("after", CORAL, "--")):
        selected = [r for r in rows if r["state"] == state]
        ax.plot([float(r["mu"]) for r in selected], [float(r["relative_loglik"]) for r in selected],
                color=color, ls=ls, lw=3, label=state.title())
    ax.axvline(0, color=INK, ls=":", lw=1.2)
    ax.set(xlabel="Candidate center", ylabel="Relative log likelihood")
    ax.legend(frameon=False, ncol=2, fontsize=24, loc="lower center", bbox_to_anchor=(.5, 1.02))
    save(fig, "talk_exit")

    from prepare_talk_equations import prepare_equations
    prepare_equations()
    report = {
        "reference_bank_sha256": hashlib.sha256(bank_path.read_bytes()).hexdigest(),
        "efficiency_summary_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "reference": {"k": 2, "n": 10, "B": 50000, "release": 0, "prior": "Normal(0,10^2)",
                      "bandwidth": "Scott", "kde_posterior_95pct_interval": interval.tolist()},
        "efficiency": {"n": ns, "iterations": 3000, "discarded": 500, "seeds": [0, 1, 2],
                       "timing_values_unit": "seconds per iteration; plot multiplies by 1000", "values": values,
                       "caveat": "Warmed instrumented fixed-setting profiles; local mu ESS, not global or latent mixing."},
        "mcmc_note": "This asset preparer runs no chains. Current talk uses the separate long_chain_study figures, not these legacy efficiency figures.",
    }
    (DOCS / "evidence/gibbs_rattle_profile/talk_asset_provenance.json").write_text(json.dumps(report, indent=2)+"\n")
    return report


if __name__ == "__main__":
    print(json.dumps(prepare(), indent=2))
