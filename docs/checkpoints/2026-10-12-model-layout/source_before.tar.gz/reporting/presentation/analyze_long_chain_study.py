"""Summarize all prespecified runs and produce trace, density and ESS figures."""

import hashlib
import json
from pathlib import Path
import sys

import arviz as az
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import cumulative_trapezoid, trapezoid
from scipy.stats import gaussian_kde, norm

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "docs/presentation/evidence/long_chain_study"
ASSETS = ROOT / "docs/presentation/Images/general_audience/polished"
INK, TEAL, CORAL, BG, LINE = "#183B3A", "#16766D", "#C45546", "#F0F5F4", "#CEDDD9"
METHODS = [("gibbs", "Gibbs", TEAL), ("rattle", "RATTLE", CORAL)]
KEYS = ["mu", "median", "q95"]
LABELS = ["Population center", "Hidden-data median", "Hidden-data 95th percentile"]


def save(fig, name, public=True):
    folder = ASSETS if public else OUT
    fig.savefig(folder / f"{name}.png", dpi=260, bbox_inches="tight", pad_inches=.12)
    fig.savefig(folder / f"{name}.pdf", bbox_inches="tight", pad_inches=.12)
    plt.close(fig)


def style(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=LINE, lw=.8)
    ax.set_axisbelow(True)


def main():
    protocol = json.loads((OUT / "protocol.json").read_text())
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 22,
        "axes.labelsize": 23, "axes.titlesize": 23, "text.color": INK,
        "axes.labelcolor": INK, "axes.edgecolor": LINE, "xtick.color": INK,
        "ytick.color": INK, "figure.facecolor": BG, "axes.facecolor": BG,
        "savefig.facecolor": BG, "pdf.fonttype": 42, "mathtext.fontset": "stix"})
    if "--presentation-only" in sys.argv:
        stats = json.loads((OUT / "summary.json").read_text())["methods"]
        arrays = {}
        for method, _, _ in METHODS:
            chains = [np.load(OUT / f"{method}_{seed}_summaries.npz") for seed in protocol["seeds"]]
            arrays[method] = {key: np.stack([chain[key] for chain in chains]) for key in KEYS}
        render_traces(arrays)
        render_efficiency(stats)
        return
    arrays, stats = {}, {}
    for method, _, _ in METHODS:
        chains = [np.load(OUT / f"{method}_{seed}_summaries.npz") for seed in protocol["seeds"]]
        metadata = [json.loads((OUT / f"{method}_{seed}.json").read_text()) for seed in protocol["seeds"]]
        elapsed = sum(m["elapsed_seconds"] for m in metadata)
        arrays[method] = {key: np.stack([chain[key] for chain in chains]) for key in KEYS}
        stats[method] = {"elapsed_seconds_total": elapsed,
                         "ms_per_iteration": 1000*elapsed/(4*protocol["iterations"]),
                         "chains": metadata, "summaries": {}}
        for key, values in arrays[method].items():
            assert values.shape == (4, protocol["iterations"]-protocol["burn_in"])
            assert np.isfinite(values).all()
            bulk, tail = float(az.ess(values, method="bulk")), float(az.ess(values, method="tail"))
            stats[method]["summaries"][key] = {
                "rank_split_rhat": float(az.rhat(values, method="rank")),
                "bulk_ess": bulk, "tail_ess": tail,
                "bulk_ess_per_second": bulk/elapsed,
                "tail_ess_per_second": tail/elapsed,
                "quantiles": np.quantile(values, [.025, .5, .975]).tolist(),
                "per_chain_quantiles": np.quantile(values, [.025, .5, .975], axis=1).T.tolist(),
                "per_chain_bulk_ess": [float(az.ess(v[None, :], method="bulk")) for v in values],
                "full_range": [float(values.min()), float(values.max())]}

    if "--diagnostics-only" in sys.argv:
        render_diagnostics(arrays, stats, protocol)
        return
    bank = np.load(OUT / "reference.npz")["mle"]
    kde = gaussian_kde(bank)
    grid = np.linspace(-40, 40, 8001)
    prior = norm.pdf(grid, 0, protocol["prior_std"])
    reference = {}
    for multiplier in [.7, 1., 1.3]:
        g = gaussian_kde(bank, bw_method=kde.factor*multiplier)
        density = prior*g(-grid)
        density /= trapezoid(density, grid)
        cdf = cumulative_trapezoid(density, grid, initial=0)
        reference[str(multiplier)] = {"quantiles": np.interp([.025, .5, .975], cdf, grid).tolist(),
                                     "density": density}
    summary = {"protocol": protocol, "methods": stats,
               "reference": {m: {"quantiles": v["quantiles"]} for m, v in reference.items()},
               "arviz_version": az.__version__,
               "reference_sha256": hashlib.sha256((OUT / "reference.npz").read_bytes()).hexdigest()}
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2)+"\n")

    fig, axs = plt.subplots(1, 2, figsize=(12.3, 4.3), gridspec_kw={"width_ratios": [1.5, 1]})
    fig.subplots_adjust(left=.085, right=.98, bottom=.23, top=.78, wspace=.35)
    display = np.linspace(-2.5, 2.5, 600)
    for method, label, color in METHODS:
        # Same KDE bandwidth rule for both marginal estimates; no chain selection.
        values = arrays[method]["mu"]
        for chain in values:
            axs[0].plot(display, gaussian_kde(chain)(display), color=color, lw=.7, alpha=.22)
        axs[0].plot(display, gaussian_kde(values.ravel())(display), color=color, lw=2.7, label=label)
    ref_curves = np.array([np.interp(display, grid, v["density"]) for v in reference.values()])
    axs[0].fill_between(display, ref_curves.min(axis=0), ref_curves.max(axis=0), color=INK, alpha=.12)
    axs[0].plot(display, ref_curves[1], color=INK, ls="--", lw=2.5, label="KDE reference")
    axs[0].set(xlabel=r"Population center $\mu$", ylabel="Probability density", xlim=(-2.5, 2.5))
    axs[0].set_xticks([-2, -1, 0, 1, 2])
    handles, labels = axs[0].get_legend_handles_labels()
    fig.legend(handles, labels, frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(.5, 1.03), fontsize=23)
    for y, (label, color, quantiles) in enumerate([
            ("Gibbs", TEAL, stats["gibbs"]["summaries"]["mu"]["quantiles"]),
            ("RATTLE", CORAL, stats["rattle"]["summaries"]["mu"]["quantiles"]),
            ("KDE ref.", INK, reference["1.0"]["quantiles"]) ]):
        lo, med, hi = quantiles
        axs[1].plot([lo, hi], [2-y, 2-y], color=color, lw=4, solid_capstyle="butt")
        axs[1].scatter([med], [2-y], color=color, s=65, zorder=4)
    axs[1].set(yticks=[2, 1, 0], yticklabels=["Gibbs", "RATTLE", "KDE ref."], ylim=(-.5, 2.5),
               xlabel="Central 95% interval", xlim=(-1.25, 1.25))
    axs[1].set_xticks([-1, 0, 1])
    for ax in axs:
        style(ax)
    save(fig, "talk_long_posterior")
    render_diagnostics(arrays, stats, protocol)
    print(json.dumps({m: {k: v for k, v in stats[m].items() if k != "chains"} for m, _, _ in METHODS}, indent=2))


def render_traces(arrays):
    fig, axs = plt.subplots(2, 3, figsize=(12.3, 4.7), sharex=True, sharey="col")
    fig.subplots_adjust(left=.11, right=.99, bottom=.21, top=.85, wspace=.27, hspace=.20)
    for col, (key, title) in enumerate(zip(KEYS, ["Population center", "Data median", "Data 95th percentile"])):
        combined = np.concatenate([arrays[m][key][0, :2000] for m, _, _ in METHODS])
        for row, (method, name, color) in enumerate(METHODS):
            ax = axs[row, col]
            ax.plot(np.arange(1, 2001), arrays[method][key][0, :2000], color=color, lw=.75)
            ax.set_xticks([0, 1000, 2000], ["0", "1,000", "2,000"])
            ax.tick_params(labelsize=18)
            if key == "q95":
                ax.set_yscale("symlog", linthresh=2)
                ax.set_ylim(0, float(combined.max())*1.12)
                ax.set_yticks([2, 10, 100], ["2", "10", "100"])
                if row == 0:
                    title += "\n(compressed scale)"
            else:
                limit = float(np.abs(combined).max())*1.08
                ax.set_ylim(-limit, limit)
                ax.set_yticks([-2, 0, 2])
            if row == 0:
                ax.set_title(title, fontsize=22, pad=14)
            style(ax)
    fig.text(.018, .69, "Gibbs", rotation=90, va="center", color=TEAL, fontsize=22, weight="bold")
    fig.text(.018, .34, "RATTLE", rotation=90, va="center", color=CORAL, fontsize=22, weight="bold")
    fig.text(.55, .025, "Retained step", ha="center", fontsize=23)
    save(fig, "talk_long_traces")


def render_diagnostics(arrays, stats, protocol):
    render_traces(arrays)
    fig, axs = plt.subplots(3, 2, figsize=(13, 9), sharex=True)
    for col, (method, name, color) in enumerate(METHODS):
        for row, (key, label) in enumerate(zip(KEYS, LABELS)):
            ax = axs[row, col]
            for i, seed in enumerate(protocol["seeds"]):
                # Full retained chain shown as points: never connect subsampled states.
                v = arrays[method][key][i]
                ax.scatter(np.arange(len(v))[::20], v[::20], s=.5, alpha=.18, label=str(seed))
            ax.set_ylabel(label, fontsize=13)
            if key == "q95":
                ax.set_yscale("symlog", linthresh=2)
            if row == 0:
                ax.set_title(name)
            ax.tick_params(labelsize=12)
            style(ax)
    axs[-1, 0].set_xlabel("Retained iteration")
    axs[-1, 1].set_xlabel("Retained iteration")
    fig.tight_layout()
    save(fig, "all_chain_overview", public=False)

    render_efficiency(stats)


def render_efficiency(stats):
    fig = plt.figure(figsize=(12.3, 4.6))
    cost = fig.add_axes([.12, .23, .24, .53])
    rate = fig.add_axes([.605, .23, .365, .53])
    fig.text(.025, .955, "Cost per update", fontsize=25, weight="bold")
    fig.text(.025, .858, "Lower is better", fontsize=20, color=TEAL)
    fig.text(.44, .955, "Effective draws per second", fontsize=25, weight="bold")
    fig.text(.44, .858, "Higher is better", fontsize=20, color=TEAL)
    times = [1000*stats[m]["ms_per_iteration"] for m, _, _ in METHODS]
    cost.barh([1, 0], times, color=[TEAL, CORAL], height=.48)
    cost.set(yticks=[1, 0], yticklabels=["Gibbs", "RATTLE"], xlabel="Microseconds",
             xlim=(0, 60), ylim=(-.6, 1.6), xticks=[0, 20, 40, 60])
    cost.tick_params(labelsize=20)
    for y, value, color in zip([1, 0], times, [TEAL, CORAL]):
        cost.text(value+1.3, y, f"{value:.1f}", va="center", color=color, fontsize=22)
    for row, key in zip([2, 1, 0], KEYS):
        values = [stats[m]["summaries"][key]["bulk_ess_per_second"] for m, _, _ in METHODS]
        rate.plot(values, [row, row], color=LINE, lw=3, zorder=1)
        for i, ((_, label, color), value) in enumerate(zip(METHODS, values)):
            rate.scatter(value, row, s=100, color=color, marker="o" if i == 0 else "s",
                         label=label if row == 2 else None, zorder=3)
            text = f"{value/1000:.0f}k" if value >= 10000 else (f"{value/1000:.1f}k" if value >= 1000 else f"{value:.0f}")
            rate.text(value, row+.18, text, ha="center", color=color, fontsize=20)
    rate.set(xscale="log", xlim=(100, 200000), ylim=(-.55, 2.65),
             yticks=[2, 1, 0], yticklabels=["Center", "Data\nmedian", "Data 95th\npercentile"],
             xlabel="Bulk ESS / second (log scale)")
    rate.set_xticks([100, 1000, 10000, 100000], ["100", "1,000", "10,000", "100,000"])
    rate.tick_params(labelsize=19)
    rate.minorticks_off()
    fig.legend(*rate.get_legend_handles_labels(), ncol=2, frameon=False,
               bbox_to_anchor=(.99, .93), loc="upper right", fontsize=18,
               handlelength=.8, handletextpad=.4, columnspacing=.8)
    for ax in [cost, rate]:
        ax.spines[["top", "right", "left"]].set_visible(False)
        ax.tick_params(axis="y", length=0, pad=8)
        ax.set_axisbelow(True)
        ax.grid(axis="x", color=LINE, lw=.8)
    save(fig, "talk_long_efficiency")


if __name__ == "__main__":
    main()
