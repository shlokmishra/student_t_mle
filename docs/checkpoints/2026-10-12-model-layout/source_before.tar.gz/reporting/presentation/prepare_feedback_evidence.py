"""Prepare user photos and a bounded, reproducible slide diagnostic.

No production code is changed. Raw chains and independently shifted reference
datasets are saved so plots can use consecutive iterations and real quantiles.
"""
from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
OUT = ROOT / "tmp/presentation_feedback_2"
ASSETS = ROOT / "docs/presentation/Images/general_audience/polished"


def photos(source_path=None):
    from PIL import Image, ImageOps
    from pillow_heif import register_heif_opener
    register_heif_opener()
    sources = [
        Path("/home/shlokmishra08/.codex/attachments/c571bd59-5dfd-45a4-936f-0c4d4706220f/IMG_3665.HEIC"),
        Path("/home/shlokmishra08/.codex/attachments/cd32d93f-36cf-4167-9e83-3973c695871b/IMG_1995.HEIC"),
    ]
    if source_path is not None:
        sources = [source_path]
    ASSETS.mkdir(parents=True, exist_ok=True)
    for source in sources:
        with Image.open(source) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            target = ASSETS / (source.stem + ".jpg")
            im.save(target, quality=95)
            print(target, im.size, flush=True)


def diagnostic():
    import hashlib
    import numpy as np
    import jax.random as random
    from models import loc_student, loc_student_rattle
    from models.student_location_mle import global_mle
    OUT.mkdir(parents=True, exist_ok=True)
    params = dict(n=10, k=2., num_iterations_T=20000, proposal_std_mu=.3,
                  proposal_std_z=.02, prior_mean=0., prior_std=10.,
                  initialization="central", initialization_seed=0, store_x_chain=True,
                  gibbs_backend="numba_full", rattle_step_size=.15, rattle_num_steps=20,
                  rattle_proj_tol=1e-10, rattle_proj_max_iters=25,
                  rattle_reverse_position_tol=5e-3,
                  rattle_projection_mode="paper_fixed_direction",
                  rattle_include_gram_correction=True, reverse_check=True)
    destination = OUT / "diagnostic.npz"
    if destination.exists():
        print("Using saved diagnostic:", destination)
        return
    arrays = {}
    keys = random.split(random.PRNGKey(0))
    for name, run, key in [("gibbs", loc_student.run_gibbs, keys[0]),
                           ("rattle", loc_student_rattle.run_rattle, keys[1])]:
        print("Running", name, "20000 iterations", flush=True)
        result = run(key, 0., params.copy(), verbose=False)
        print(name, "keys", list(result), flush=True)
        arrays[name+"_mu"] = np.asarray(result["mu_chain"])
        arrays[name+"_x"] = np.asarray(result["x_chain"])
        assert arrays[name+"_x"].shape == (20001, 10)
        assert np.isfinite(arrays[name+"_x"]).all()
    rng = np.random.default_rng(20260907)
    base = rng.standard_t(2., size=(12000, 10))
    mle = np.empty(len(base))
    print("Computing 12000 independent certified selected MLEs", flush=True)
    for i, sample in enumerate(base):
        mle[i] = global_mle(sample, 2.)
        if (i+1) % 2000 == 0:
            print("Reference datasets:", i+1, flush=True)
    arrays.update(base_data=base, centered_mle=mle, ref_mu=-mle,
                  ref_x=base-mle[:, None], weights=np.exp(-.5*(mle/10.)**2))
    # Translation-equivariance validates the independently shifted datasets.
    residual = max(abs(global_mle(x, 2.)) for x in arrays["ref_x"][::100])
    assert residual < 1e-8
    np.savez_compressed(destination, **arrays)
    sources = ["models/loc_student.py", "models/loc_student_rattle.py", "models/student_location_mle.py"]
    metadata = dict(params=params, burn_in=5000, released_mle=0., reference_seed=20260907,
                    reference_B=len(base), reference_mle="certified selected/global MLE",
                    reference_weights="Normal(0,10) prior at mu=-T(U)",
                    reference_joint_identity="mu=-T(U), X=U-T(U); weight=prior(mu). From t=mu+T(U), dmu=dt.",
                    max_checked_reference_mle_residual=residual,
                    code_sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in sources})
    (OUT/"metadata.json").write_text(json.dumps(metadata, indent=2)+"\n")
    print("Saved", destination, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["photos", "diagnostic"])
    parser.add_argument("--photo-path", type=Path, help="Convert only this supplied photo.")
    args = parser.parse_args()
    if args.action == "photos":
        photos(args.photo_path)
    else:
        diagnostic()
