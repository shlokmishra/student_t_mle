"""Validate equation pixels in the exported PDF and build a flattened PPTX.

The normal deck retains editable text. This companion uses ordinary full-slide
PNG images plus the original speaker notes for viewers with limited support.
"""

import argparse
from io import BytesIO
import json
from pathlib import Path
import zipfile

import numpy as np
import pymupdf as fitz
from PIL import Image, ImageOps, ImageDraw
from pptx import Presentation


def build(pptx, pdf, out):
    out.mkdir(parents=True, exist_ok=True)
    source = Presentation(pptx)
    document = fitz.open(pdf)
    assert len(source.slides) == len(document) > 0
    checks, crops = [], []
    with zipfile.ZipFile(pptx) as archive:
        assert archive.testzip() is None
        assert not any(name.endswith(".svg") for name in archive.namelist())
        assert all(b"svgBlip" not in archive.read(name) for name in archive.namelist()
                   if name.endswith(".xml"))

    for index, slide in enumerate(source.slides):
        page = document[index]
        assert abs(page.rect.width-960) < .1 and abs(page.rect.height-540) < .1
        for font in page.get_fonts(full=True):
            assert document.extract_font(font[0])[3], (index+1, font[3])
        for shape in slide.shapes:
            if shape.shape_type != 13:
                continue
            name = shape._element.nvPicPr.cNvPr.get("descr", "")
            if not name.startswith("eq_"):
                continue
            rect = fitz.Rect(shape.left/12700, shape.top/12700,
                             (shape.left+shape.width)/12700, (shape.top+shape.height)/12700)
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), clip=rect, alpha=False)
            actual = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
            expected = Image.open(BytesIO(shape.image.blob)).convert("RGB").resize(actual.size, Image.Resampling.LANCZOS)
            a, b = np.array(actual).astype(float), np.array(expected).astype(float)
            background = np.array([240, 245, 244])
            actual_ink = np.linalg.norm(a-background, axis=2) > 70
            expected_ink = np.linalg.norm(b-background, axis=2) > 70
            union = np.logical_or(actual_ink, expected_ink).sum()
            iou = float(np.logical_and(actual_ink, expected_ink).sum()/max(1, union))
            assert actual_ink.mean() > .015 and iou > .65, (index+1, name, iou)
            checks.append({"slide": index+1, "equation": name, "rendered_ink_fraction": float(actual_ink.mean()),
                           "source_render_ink_iou": iou})
            crop = ImageOps.contain(actual, (1100, 170))
            crops.append((f"Slide {index+1}: {name}", crop))
    assert len(checks) == 6
    sheet = Image.new("RGB", (1200, len(crops)*210), "#F0F5F4")
    draw = ImageDraw.Draw(sheet)
    for index, (label, crop) in enumerate(crops):
        draw.text((20, index*210+8), label, fill="#183B3A")
        sheet.paste(crop, (35, index*210+35))
    sheet.save(out/"equation_render_check.png")

    portable = Presentation()
    portable.slide_width, portable.slide_height = source.slide_width, source.slide_height
    for index, page in enumerate(document):
        slide = portable.slides.add_slide(portable.slide_layouts[6])
        pix = page.get_pixmap(matrix=fitz.Matrix(300/72, 300/72), alpha=False)
        picture = slide.shapes.add_picture(BytesIO(pix.tobytes("png")), 0, 0,
                                          width=portable.slide_width, height=portable.slide_height)
        picture._element.nvPicPr.cNvPr.set("descr", f"Slide {index+1}; rendered compatibility copy")
        slide.notes_slide.notes_text_frame.text = source.slides[index].notes_slide.notes_text_frame.text
    target = out/"beyond_borders_general_audience_portable.pptx"
    portable.save(target)
    reopened = Presentation(target)
    assert len(reopened.slides) == len(source.slides)
    assert all(len(slide.shapes) == 1 and slide.shapes[0].image.content_type == "image/png"
               for slide in reopened.slides)
    assert all(a.notes_slide.notes_text_frame.text == b.notes_slide.notes_text_frame.text
               for a, b in zip(source.slides, reopened.slides))
    report = {"equations": checks, "pdf_fonts_embedded": True, "slides": len(source.slides),
              "editable_deck_svg_overrides": 0, "portable_slide_dpi": 300,
              "portable_notes_preserved": True, "portable_text_editable": False}
    (out/"compatibility_validation.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pptx", type=Path)
    parser.add_argument("pdf", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    build(args.pptx, args.pdf, args.out)
