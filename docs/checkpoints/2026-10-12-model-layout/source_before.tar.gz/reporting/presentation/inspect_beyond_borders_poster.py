"""Check full-size poster export, text survival, bounds, fonts and images."""
import json
import re
from pathlib import Path
import pymupdf as fitz
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/"tmp/presentation_results_story"


def inspect():
    deck=Presentation(OUT/"beyond_borders_research_poster.pptx")
    pdf=fitz.open(OUT/"beyond_borders_research_poster.pdf")
    assert len(deck.slides)==len(pdf)==1
    page=pdf[0]
    assert abs(page.rect.width-48*72)<.1 and abs(page.rect.height-36*72)<.1
    assert abs(deck.slide_width/914400-48)<1e-5 and abs(deck.slide_height/914400-36)<1e-5
    norm=lambda s:re.sub(r"\s+","",s).replace("\u00ad","")
    actual=norm(page.get_text())
    issues=[]
    for shape in deck.slides[0].shapes:
        if shape.has_text_frame and norm(shape.text) not in actual:
            issues.append("Missing editable text: "+shape.text[:70])
    lines=[line for block in page.get_text("dict")["blocks"] if "lines" in block
           for line in block["lines"] if any(s["text"].strip() for s in line["spans"])]
    for i,line in enumerate(lines):
        box=fitz.Rect(line["bbox"])
        if not page.rect.contains(box):issues.append("Outside page: "+str(box))
        for other in lines[i+1:]:
            cross=box & fitz.Rect(other["bbox"])
            if not cross.is_empty and cross.width>2 and cross.height>2:
                issues.append("Text overlap: "+line["spans"][0]["text"]+" / "+other["spans"][0]["text"])
    metrics=json.loads((OUT/"poster_metrics.json").read_text())
    for visual in metrics["visuals"]:
        if visual["effective_dpi"] is not None and visual["effective_dpi"]<150:
            issues.append("Low image resolution: "+visual["name"])
    for equation in metrics.get("equations", []):
        if equation["size_pt"] < 24:
            issues.append("Small equation: "+equation["name"])
    pictures=[s for s in deck.slides[0].shapes if s.shape_type == MSO_SHAPE_TYPE.PICTURE]
    texts=[s for s in deck.slides[0].shapes if s.has_text_frame and s.text.strip()]
    def rect(shape):
        return fitz.Rect(shape.left/12700,shape.top/12700,
                         (shape.left+shape.width)/12700,(shape.top+shape.height)/12700)
    for picture in pictures:
        if not page.rect.contains(rect(picture)):
            issues.append("Image outside page: "+picture.name)
        for shape in texts:
            cross=rect(picture) & rect(shape)
            if not cross.is_empty and cross.width>2 and cross.height>2:
                issues.append("Image/text overlap: "+picture.name+" / "+shape.text[:50])
    page.get_pixmap(matrix=fitz.Matrix(.65,.65),alpha=False).save(OUT/"poster_preview.png")
    # Native 100% (72 points per inch) inspection crops, not reduced thumbnails.
    for name,box in [("header",(0,0,3456,390)),("left",(60,390,1150,2400)),
                     ("middle",(1170,390,2280,2400)),("right",(2280,390,3400,2400)),
                     ("footer",(0,2370,3456,2592))]:
        page.get_pixmap(matrix=fitz.Matrix(1,1),clip=fitz.Rect(box),alpha=False).save(OUT/("poster_100pct_"+name+".png"))
    font_sizes=sorted({round(s["size"],1) for line in lines for s in line["spans"] if s["text"].strip()})
    result=dict(pages=1,width_inches=page.rect.width/72,height_inches=page.rect.height/72,
                font_sizes_pt=font_sizes,issues=issues,metrics=metrics)
    (OUT/"poster_layout_check.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="metrics"},indent=2))
    if issues:raise SystemExit(1)


if __name__=="__main__":inspect()
