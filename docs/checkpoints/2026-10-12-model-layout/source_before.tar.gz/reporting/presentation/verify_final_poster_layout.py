"""Check full-size poster boundaries, references, figure labels and display copy."""

from io import BytesIO
import json
from pathlib import Path
import re
import zipfile

import numpy as np
from PIL import Image
import pymupdf as fitz
from pptx import Presentation

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "tmp/poster_final_review"
BUILD = ROOT / "tmp/poster_latex"
STEM = "beyond_borders_research_poster"


def main():
    pdf = fitz.open(BUILD / f"{STEM}.pdf")
    page = pdf[0]
    assert len(pdf) == 1 and page.rect == fitz.Rect(0, 0, 3456, 2592)
    assert not page.get_images()
    assert all(pdf.extract_font(font[0])[3] for font in page.get_fonts(full=True))
    text = page.get_text()
    assert text.count("Bani Mallick") == 2
    assert "50,000" in text and "640,000" in text
    for number in range(1, 6):
        assert f"[{number}]" in text
    links = {link.get("uri", "") for link in page.get_links()}
    expected = {
        "https://doi.org/10.1093/biomet/57.1.97",
        "https://ned.ipac.caltech.edu/level5/March02/Silverman/Silver_contents.html",
        "https://doi.org/10.1016/0021-9991(83)90014-1",
        "https://doi.org/10.1214/20-BA1221",
        "https://doi.org/10.1214/12-IMSCOLL1006",
        "https://cordis.europa.eu/project/id/101071601/reporting",
    }
    assert expected <= links, expected-links
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):
            rect = fitz.Rect(line["bbox"])
            assert page.rect.contains(rect)
            line_text = "".join(span["text"] for span in line["spans"])
            if 400 < rect.y0 and rect.y1 < 2350:
                for divider in [15.62*72, 32.37*72]:
                    assert not rect.x0 < divider < rect.x1, (line_text, rect)
    # Whole-line boxes span blank space below tall inline summation symbols.
    # Compare the actual prose words so those math extents do not create false collisions.
    prose_words = [(fitz.Rect(word[:4]), word[4], word[5:7]) for word in page.get_text("words")
                   if re.search(r"[A-Za-z]{3,}", word[4])]
    for index, (rect, line, line_id) in enumerate(prose_words):
        for other_rect, other, other_id in prose_words[index+1:]:
            if line_id == other_id:
                continue
            overlap = rect & other_rect
            assert overlap.is_empty or overlap.width <= 2 or overlap.height <= 2, (line, other)
    figure_labels = {}
    for name in ["branches", "posterior_long", "efficiency_long"]:
        figure = fitz.open(ROOT / f"docs/presentation/Images/latex_poster/{name}.pdf")
        words = figure[0].get_text("words")
        assert all(figure[0].rect.contains(fitz.Rect(word[:4])) for word in words), name
        figure_labels[name] = len(words)
    deck = Presentation(BUILD / f"{STEM}.pptx")
    assert len(deck.slides) == 1 and len(deck.slides[0].shapes) == 1
    assert deck.slide_width == 48*914400 and deck.slide_height == 36*914400
    # OOXML escapes PDF-extracted math control glyphs instead of dropping them.
    notes = deck.slides[0].notes_slide.notes_text_frame.text
    notes = re.sub(r"_x([0-9A-Fa-f]{4})_", lambda match: chr(int(match[1], 16)), notes)
    assert text in notes
    with zipfile.ZipFile(BUILD / f"{STEM}.pptx") as archive:
        assert archive.testzip() is None
        assert not any(name.endswith(".svg") for name in archive.namelist())
    pixels = page.get_pixmap(matrix=fitz.Matrix(150/72, 150/72), alpha=False)
    embedded = Image.open(BytesIO(deck.slides[0].shapes[0].image.blob)).convert("RGB")
    assert embedded.size == (pixels.width, pixels.height)
    assert embedded.tobytes() == pixels.samples
    office_pdf = OUT / f"{STEM}.pdf"
    assert office_pdf.stat().st_mtime >= (BUILD / f"{STEM}.pptx").stat().st_mtime, "Office export is stale"
    rerender = fitz.open(office_pdf)
    assert len(rerender) == 1 and rerender[0].rect == page.rect
    actual = np.frombuffer(page.get_pixmap(matrix=fitz.Matrix(.5, .5), alpha=False).samples, np.uint8).astype(float)
    comparison = np.frombuffer(rerender[0].get_pixmap(matrix=fitz.Matrix(.5, .5), alpha=False).samples, np.uint8).astype(float)
    error = float(np.abs(actual-comparison).mean())
    assert error < 8, error
    report = {"status": "passed", "size_inches": [48, 36], "pages": 1,
              "native_vector_pdf": True, "fonts_embedded": True,
              "prose_overlap_and_column_boundary_checks": "passed",
              "figure_label_counts_checked": figure_labels, "reference_and_context_links": sorted(expected),
              "co_supervisor_mentions": 2, "pptx_svg_overrides": 0,
              "pptx_matches_pdf_at_150_dpi": True, "pptx_rerender_pixel_error": error}
    (OUT / "layout_audit.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
