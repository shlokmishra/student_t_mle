"""Render the authoritative LaTeX poster and a portable PowerPoint display copy.

No sampler experiments are run. Figures use frozen reference and long-chain
evidence. Use --publish only after reviewing the PDF previews.
"""
import argparse
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

from prepare_final_poster_assets import figures
import pymupdf as fitz
from pptx import Presentation
from pptx.util import Inches

ROOT = Path(__file__).resolve().parents[2]
DOCS = ROOT / "docs/presentation"
OUT = ROOT / "tmp/poster_latex"
ASSETS = DOCS / "Images/latex_poster"
STEM = "beyond_borders_research_poster"
TEXBIN = Path("/sw/eb/sw/texlive/20230313-GCC-13.2.0/bin/x86_64-linux")


def compile_tex():
    executable=shutil.which("pdflatex") or str(TEXBIN/"pdflatex")
    env=dict(os.environ)
    env["PATH"]=str(Path(executable).parent)+os.pathsep+env["PATH"]
    for run in range(2):
        result=subprocess.run([executable,"-halt-on-error","-interaction=nonstopmode",
                               "-output-directory="+str(OUT),str(DOCS/(STEM+".tex"))],
                              cwd=ROOT,env=env,text=True,errors="replace",
                              stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (OUT/f"compile_{run+1}.txt").write_text(result.stdout)
        if result.returncode:
            raise RuntimeError(result.stdout[-6500:])
    log=(OUT/(STEM+".log")).read_text(errors="replace")
    overflow=re.findall(r"Overfull \\[hv]box[^\n]*",log)
    if overflow:
        raise RuntimeError("LaTeX overflow:\n"+"\n".join(overflow))
    print("LaTeX: two passes; no overfull boxes.",flush=True)


def inspect_and_package():
    pdf=fitz.open(OUT/(STEM+".pdf"))
    assert len(pdf)==1
    page=pdf[0]
    assert abs(page.rect.width-3456)<.1 and abs(page.rect.height-2592)<.1
    text=page.get_text()
    for phrase in ["Algorithm 1.","Hastings correction", "Branch draw", "Laplace", "KDE", "Patricia Ning", "Bani Mallick"]:
        assert phrase in text,phrase
    assert "raw weighted" not in text.lower()
    glyphs=[c for b in page.get_text("rawdict")["blocks"] if "lines" in b
            for line in b["lines"] for span in line["spans"] for c in span["chars"] if c["c"].strip()]
    assert all(page.rect.contains(fitz.Rect(c["bbox"])) for c in glyphs)
    fonts=[dict(name=f[3],type=f[2],embedded=bool(pdf.extract_font(f[0])[3])) for f in page.get_fonts(full=True)]
    assert all(f["embedded"] for f in fonts),fonts
    assert not page.get_images(),"Poster should retain vector plots and typeset text, not raster snapshots."
    page.get_pixmap(matrix=fitz.Matrix(.65,.65),alpha=False).save(OUT/"poster_preview.png")
    for name,rect in [("left",(65,385,1115,2350)),("middle",(1140,385,2310,2350)),
                      ("right",(2340,385,3390,2350)),("header",(0,0,3456,385)),
                      ("footer",(0,2360,3456,2592))]:
        page.get_pixmap(clip=fitz.Rect(rect),alpha=False).save(OUT/f"poster_100pct_{name}.png")
    (OUT/"poster_text.txt").write_text(text)
    metrics=dict(pages=1,width_inches=48,height_inches=36,embedded_fonts=fonts,
                 raster_images=0,overfull_boxes=0,equations="native LaTeX vector text",
                 editable_master=str(DOCS/(STEM+".tex")),pptx="150-dpi PNG display copy, no SVG override; edit LaTeX master")
    (OUT/"validation.json").write_text(json.dumps(metrics,indent=2)+"\n")

    # Keep the print PDF vector-based; ordinary PNGs avoid viewer-specific SVG failures.
    preview=OUT/"powerpoint_fallback.png"
    page.get_pixmap(matrix=fitz.Matrix(150/72,150/72),alpha=False).save(preview)
    prs=Presentation()
    prs.slide_width,prs.slide_height=Inches(48),Inches(36)
    slide=prs.slides.add_slide(prs.slide_layouts[6])
    shape=slide.shapes.add_picture(str(preview),0,0,width=prs.slide_width,height=prs.slide_height)
    shape._element.nvPicPr.cNvPr.set("descr","LaTeX poster display copy. Edit beyond_borders_research_poster.tex and rebuild.")
    slide.notes_slide.notes_text_frame.text=("LaTeX is the editable master. This is a 150-dpi display copy. Use the vector PDF for printing.\n\n"+text)
    prs.save(OUT/(STEM+".pptx"))
    print("Validated 48 x 36 inches; native vector PDF; embedded fonts; PowerPoint display copy.",flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--publish",action="store_true")
    parser.add_argument("--reuse-figures", action="store_true", help="Rebuild text/layout without regenerating the saved figures.")
    args=parser.parse_args()
    OUT.mkdir(parents=True,exist_ok=True)
    if not args.reuse_figures:
        figures()
    compile_tex()
    inspect_and_package()
    if args.publish:
        for ext in ("pdf","pptx"):
            shutil.copy2(OUT/(STEM+"."+ext),DOCS/(STEM+"."+ext))
        print("Published matching PDF and PowerPoint copy.")


if __name__=="__main__":
    main()
