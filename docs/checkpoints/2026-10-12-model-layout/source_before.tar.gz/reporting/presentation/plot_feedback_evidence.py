"""Presentation-sized views of the saved independent-reference diagnostic."""
from pathlib import Path
import json
import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MaxNLocator

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from kde_ref.posterior import get_normalized_posterior_pdf, build_likelihood_kde_backend
from kde_ref.moments import weighted_quantile

SOURCE = ROOT / "tmp/presentation_feedback_2"
OUT = ROOT / "docs/presentation/Images/general_audience/polished"
TEAL, CORAL, INK, BG, LINE = "#16766D", "#C45546", "#183B3A", "#F0F5F4", "#CEDDD9"


def create():
    data = np.load(SOURCE/"diagnostic.npz")
    meta = json.loads((SOURCE/"metadata.json").read_text())
    params = meta["params"]
    burn = meta["burn_in"]
    mle = data["centered_mle"]
    weights = data["weights"]
    ref_mu = data["ref_mu"]
    prior = dict(prior_mean=0., prior_std=10., kde_bw_method="scott")
    pdf = get_normalized_posterior_pdf(0., prior, mle, use_grid=True, n_grid=4000)
    kernel = build_likelihood_kde_backend(mle, prior)
    grid = np.linspace(-3.5, 3.5, 1000)
    reference = pdf(grid)
    def save(fig, name):
        fig.savefig(OUT/(name+".png"), dpi=220, bbox_inches="tight", pad_inches=.12)
        plt.close(fig)
    def clean(ax):
        ax.spines[["top", "right"]].set_visible(False)
        ax.grid(axis="y", color=LINE, lw=.6)
        ax.set_axisbelow(True)

    fig, ax = plt.subplots(figsize=(8.5, 4.2))
    fig.subplots_adjust(left=.13, right=.98, bottom=.23, top=.76)
    release = np.linspace(-2.5, 4., 900)
    for center, color, style in [(0., TEAL, "-"), (1.5, CORAL, "--")]:
        ax.plot(release, np.exp(kernel.logpdf(release-center)), color=color, ls=style,
                lw=3.3, label=f"Population center = {center:g}")
    ax.axvline(0, color=INK, lw=1.5, ls=":")
    ax.legend(frameon=False, fontsize=17, loc="lower left", bbox_to_anchor=(0,1.02))
    ax.set_xlabel("Value of the published estimate", labelpad=10)
    ax.set_ylabel("Probability density", labelpad=10)
    clean(ax)
    save(fig, "kde_shift")

    # A preselected example (first reference dataset), not a best-looking case.
    observed = data["ref_x"][0]
    ll = -1.5*np.log1p((observed[:,None]-grid)**2/2.).sum(axis=0)-.5*(grid/10.)**2
    full = np.exp(ll-ll.max())
    full /= np.trapezoid(full, grid)
    fig, ax = plt.subplots(figsize=(12., 4.0))
    fig.subplots_adjust(left=.08, right=.985, bottom=.23, top=.94)
    ax.plot(grid, full, color=TEAL, lw=3.5, label="Full dataset available")
    ax.plot(grid, reference, color=CORAL, lw=3.5, ls="--", label="Only the estimate available")
    ax.fill_between(grid, 0, full, color=TEAL, alpha=.06)
    ax.set_xlabel("Possible population center", labelpad=10)
    ax.set_ylabel("Posterior density", labelpad=10)
    ax.legend(frameon=False, fontsize=20)
    clean(ax)
    save(fig, "release_posterior")

    # Traces are consecutive and never decimated; marginals use all retained states.
    start, stop = 15001, 17001
    mu_range = max(3.5, max(abs(data[m+"_mu"][burn:]).max() for m in ["gibbs", "rattle"]))
    density_grid = np.linspace(-mu_range, mu_range, 1200)
    trace_limits = np.concatenate([data[m+"_mu"][start:stop] for m in ["gibbs", "rattle"]])
    fig, axes = plt.subplots(2, 2, figsize=(12., 4.1), gridspec_kw={"width_ratios":[1.9,1]})
    fig.subplots_adjust(left=.08, right=.985, bottom=.22, top=.88, hspace=.45, wspace=.22)
    for i, (method, color) in enumerate([("gibbs", TEAL), ("rattle", CORAL)]):
        trace, density = axes[i]
        trace.plot(np.arange(start, stop), data[method+"_mu"][start:stop], color=color, lw=.75)
        trace.set_ylim(trace_limits.min()-.1, trace_limits.max()+.1)
        trace.set_ylabel(method.title(), color=color, fontsize=20, weight="bold")
        trace.tick_params(labelsize=14)
        trace.set_xticks([15000,16000,17000])
        density.hist(data[method+"_mu"][burn:], bins=65, density=True, color=color, alpha=.45)
        density.plot(density_grid, pdf(density_grid), color=INK, lw=2.2)
        density.set_xlim(-mu_range, mu_range)
        density.tick_params(labelsize=14)
        for ax in (trace, density): clean(ax)
    axes[0,0].set_title("Population center through time", loc="left", fontsize=21)
    axes[0,1].set_title("Density vs reference", loc="left", fontsize=21)
    axes[-1,0].set_xlabel("Iteration", fontsize=19)
    axes[-1,1].set_xlabel("Population center", fontsize=19)
    save(fig, "mu_reference_comparison")

    summaries = {}
    for quantiles, name, height in [([.05,.5,.95], "latent_reference_comparison", 4.2),
                                    ([.05,.25,.5,.75,.95], "latent_five_quantiles", 7.4)]:
        ref_q = np.quantile(data["ref_x"], quantiles, axis=1).T
        fig, axes = plt.subplots(len(quantiles), 2, figsize=(12., height), sharex=True)
        fig.subplots_adjust(left=.105, right=.985, bottom=.19 if height<5 else .1,
                            top=.88 if height<5 else .93, hspace=.16, wspace=.15)
        for row, q in enumerate(quantiles):
            bounds = weighted_quantile(ref_q[:,row], weights, [.025,.975])
            ys = [np.quantile(data[m+"_x"][start:stop], q, axis=1) for m in ["gibbs","rattle"]]
            lo, hi = min(min(v) for v in ys), max(max(v) for v in ys)
            lo, hi = min(lo, bounds[0]), max(hi, bounds[1])
            pad = .04*(hi-lo)
            for col, (method, color, values) in enumerate(zip(["gibbs","rattle"], [TEAL,CORAL], ys)):
                ax = axes[row,col]
                ax.axhspan(*bounds, color="#A8B8B3", alpha=.4, zorder=0)
                ax.plot(np.arange(start, stop), values, color=color, lw=.7)
                ax.set_ylim(lo-pad, hi+pad)
                if max(abs(lo),abs(hi)) > 20:
                    ax.set_yscale("symlog", linthresh=2)
                    ticks = [v for v in [-1000,-100,-10,0,10,100,1000] if lo-pad <= v <= hi+pad]
                    ax.set_yticks(ticks, [str(v) for v in ticks])
                else:
                    ax.yaxis.set_major_locator(MaxNLocator(3))
                ax.set_xticks([15000,16000,17000])
                ax.tick_params(labelsize=13)
                clean(ax)
            label = "Median" if q == .5 else f"{int(q*100)}th\npercentile"
            axes[row,0].set_ylabel(label, fontsize=15, rotation=0, ha="right", va="center", labelpad=26)
            summaries[str(q)] = [float(v) for v in bounds]
        axes[0,0].set_title("Gibbs: hidden-data quantiles", loc="left", fontsize=21, color=TEAL)
        axes[0,1].set_title("RATTLE: hidden-data quantiles", loc="left", fontsize=21, color=CORAL)
        for ax in axes[-1]: ax.set_xlabel("Iteration", fontsize=19)
        save(fig, name)
    result = dict(reference_weight_ess=float(weights.sum()**2/(weights@weights)),
                  ref_mu_sd=float(np.sqrt(np.average((ref_mu-np.average(ref_mu,weights=weights))**2,weights=weights))),
                  first_dataset_full_sd=float(np.sqrt(np.trapezoid(grid**2*full,grid)-np.trapezoid(grid*full,grid)**2)),
                  trace_start=start, trace_stop_exclusive=stop, retained_states=15001,
                  latent_reference_95_intervals=summaries)
    for method in ["gibbs", "rattle"]:
        mu = data[method+"_mu"][burn:]
        median = np.median(data[method+"_x"][burn:],axis=1)
        result[method] = dict(mu_mean=float(mu.mean()), mu_sd=float(mu.std()),
                              median_lag1_correlation=float(np.corrcoef(median[:-1],median[1:])[0,1]))
    (SOURCE/"plot_summary.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":20,
                         "figure.facecolor":BG,"axes.facecolor":BG,"savefig.facecolor":BG,
                         "text.color":INK,"axes.labelcolor":INK,"axes.edgecolor":LINE,
                         "xtick.color":INK,"ytick.color":INK})
    create()
