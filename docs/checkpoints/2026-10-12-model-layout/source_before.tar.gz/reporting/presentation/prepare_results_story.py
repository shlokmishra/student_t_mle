"""Refresh bounded presentation evidence, independently of MCMC targets.

Saved backend timings are historical implementation measurements. New location
reference particles use equivariance and prior weighting, without legacy caches.
"""
from pathlib import Path
import csv
import hashlib
import json
import shutil
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
OUT = ROOT / "tmp/presentation_results_story"
ASSETS = ROOT / "docs/presentation/Images/general_audience/polished"
BG, INK, TEAL, CORAL, LILAC = "#F0F5F4", "#183B3A", "#16766D", "#C45546", "#7774A4"
SPECS = [("logistic", 10), ("logistic", 50), ("student", 10), ("laplace", 11), ("laplace", 51)]


def mle(x, model):
    if model == "laplace":
        return np.median(x, axis=1)
    if model == "student":
        from models.student_location_mle import global_mle
        return np.array([global_mle(row, 2.) for row in x])
    lo, hi = x.min(axis=1), x.max(axis=1)
    for _ in range(52):
        mid = (lo+hi)/2
        score = np.tanh((x-mid[:, None])/2).sum(axis=1)
        lo, hi = np.where(score > 0, mid, lo), np.where(score > 0, hi, mid)
    return (lo+hi)/2


def full_pdf(x, model, grid):
    y = x[:, None]-grid
    if model == "student":
        ll = -1.5*np.log1p(y*y/2).sum(axis=0)
    elif model == "logistic":
        ll = (-y-2*np.logaddexp(0, -y)).sum(axis=0)
    else:
        ll = -np.abs(y).sum(axis=0)
    ll -= .5*(grid/10)**2
    pdf = np.exp(ll-ll.max())
    pdf /= np.trapezoid(pdf, grid)
    assert np.trapezoid(pdf[:100],grid[:100])+np.trapezoid(pdf[-100:],grid[-100:]) < 1e-8
    mean = np.trapezoid(grid*pdf, grid)
    sd = np.sqrt(np.trapezoid((grid-mean)**2*pdf, grid))
    return pdf, sd


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)
    cache = OUT / "information_reference.npz"
    frozen = ROOT / "docs/presentation/evidence/results_story"
    if not cache.exists() and (frozen/cache.name).exists():
        for name in [cache.name,"information_by_dataset.csv","information_metadata.json"]:
            shutil.copy2(frozen/name,OUT/name)
    if not cache.exists():
        rng = np.random.default_rng(20260909)
        arrays, results = {}, []
        grid = np.linspace(-40, 40, 16001)
        errors = []
        for model, n in SPECS:
            key = f"{model}_{n}"
            draw = {"logistic":rng.logistic, "laplace":rng.laplace,
                    "student":lambda size:rng.standard_t(2.,size=size)}[model]
            if model == "student":
                fresh = np.load(ROOT/"tmp/presentation_feedback_2/diagnostic.npz")
                base_mle = fresh["centered_mle"]
            else:
                base_mle = mle(draw(size=(20000,n)),model)
            observed = draw(size=(100,n))
            released = mle(observed,model)
            arrays[key+"_mle"] = base_mle
            arrays[key+"_observed"] = observed
            arrays[key+"_released"] = released
            for i, (x,t) in enumerate(zip(observed,released)):
                pdf, full_sd = full_pdf(x,model,grid)
                particles = t-base_mle
                weights = np.exp(-.5*(particles/10)**2)
                mean = np.average(particles,weights=weights)
                ref_sd = np.sqrt(np.average((particles-mean)**2,weights=weights))
                if i < 5:
                    _, fine_sd = full_pdf(x,model,np.linspace(-40,40,32001))
                    errors.append(abs(full_sd/fine_sd-1))
                results.append(dict(model=model,n=n,dataset=i,release=float(t),
                                    full_sd=float(full_sd),reference_sd=float(ref_sd),
                                    sd_ratio=float(ref_sd/full_sd)))
            print("Finished",key,flush=True)
        assert max(errors) < .001
        np.savez_compressed(cache,**arrays)
        with (OUT/"information_by_dataset.csv").open("w") as f:
            writer = csv.DictWriter(f,fieldnames=list(results[0]))
            writer.writeheader(); writer.writerows(results)
        (OUT/"information_metadata.json").write_text(json.dumps(dict(
            seed=20260909,observed_datasets_per_regime=100,prior="Normal(0,10)",
            fixed_scale=1,student_df=2,student_reference_B=12000,other_reference_B=20000,
            reference="mu=t-T(U); weight=prior(mu); raw weighted particle moments",
            full_grid=[-40,40,16001],max_grid_sd_relative_change=max(errors),
            selector_sha256=hashlib.sha256((ROOT/"models/student_location_mle.py").read_bytes()).hexdigest(),
            caveat="Finite Monte Carlo reference; no claim of exact sufficiency or privacy guarantees."
        ),indent=2)+"\n")
    return np.load(cache),list(csv.DictReader((OUT/"information_by_dataset.csv").open()))


def save(fig,name):
    fig.savefig(ASSETS/(name+".png"),dpi=400,bbox_inches="tight",pad_inches=.16)
    fig.savefig(ASSETS/(name+".pdf"),bbox_inches="tight",pad_inches=.16)
    if name in {"implementation_runtime", "information_repeated"}:
        fig.set_size_inches(9.3,5.4)
        if name == "implementation_runtime":
            fig.axes[0].set_xlabel("Seconds for 60,000 updates\n(lower is better)")
            fig.subplots_adjust(bottom=.25)
        else:
            fig.axes[0].tick_params(axis="x",labelsize=17)
        fig.savefig(ASSETS/(name+"_poster.png"),dpi=400,bbox_inches="tight",pad_inches=.16)
        fig.savefig(ASSETS/(name+"_poster.pdf"),bbox_inches="tight",pad_inches=.16)
    plt.close(fig)


def clean(ax):
    ax.spines[["top","right"]].set_visible(False)
    ax.grid(axis="y",color="#CEDDD9",lw=.7)
    ax.set_axisbelow(True)


def figures(data,rows):
    summary = []
    values=[]
    for model,n in SPECS:
        v=np.array([float(r["sd_ratio"]) for r in rows if r["model"]==model and int(r["n"])==n])
        values.append(v)
        summary.append(dict(model=model,n=n,median_ratio=float(np.median(v)),
                            q10=float(np.quantile(v,.1)),q90=float(np.quantile(v,.9))))
    fig,ax=plt.subplots(figsize=(12,4.7))
    fig.subplots_adjust(left=.12,right=.98,bottom=.24,top=.94)
    colors=[TEAL,TEAL,CORAL,LILAC,LILAC]
    rng=np.random.default_rng(12)
    for i,(v,color) in enumerate(zip(values,colors),1):
        ax.scatter(i+rng.uniform(-.16,.16,len(v)),v,s=19,color=color,alpha=.5)
        ax.plot([i-.22,i+.22],[np.median(v)]*2,color=INK,lw=3)
    ax.axhline(1,color=INK,ls="--",lw=1.2)
    ax.set_xticks(range(1,6),["Logistic\nn=10","Logistic\nn=50","Student k=2\nn=10","Laplace\nn=11","Laplace\nn=51"])
    ax.set_ylabel("Uncertainty ratio\n(estimate only / full data)")
    clean(ax); save(fig,"information_repeated")

    # Show the first dataset in each specified regime; no selection by appearance.
    fig,axes=plt.subplots(1,2,figsize=(12,4.5))
    fig.subplots_adjust(left=.085,right=.98,bottom=.23,top=.76,wspace=.22)
    from scipy.stats import gaussian_kde
    for ax,(model,n),label in zip(axes,[("logistic",50),("student",10)],
                                 ["Logistic / 50 observations","Student / 10 observations"]):
        key=f"{model}_{n}"; x=data[key+"_observed"][0]; t=data[key+"_released"][0]
        grid=np.linspace(t-1.8,t+1.8,1200)
        full,_=full_pdf(x,model,np.linspace(-40,40,16001))
        full=np.interp(grid,np.linspace(-40,40,16001),full)
        particles=t-data[key+"_mle"]; weights=np.exp(-.5*(particles/10)**2)
        smooth=gaussian_kde(particles,weights=weights)(grid)
        ax.plot(grid-t,full,color=TEAL,lw=3,label="Full dataset")
        ax.plot(grid-t,smooth,color=CORAL,lw=3,ls="--",label="Estimate only")
        ax.set_title(label,fontsize=20,pad=15)
        ax.set_xlabel("Center relative to release",fontsize=19)
        clean(ax)
    axes[0].set_ylabel("Posterior density")
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="upper center",ncol=2,frameon=False,fontsize=21)
    save(fig,"information_examples")

    timing=list(csv.DictReader((ROOT/"results/numba_speedup_validation_task_results/benchmark_results.csv").open()))
    speedups=[]
    for k in [1.,2.,3.]:
        for n in [10,20,50]:
            med={b:np.median([float(r["iterations_per_sec"]) for r in timing
                              if r["backend"]==b and float(r["k"])==k and int(r["n"])==n])
                 for b in ["jax_loop","jax_scan","numba"]}
            speedups.append(dict(k=k,n=n,vs_loop=med["numba"]/med["jax_loop"],vs_scan=med["numba"]/med["jax_scan"]))
    fig,ax=plt.subplots(figsize=(12,4.6))
    fig.subplots_adjust(left=.25,right=.94,bottom=.2,top=.92)
    backends=["jax_loop","jax_scan","numba"]
    seconds=[np.median([float(r["elapsed_sec"]) for r in timing if r["backend"]==b
                        and float(r["k"])==2 and int(r["n"])==50]) for b in backends]
    ax.barh([2,1,0],seconds,color=[LILAC,TEAL,CORAL],height=.5)
    for y,sec in zip([2,1,0],seconds):
        ax.text(sec+3,y,f"{sec:.1f} s",va="center",fontsize=22,weight="bold")
    ax.set_yticks([2,1,0],["Original JAX loop","Compiled JAX scan","Compiled Numba"])
    ax.set_xlim(0,max(seconds)*1.25)
    ax.set_xlabel("Seconds for 60,000 updates (lower is better)")
    clean(ax); save(fig,"implementation_runtime")
    (OUT/"results_summary.json").write_text(json.dumps(dict(information=summary,speedups=speedups,
        example_seconds=dict(zip(backends,seconds)),
        timing_sha256=hashlib.sha256((ROOT/"results/numba_speedup_validation_task_results/benchmark_results.csv").read_bytes()).hexdigest()),indent=2)+"\n")
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":20,"axes.labelsize":22,
        "figure.facecolor":BG,"axes.facecolor":BG,"savefig.facecolor":BG,
        "text.color":INK,"axes.labelcolor":INK,"xtick.color":INK,"ytick.color":INK})
    figures(*prepare())
