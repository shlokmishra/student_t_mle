"""Create discussion-friendly visuals for the Beyond Borders presentation.

The figures are intentionally explanatory rather than publication-heavy. They
are reusable in the later 36 x 48 inch poster.
"""

from __future__ import annotations

import csv
import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Polygon


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "docs" / "presentation" / "Images" / "general_audience"
INFO_CSV = (
    ROOT
    / "results"
    / "final_production_v1_release_information_audit_100"
    / "information_loss_by_dataset.csv"
)

NAVY = "#173F5F"
BLUE = "#20639B"
TEAL = "#2A9D8F"
GOLD = "#F2B134"
CORAL = "#E76F51"
PURPLE = "#6C5CE7"
PALE = "#F4F7FA"
GRAY = "#5B6573"


def setup() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 18,
            "axes.titlesize": 25,
            "axes.labelsize": 19,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )


def save(fig: plt.Figure, name: str) -> None:
    fig.savefig(OUT / name, dpi=220, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def rounded_box(ax, xy, width, height, color, title, lines, title_color="white"):
    box = FancyBboxPatch(
        xy,
        width,
        height,
        boxstyle="round,pad=0.025,rounding_size=0.035",
        linewidth=0,
        facecolor=color,
    )
    ax.add_patch(box)
    ax.text(
        xy[0] + width / 2,
        xy[1] + height * 0.73,
        title,
        ha="center",
        va="center",
        color=title_color,
        fontsize=19 if len(title.replace("\n", "")) > 18 else 22,
        fontweight="bold",
    )
    ax.text(
        xy[0] + width / 2,
        xy[1] + height * 0.37,
        lines,
        ha="center",
        va="center",
        color=title_color,
        fontsize=16,
        linespacing=1.35,
    )


def paris_context() -> None:
    fig, ax = plt.subplots(figsize=(13.3, 6.6))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")

    # French tricolour marker and a minimal Eiffel Tower silhouette.
    ax.add_patch(Polygon([[0.04, 0.12], [0.12, 0.12], [0.12, 0.87], [0.04, 0.87]], color="#1B4FA3"))
    ax.add_patch(Polygon([[0.12, 0.12], [0.20, 0.12], [0.20, 0.87], [0.12, 0.87]], color="white"))
    ax.add_patch(Polygon([[0.20, 0.12], [0.28, 0.12], [0.28, 0.87], [0.20, 0.87]], color="#ED2939"))
    ax.plot([0.105, 0.16, 0.215], [0.22, 0.78, 0.22], color=NAVY, lw=4)
    ax.plot([0.12, 0.20], [0.42, 0.42], color=NAVY, lw=4)
    ax.plot([0.09, 0.23], [0.22, 0.22], color=NAVY, lw=4)
    ax.text(0.16, 0.08, "Paris, France", ha="center", fontsize=23, fontweight="bold", color=NAVY)

    rounded_box(
        ax,
        (0.35, 0.56),
        0.27,
        0.30,
        BLUE,
        "Lived at CIUP",
        "An international campus\nfor students and researchers",
    )
    rounded_box(
        ax,
        (0.68, 0.56),
        0.27,
        0.30,
        TEAL,
        "Worked at PariSanté",
        "A hub connecting health,\ndata, research and innovation",
    )
    rounded_box(
        ax,
        (0.50, 0.12),
        0.30,
        0.28,
        PURPLE,
        "Research\ncollaboration",
        "Christian P. Robert\nCEREMADE · OCEAN ERC",
    )
    for start, end in [((0.485, 0.56), (0.61, 0.42)), ((0.815, 0.56), (0.69, 0.42))]:
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=22, lw=2.5, color=GRAY))
    save(fig, "paris_research_context.png")


def privacy_frameworks() -> None:
    fig, ax = plt.subplots(figsize=(13.3, 6.6))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    rounded_box(ax, (0.03, 0.22), 0.285, 0.57, BLUE, "GDPR", "Rights, principles\nand responsibilities\nfor personal data")
    rounded_box(ax, (0.357, 0.22), 0.285, 0.57, TEAL, "Differential privacy", "A mathematical guarantee\nfor randomized releases\nand neighboring datasets")
    rounded_box(ax, (0.685, 0.22), 0.285, 0.57, CORAL, "Our question", "After a fixed summary\nis released, what can\nan observer infer?")
    ax.text(0.5, 0.10, "Complementary lenses on privacy — not interchangeable definitions", ha="center", fontsize=20, color=NAVY, fontweight="bold")
    save(fig, "privacy_frameworks.png")


def statistic_compression() -> None:
    fig, ax = plt.subplots(figsize=(13.3, 6.6))
    ax.set_xlim(-0.5, 10.5)
    ax.set_ylim(-0.2, 3.3)
    ax.axis("off")
    datasets = [
        np.array([-2, -1, 0, 1, 2]),
        np.array([-4, 0, 0, 0, 4]),
        np.array([-1, -1, 0, 1, 1]),
    ]
    colors = [BLUE, TEAL, PURPLE]
    for row, (data, color) in enumerate(zip(datasets, colors)):
        y = 2.65 - row * 0.9
        x = 0.7 + (data + 4) * 0.42
        ax.scatter(x, np.full_like(x, y, dtype=float), s=130, color=color, edgecolor="white", linewidth=1.5)
        ax.plot([0.6, 4.2], [y, y], color="#CBD3DC", lw=2, zorder=0)
        ax.text(0.1, y, f"Dataset {row + 1}", va="center", fontsize=18, color=NAVY, fontweight="bold")
    ax.add_patch(FancyArrowPatch((4.45, 1.76), (6.15, 1.76), arrowstyle="-|>", mutation_scale=30, lw=3, color=GOLD))
    ax.add_patch(FancyBboxPatch((6.25, 1.14), 1.55, 1.25, boxstyle="round,pad=0.03", facecolor=PALE, edgecolor=NAVY, linewidth=2.5))
    ax.text(7.025, 1.96, "Compute one\nsummary", ha="center", va="center", fontsize=20, color=NAVY, fontweight="bold")
    ax.text(7.025, 1.43, "estimated center", ha="center", va="center", fontsize=16, color=GRAY)
    ax.add_patch(FancyArrowPatch((7.9, 1.76), (8.8, 1.76), arrowstyle="-|>", mutation_scale=30, lw=3, color=GOLD))
    ax.add_patch(Circle((9.55, 1.76), 0.58, facecolor=CORAL, edgecolor="none"))
    ax.text(9.55, 1.83, "0", ha="center", va="center", fontsize=38, color="white", fontweight="bold")
    ax.text(9.55, 1.35, "released", ha="center", va="center", fontsize=13, color="white")
    ax.text(5.25, 0.22, "Compression preserves the answer — but not the original dataset", ha="center", fontsize=22, color=NAVY, fontweight="bold")
    save(fig, "statistic_compression.png")


def sampling_worlds() -> None:
    rng = np.random.default_rng(20260904)
    draws = rng.normal(0.15, 0.75, 22)
    grid = np.linspace(-3, 3, 500)
    dens = np.exp(-0.5 * ((grid - 0.15) / 0.75) ** 2)
    dens /= dens.max()
    fig, ax = plt.subplots(figsize=(13.3, 6.6))
    ax.plot(grid, dens, color=BLUE, lw=5)
    ax.fill_between(grid, 0, dens, color=BLUE, alpha=0.12)
    ax.scatter(draws, np.full_like(draws, -0.08), s=95, color=CORAL, edgecolor="white", linewidth=1.2, clip_on=False)
    for value in draws[:7]:
        height = np.interp(value, grid, dens)
        ax.plot([value, value], [-0.02, height], color=CORAL, alpha=0.25, lw=1.3)
    ax.text(-2.8, 0.88, "More plausible", fontsize=20, color=BLUE, fontweight="bold")
    ax.text(1.75, 0.24, "Less plausible", fontsize=20, color=GRAY)
    ax.set_xlim(-3, 3)
    ax.set_ylim(-0.18, 1.13)
    ax.set_xlabel("Possible value of the unknown center")
    ax.set_yticks([])
    for spine in ["left", "right", "top"]:
        ax.spines[spine].set_visible(False)
    save(fig, "sampling_worlds.png")


def gibbs_cycle() -> None:
    fig, ax = plt.subplots(figsize=(13.3, 6.6))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    rounded_box(ax, (0.05, 0.28), 0.37, 0.48, BLUE, "Step A", "Given a plausible dataset,\ndraw a plausible center\n\nparameter  |  data")
    rounded_box(ax, (0.58, 0.28), 0.37, 0.48, TEAL, "Step B", "Given that center,\ndraw a plausible dataset\nmatching the release\n\ndata  |  parameter")
    ax.add_patch(FancyArrowPatch((0.42, 0.61), (0.58, 0.61), arrowstyle="-|>", mutation_scale=28, lw=3, color=GOLD))
    ax.add_patch(FancyArrowPatch((0.58, 0.37), (0.42, 0.37), arrowstyle="-|>", mutation_scale=28, lw=3, color=GOLD))
    ax.text(0.5, 0.13, "Repeat the two manageable questions to explore one difficult joint question", ha="center", fontsize=21, color=NAVY, fontweight="bold")
    save(fig, "gibbs_cycle.png")


def likelihood_landscapes() -> None:
    mu = np.linspace(-9, 9, 1400)
    normal_data = np.array([-1.3, -0.8, -0.2, 0.1, 0.4, 0.9, 1.2])
    student_data = np.array([-5.5, -5.1, -4.8, 4.7, 5.0, 5.4])
    normal_ll = -0.5 * np.sum((normal_data[:, None] - mu[None, :]) ** 2, axis=0)
    student_ll = -np.sum(np.log1p((student_data[:, None] - mu[None, :]) ** 2), axis=0)
    normal_ll -= normal_ll.max()
    student_ll -= student_ll.max()

    fig, axes = plt.subplots(1, 2, figsize=(13.3, 5.8), sharey=False)
    axes[0].plot(mu, normal_ll, color=BLUE, lw=5)
    axes[0].fill_between(mu, normal_ll, normal_ll.min(), color=BLUE, alpha=0.10)
    axes[0].set_title("Regular model: one clear hill", fontweight="bold", color=NAVY)
    axes[0].annotate("global maximum", xy=(normal_data.mean(), 0), xytext=(2.0, -16), arrowprops={"arrowstyle": "->", "color": GRAY, "lw": 2}, fontsize=16, color=GRAY)
    axes[0].set_ylim(-120, 5)

    axes[1].plot(mu, student_ll, color=CORAL, lw=5)
    axes[1].fill_between(mu, student_ll, student_ll.min(), color=CORAL, alpha=0.10)
    axes[1].set_title("Robust Student model: several hills", fontweight="bold", color=NAVY)
    axes[1].annotate("peak 1", xy=(-5.0, np.interp(-5.0, mu, student_ll)), xytext=(-7.3, -2.0), arrowprops={"arrowstyle": "->", "color": GRAY, "lw": 2}, fontsize=16, color=GRAY)
    axes[1].annotate("peak 2", xy=(5.0, np.interp(5.0, mu, student_ll)), xytext=(2.3, -2.0), arrowprops={"arrowstyle": "->", "color": GRAY, "lw": 2}, fontsize=16, color=GRAY)
    for ax in axes:
        ax.axhline(0, color="#CBD3DC", lw=1)
        ax.set_xlabel("candidate center")
        ax.set_ylabel("relative log likelihood")
        ax.grid(alpha=0.18)
        ax.spines[["top", "right"]].set_visible(False)
    fig.suptitle("The maximum-likelihood estimate is the top of the highest hill", fontsize=25, color=NAVY, fontweight="bold")
    fig.tight_layout()
    save(fig, "likelihood_landscapes.png")


def branch_ambiguity() -> None:
    k = 2.0
    y = np.linspace(-9, 9, 1800)
    z = y / (k + y * y)
    z0 = 0.17
    discr = math.sqrt(1 - 4 * k * z0 * z0)
    yin = (1 - discr) / (2 * z0)
    yout = (1 + discr) / (2 * z0)
    fig, ax = plt.subplots(figsize=(13.3, 6.3))
    ax.plot(y, z, color=BLUE, lw=4)
    ax.axhline(z0, color=GOLD, lw=3, ls="--")
    ax.scatter([yin, yout], [z0, z0], s=190, color=[TEAL, CORAL], edgecolor="white", linewidth=2, zorder=5)
    ax.annotate("inner solution\nordinary observation", (yin, z0), (yin - 2.5, z0 + 0.11), arrowprops={"arrowstyle": "->", "lw": 2, "color": TEAL}, color=TEAL, fontsize=19, ha="center")
    ax.annotate("outer solution\nextreme observation", (yout, z0), (yout + 1.2, z0 + 0.11), arrowprops={"arrowstyle": "->", "lw": 2, "color": CORAL}, color=CORAL, fontsize=19, ha="center")
    ax.text(-8.5, -0.27, "The same score contribution can come from two very different data values", fontsize=22, color=NAVY, fontweight="bold")
    ax.set_xlabel("distance of an observation from the released center")
    ax.set_ylabel("its score contribution")
    ax.set_ylim(-0.37, 0.37)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(alpha=0.18)
    save(fig, "branch_ambiguity.png")


def kde_explainer() -> None:
    rng = np.random.default_rng(88)
    draws = np.concatenate([rng.normal(-0.35, 0.55, 120), rng.normal(0.55, 0.35, 80)])
    grid = np.linspace(-2.5, 2.5, 600)
    bandwidth = 0.24
    kde = np.mean(np.exp(-0.5 * ((grid[:, None] - draws[None, :]) / bandwidth) ** 2), axis=1)
    kde /= bandwidth * math.sqrt(2 * math.pi)
    fig, ax = plt.subplots(figsize=(13.3, 6.3))
    ax.scatter(draws, np.zeros_like(draws) - 0.015, s=24, color=GRAY, alpha=0.55, label="raw simulated values")
    ax.plot(grid, kde, color=PURPLE, lw=5, label="KDE: a smooth display")
    ax.fill_between(grid, 0, kde, color=PURPLE, alpha=0.12)
    ax.set_xlabel("possible value of the unknown center")
    ax.set_ylabel("relative concentration")
    ax.set_yticks([])
    ax.legend(frameon=False, fontsize=19, loc="upper right")
    ax.text(-2.35, kde.max() * 0.82, "A smooth curve makes thousands\nof samples easier to see", fontsize=21, color=NAVY, fontweight="bold")
    ax.text(-2.35, kde.max() * 0.63, "But calculations use the raw samples,\nnot the prettiness of the curve", fontsize=18, color=CORAL)
    ax.spines[["top", "right", "left"]].set_visible(False)
    save(fig, "kde_explainer.png")


def sampler_metaphor() -> None:
    fig, axes = plt.subplots(1, 2, figsize=(13.3, 6.2))
    theta = np.linspace(0, 2 * np.pi, 300)
    for ax in axes:
        ax.axis("off")
        ax.set_aspect("equal")
        ax.set_xlim(-3.6, 3.6)
        ax.set_ylim(-2.6, 2.6)
        ax.plot(-1.9 + 1.15 * np.cos(theta), 1.35 * np.sin(theta), color=BLUE, lw=6)
        ax.plot(1.9 + 1.15 * np.cos(theta), 1.35 * np.sin(theta), color=TEAL, lw=6)
    t = np.linspace(0.3, 4.5, 80)
    axes[0].plot(-1.9 + 1.15 * np.cos(t), 1.35 * np.sin(t), color=GOLD, lw=4)
    axes[0].scatter([-1.9 + 1.15 * np.cos(t[-1])], [1.35 * np.sin(t[-1])], s=130, color=CORAL)
    axes[0].set_title("RATTLE: walk continuously", fontsize=24, color=NAVY, fontweight="bold")
    axes[0].text(0, -2.15, "Excellent local movement\ncan still stay on one island", ha="center", fontsize=18, color=GRAY)
    axes[1].add_patch(FancyArrowPatch((-1.4, 0.45), (1.4, -0.45), connectionstyle="arc3,rad=-0.18", arrowstyle="-|>", mutation_scale=28, lw=4, ls="--", color=CORAL))
    axes[1].scatter([-1.4, 1.4], [0.45, -0.45], s=130, color=[GOLD, CORAL])
    axes[1].set_title("Gibbs branch refresh: jump", fontsize=24, color=NAVY, fontweight="bold")
    axes[1].text(0, -2.15, "A nonlocal reconstruction\ncan move between islands", ha="center", fontsize=18, color=GRAY)
    fig.suptitle("Two correct local mechanisms can explore very differently", fontsize=25, color=NAVY, fontweight="bold")
    save(fig, "sampler_metaphor.png")


def information_loss() -> None:
    with INFO_CSV.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    specs = [
        ("normal_known_var", "NA", 20, "Normal\n$n=20$", BLUE),
        ("logistic", "NA", 20, "Logistic\n$n=20$", TEAL),
        ("student_t", "3", 20, "Student $k=3$\n$n=20$", PURPLE),
        ("student_t", "1", 10, "Student $k=1$\n$n=10$", CORAL),
    ]
    values = []
    labels = []
    colors = []
    for model, k_key, n, label, color in specs:
        current = [
            float(row["sd_ratio_mle_over_full"])
            for row in rows
            if row["model"] == model and row["k_key"] == k_key and int(row["n"]) == n
        ]
        values.append(current)
        labels.append(label)
        colors.append(color)

    fig, ax = plt.subplots(figsize=(13.3, 6.4))
    bp = ax.boxplot(values, patch_artist=True, widths=0.58, showfliers=True, medianprops={"color": "white", "linewidth": 3})
    for patch, color in zip(bp["boxes"], colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.88)
    rng = np.random.default_rng(41)
    for idx, (vals, color) in enumerate(zip(values, colors), start=1):
        jitter = rng.normal(idx, 0.055, len(vals))
        ax.scatter(jitter, vals, color=color, alpha=0.45, s=30, zorder=3)
        median = float(np.median(vals))
        ax.text(idx, min(2.16, max(vals) + 0.07), f"median {median:.2f}×", ha="center", fontsize=16, color=NAVY, fontweight="bold")
    ax.axhline(1, color=GRAY, lw=2.5, ls="--")
    ax.text(0.54, 1.035, "same posterior uncertainty as full data", fontsize=15, color=GRAY)
    ax.set_xticklabels(labels, fontsize=18)
    ax.set_ylabel("relative posterior uncertainty\n(MLE-only ÷ full data)", fontsize=17)
    ax.set_ylim(0.55, 2.3)
    ax.grid(axis="y", alpha=0.18)
    ax.spines[["top", "right"]].set_visible(False)
    ax.text(0.99, -0.20, "30 simulated datasets per case; direct selected-MLE weighted-Monte-Carlo benchmark", transform=ax.transAxes, ha="right", fontsize=13, color=GRAY)
    save(fig, "information_loss_simple.png")


def main() -> None:
    setup()
    paris_context()
    privacy_frameworks()
    statistic_compression()
    sampling_worlds()
    gibbs_cycle()
    likelihood_landscapes()
    branch_ambiguity()
    kde_explainer()
    sampler_metaphor()
    information_loss()


if __name__ == "__main__":
    main()
